function f=f1(x)
     s=x(1)*x(2)*x(3)*x(4)*x(5);
     f=exp(s)-0.5*(x(1)^3+x(2)^3+1)^2;