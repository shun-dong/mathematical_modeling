function [dh,dg]=dcons(x)
     dh=[ ];
     dg=[-1 -1; 1 0; 0 1];