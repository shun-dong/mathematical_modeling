function f=f1(x) 
     s=-x(1)-x(2);
     f=exp(s)+x(1)^2+2*x(1)*x(2)+x(2)^2+2*x(1)+6*x(2);