function g_para = setGlobalParameter()
	g_para.chromosome_size = 3;
	g_para.pop_size = 30;
	g_para.max_iter = 400;
	g_para.crossover_probability = 0.6;
	g_para.mutation_probability = 0.3;
	g_para.a = 0.05;
end