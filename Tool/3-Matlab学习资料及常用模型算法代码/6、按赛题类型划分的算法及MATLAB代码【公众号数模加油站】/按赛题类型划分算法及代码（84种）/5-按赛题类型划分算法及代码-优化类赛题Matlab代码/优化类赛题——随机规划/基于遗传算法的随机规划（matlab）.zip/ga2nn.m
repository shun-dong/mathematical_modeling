function ga2nn()
end