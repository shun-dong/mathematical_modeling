classdef CommonEnum
%   Copyright 2008-2012 The MathWorks, Inc.

 
%   Copyright 2008-2012 The MathWorks, Inc.

    methods
        function out=CommonEnum
            %   Copyright 2008-2012 The MathWorks, Inc.
        end

        function getEnum(in) %#ok<MANU>
        end

    end
    methods (Abstract)
    end
    properties
        AlgebraicIntlvMethod;

        AutoOrProperty;

        BinaryGrayCustom;

        BinaryGrayUsr;

        BinaryOrGray;

        BitDataType;

        BitOrInt;

        BooleanOrDouble;

        DecisionOptions;

        DoubleInt8;

        DoubleLogicalSmallestUnsigned;

        DoubleOrSingle;

        FrequencyPulseShapes;

        IntDataType;

        LogicalOrDouble;

        NoneOrProperty;

        NormalizationMethods;

        NormalizationOptions;

        OutDataType;

        OutDataType1;

        OutDataType2;

        Polarity;

        PolynomialOptions;

        ResetOptions;

        ResetRegisterOptions;

        SameAsInputDoubleLogical;

        SignedIntDataType;

        SignedOutDataType;

        SpecifyInputs;

        TerminationMethod;

        UnsignedBitDataType;

        UnsignedIntDataType;

        %Signed sources cannot inherit / same as input / etc.
        UnsignedSrcDataType;

    end
end
