% CRC  Cyclic redundancy check (CRC) objects
%
%   crc.generator - CRC generator class
%   crc.detector  - CRC detector class

% Copyright 2007 The MathWorks, Inc.
% $Revision: 1.1.6.1 $  $Date: 2007/11/07 18:17:06 $

% [EOF]