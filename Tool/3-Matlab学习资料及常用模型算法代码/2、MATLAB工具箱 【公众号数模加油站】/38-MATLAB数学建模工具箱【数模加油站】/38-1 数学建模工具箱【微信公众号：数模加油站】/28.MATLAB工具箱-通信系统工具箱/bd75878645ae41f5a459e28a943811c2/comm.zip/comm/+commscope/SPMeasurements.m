classdef (Hidden) SPMeasurements < hgsetget & sigutils.sorteddisp
    %SPMeasurements Construct a scatter plot measurements manager object
    
    % Copyright 2008-2012 The MathWorks, Inc.
    % $Revision: 1.1.6.4 $  $Date: 2012/02/21 23:21:57 $

    %===========================================================================
    % Public Observable properties
    properties (SetObservable)
        Percentile = 95;
    end
    
    %===========================================================================
    % Read-only Dependent properties
    properties (SetAccess = private, Dependent)
        RMSEVM;
        MaximumEVM;
        PercentileEVM;
        MERdB;
        MinimumMER;
        PercentileMER;
    end
    
    %===========================================================================
    % Private properties
    properties (Access = private)
        EVM;
        MER;
    end
    
    %===========================================================================
    % Public Hidden methods
    methods (Hidden)
        function this = SPMeasurements
            this.EVM = comm.EVM('XPercentileEVMOutputPort',true,...
                                'MaximumEVMOutputPort',    true,...
                                'XPercentileValue', this.Percentile);
            this.MER = comm.MER('XPercentileMEROutputPort', true,...
                                'MinimumMEROutputPort', true,...
                                'XPercentileValue', this.Percentile);
        end
        %-----------------------------------------------------------------------
        function reset(this)
            reset(this.EVM);
            reset(this.MER);
        end
        %-----------------------------------------------------------------------
        function update(this, y, x)
            [this.RMSEVM, this.MaximumEVM, this.PercentileEVM] = step(this.EVM, y, x);
            [this.MERdB,  this.MinimumEVM, this.PercentileMER] = step(this.MER, y, x);
        end
    end
    
    %===========================================================================
    % Set/Get methods
    methods
        function v = get.RMSEVM(this)
            v = this.RMSEVM;
        end
        %-----------------------------------------------------------------------
        function v = get.MaximumEVM(this)
            v = this.MaximumEVM;
        end
        %-----------------------------------------------------------------------
        function v = get.PercentileEVM(this)
            v = this.PercentileEVM;
        end
        %-----------------------------------------------------------------------
        function v = get.MERdB(this)
            v = this.MERdB;
        end
        %-----------------------------------------------------------------------
        function v = get.MinimumMER(this)
            v = this.MinimumMER;
        end
        %-----------------------------------------------------------------------
        function v = get.PercentileMER(this)
            v = this.PercentileMER;
        end
        %-----------------------------------------------------------------------
        function set.Percentile(this, v)
            this.EVM.Percentile = v;
            this.MER.Percentile = v;
            this.Percentile = v;
        end
    end
end
