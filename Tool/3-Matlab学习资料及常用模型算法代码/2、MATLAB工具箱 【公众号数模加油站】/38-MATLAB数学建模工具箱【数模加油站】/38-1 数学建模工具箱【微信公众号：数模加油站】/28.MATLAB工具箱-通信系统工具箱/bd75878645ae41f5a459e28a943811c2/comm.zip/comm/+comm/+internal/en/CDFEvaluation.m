classdef CDFEvaluation
%CDFEvaluation CDF evaluation class for the measure package

 
%   Copyright 2009-2012 The MathWorks, Inc.

    methods
        function out=CDFEvaluation
            %CDFEvaluation CDF evaluation class for the measure package
        end

        function getNumInputsImpl(in) %#ok<MANU>
        end

        function validateInputsImpl(in) %#ok<MANU>
            % Check input dimensions
        end

    end
    methods (Abstract)
    end
    properties
    end
end
