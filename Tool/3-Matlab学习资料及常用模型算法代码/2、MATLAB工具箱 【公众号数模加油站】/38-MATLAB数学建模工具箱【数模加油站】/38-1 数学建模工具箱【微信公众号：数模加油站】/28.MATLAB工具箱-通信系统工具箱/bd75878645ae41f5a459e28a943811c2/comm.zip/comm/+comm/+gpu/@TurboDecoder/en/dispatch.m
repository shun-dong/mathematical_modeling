%Dispatch table for GPU Turbo Decoder
