function y = exactLLRLogSum(x1, x2)
% Copyright 2011 The MathWorks, Inc.

y = log(x1./x2);
end 