function closefig(h);
%CLOSEFIG  Close figure window for multipath figure object.

%   Copyright 1996-2011 The MathWorks, Inc.
%   $Revision: 1.1.6.5 $  $Date: 2011/05/17 01:47:31 $

h.FigureHandle = [];

% Check to see whether associated with Simulink block.
chan = h.CurrentChannel;
blk = chan.SimulinkBlock;
if ~isempty(blk)
    % Make sure enableProbe menu setting is 0.
    set_param(blk, 'enableProbe', '0');
    chan.PrivateData.EnableProbe = false;
    % The flag is not used and comment it out (g477993, g703156).
    % Set figure closed flag for Simulink.  This is important to avoid the
    % figure opening again during a call to updatestates.    
    % h.SimulinkBlkFigClosedFlag = true;
end
