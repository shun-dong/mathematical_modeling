function notifyError(hFig, me)
%NOTIFYERROR Notify the error event to the main GUI
%   NOTIFYERROR(HFIG, ME) finds the main GUI handle in the main GUI figure
%   HGUI by getting the application data of the figure. Then, it calls the
%   error method of the main GUI with MException ME. 

%   Copyright 2008-2012 The MathWorks, Inc.
%   $Revision: 1.1.6.3 $  $Date: 2012/05/15 14:03:27 $

hGui = getappdata(hFig, 'GuiObject');
eyediagramerror(hGui, me); % a local error function. me came from try/catch.

%-------------------------------------------------------------------------------
%[EOF]
