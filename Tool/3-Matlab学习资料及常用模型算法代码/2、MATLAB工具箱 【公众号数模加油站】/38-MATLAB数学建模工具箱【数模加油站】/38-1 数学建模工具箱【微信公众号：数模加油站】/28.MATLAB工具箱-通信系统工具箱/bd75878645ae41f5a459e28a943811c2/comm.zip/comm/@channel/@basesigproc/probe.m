function probe(h)

%   Copyright 1996-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2004/12/10 19:19:07 $

hData = h.PrivateData;

disp('PROBEFCN: NO ACTION');


