function setrates(h, Ts, fc)
%SETRATES  Set sample period and cutoff frequency for source.
%  SETRATES(H, TS, FC) sets the output sample period and cutoff frequency
%  of filtgaussian object H to TS and FC, respectively.  TS is in seconds
%  and FC is in Hertz.  1/TS must be smaller than 100*FC to avoid an overly
%  long filter impulse response.

%   Copyright 1996-2011 The MathWorks, Inc.

if (Ts<=0.0)
    error(message('comm:channel_filtgaussian_setrates:ts'));
end

if (fc<0.0)
    error(message('comm:channel_filtgaussian_setrates:fc'));
end

h.QuasiStatic = any(fc==0);

h.PrivateData.OutputSamplePeriod = Ts;
h.PrivateData.CutoffFrequency = fc;

if ~(h.QuasiStatic)
    N = 1./(Ts.*fc);
    if any(N>100)
        error(message('comm:channel_filtgaussian_setrates:N'));
    end
    h.PrivateData.OversamplingFactor = N;
else
    h.PrivateData.OversamplingFactor = NaN * ones(1,length(fc));
end

if h.Constructed, initialize(h); end
