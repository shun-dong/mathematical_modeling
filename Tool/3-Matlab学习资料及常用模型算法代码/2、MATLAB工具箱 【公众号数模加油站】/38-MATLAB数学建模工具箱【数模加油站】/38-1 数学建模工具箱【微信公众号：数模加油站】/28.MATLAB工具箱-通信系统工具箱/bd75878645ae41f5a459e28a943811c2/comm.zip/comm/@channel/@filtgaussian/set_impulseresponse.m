function IR = set_impulseresponse(h, IR)

%   Copyright 1996-2011 The MathWorks, Inc.

% This method overrides the set method for channel.basefiltgaussian.

check_object_locked(h, 'impulse response');

if h.LockImpulseResponse
    error(message('comm:channel_filtgaussian_set_impulseresponse:ir'));
end

h.PrivateData.ImpulseResponse = IR;
