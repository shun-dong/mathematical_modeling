function z = scalepathgains(chan, z)

%   Copyright 1996-2012 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2012/04/14 03:43:02 $

% Apply path gain factors
APG = chan.AvgPathGainVector;
for colIdx = 1:size(z,2)
    z(:, colIdx) = APG .* z(:, colIdx);
end

% [EOF]