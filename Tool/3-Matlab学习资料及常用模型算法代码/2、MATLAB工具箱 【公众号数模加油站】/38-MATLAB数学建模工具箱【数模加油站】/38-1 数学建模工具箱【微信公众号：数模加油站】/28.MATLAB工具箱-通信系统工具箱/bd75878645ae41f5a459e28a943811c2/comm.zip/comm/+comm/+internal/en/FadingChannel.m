classdef FadingChannel
%FadingChannel Filter input signal through a fading channel

 
% Copyright 2011-2012 The MathWorks, Inc.

    methods
        function out=FadingChannel
            %FadingChannel Filter input signal through a fading channel
        end

        function getNumOutputsImpl(in) %#ok<MANU>
        end

        function isInactivePropertyImpl(in) %#ok<MANU>
            % Use the if-else format for codegen
        end

        function loadObjectImpl(in) %#ok<MANU>
        end

        function resetImpl(in) %#ok<MANU>
        end

        function saveObjectImpl(in) %#ok<MANU>
        end

        function setupImpl(in) %#ok<MANU>
        end

        function setupSQRTCorrelationMatrix(in) %#ok<MANU>
        end

        function stepImpl(in) %#ok<MANU>
        end

        function validateInputsImpl(in) %#ok<MANU>
        end

    end
    methods (Abstract)
    end
    properties
        %NormalizeChannelOutputs Normalize channel outputs
        %   Set this property to true to normalize the channel outputs by the
        %   number of receive antennas. The default value of this property is
        %   true.
        NormalizeChannelOutputs;

        %NormalizePathGains Normalize path gains
        %   Set this property to true to normalize the fading processes such
        %   that the total power of the path gains, averaged over time, is 0dB.
        %   The default value of this property is true.
        NormalizePathGains;

        %PathGainsOutputPort Output channel path gains
        %   Set this property to true to output the channel path gains of the
        %   underlying fading process. The default value of this property is
        %   false.
        PathGainsOutputPort;

        %RandomStream Source of random number stream 
        %   Specify the source of random number stream as one of 'Global
        %   stream' | 'mt19937ar with seed'. If RandomStream is set to 'Global
        %   stream', the current global random number stream is used for
        %   normally distributed random number generation, in which case the
        %   reset method only resets the filters. If RandomStream is set to
        %   'mt19937ar with seed', the mt19937ar algorithm is used for normally
        %   distributed random number generation, in which case the reset
        %   method not only resets the filters but also re-initializes the
        %   random number stream to the value of the Seed property. The default
        %   value of this property is 'Global stream'.
        RandomStream;

        %Seed Initial seed of mt19937ar random number stream
        %   Specify the initial seed of a mt19937ar random number generator
        %   algorithm as a double precision, real, nonnegative integer scalar.
        %   This property applies when you set the RandomStream property to
        %   'mt19937ar with seed'. The Seed is to re-initialize the mt19937ar
        %   random number stream in the reset method. The default value of this
        %   property is 73.
        Seed;

        % Doppler spectrum that must be in char format for codegen. By default,
        % it is a char string so that codegen works with the default value.
        pDopplerSpectrum;

        % Cutoff frequency factor that is 1 by default for doppler.jakes
        pFcFactor;

        % Uncorrelated spatial correlation flag
        pIsRHIdentity;

        % Polyphase filter length that is a pre-assigned value
        pPolyphaseFilterLength;

        % [NP*NL, NP*NL] block diagonal spatial correlation matrix, for
        % spatially correlated channels only
        pSQRTCorrelationMatrix;

    end
end
