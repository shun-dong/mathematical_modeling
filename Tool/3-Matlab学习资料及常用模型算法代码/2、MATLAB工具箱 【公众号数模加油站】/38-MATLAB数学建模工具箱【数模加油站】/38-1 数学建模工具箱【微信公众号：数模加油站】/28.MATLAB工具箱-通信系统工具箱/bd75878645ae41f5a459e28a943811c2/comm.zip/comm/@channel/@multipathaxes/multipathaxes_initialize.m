function multipathaxes_initialize(h)
%MULTIPATHAXES_INITIALIZE  Initialize multipath axes object.

%   Copyright 1996-2006 The MathWorks, Inc.
%   $Revision: 1.1.6.3 $  $Date: 2006/05/09 23:06:44 $

h.reset;
