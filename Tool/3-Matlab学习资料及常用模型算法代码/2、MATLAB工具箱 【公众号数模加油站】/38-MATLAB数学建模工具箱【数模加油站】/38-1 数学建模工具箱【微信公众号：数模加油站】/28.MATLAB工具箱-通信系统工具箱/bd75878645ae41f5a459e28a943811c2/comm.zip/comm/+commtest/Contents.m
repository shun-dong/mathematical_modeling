%COMMTEST Communications test console package
%   H = COMMTEST.<TYPE>(...) returns a communications test console object H
%   of a particular TYPE. A list of COMMTEST test console objects is given in
%   the following.
%
%   commtest.ErrorRate - Run parallel, parameterized error rate simulations
%
% EXAMPLE: 
%
%   % Construct a communications test console object for error rate
%   % analysis.
%   h = commtest.ErrorRate;

%   Copyright 2009-2010 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2010/11/17 11:03:14 $
