function mpanimateaxes_reset(h)
%MPANIMATEAXES_RESET  Reset axes object.

%   Copyright 1996-2006 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2006/05/09 23:06:27 $

h.multipathaxes_reset;
h.setaxesposition;
