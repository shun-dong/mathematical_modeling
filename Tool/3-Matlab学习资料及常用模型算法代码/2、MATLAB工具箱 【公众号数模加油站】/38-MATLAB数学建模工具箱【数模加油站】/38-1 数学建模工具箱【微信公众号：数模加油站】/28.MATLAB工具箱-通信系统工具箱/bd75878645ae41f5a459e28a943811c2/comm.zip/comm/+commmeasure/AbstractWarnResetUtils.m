classdef (Hidden) AbstractWarnResetUtils < handle
    %AbstractWarnResetUtils Defines AbstractWarnResetUtils abstract class
    %for COMMMEASURE package
    
    %   Copyright 2009-2011 The MathWorks, Inc.

    %======================================================================
    % Protected properties
    %======================================================================    
    properties (Access = protected, Hidden = true)
        %PrivResetFlag Reset flag
        %   Use this flag to signal a reset       
        PrivResetFlag        
    end
    %======================================================================
    % Protected methods
    %======================================================================   
    methods(Access = protected)
    %=====================================================================
    function warnAboutIrrelevantSet(obj,propertyName,class) %#ok<MANU>
        %warnAboutIrrelevantSet Warn about irrelevant set
        %   Warn when the user attempts to set an irrelevant property.
        warning(message('comm:commmeasure:AbstractWarnResetUtils:irrelevantPropertySet', propertyName, class));            
    end
    %=====================================================================
    function warnAboutInvalidStateChange(obj,class) %#ok<MANU>
        %warnAboutInvalidStateChange Warn about invalid state change
        warning(message('comm:commmeasure:AbstractWarnResetUtils:invalidStateChange', class));
    end    
    %=====================================================================
    function checkResetFlagAndReset(obj)
        %checkResetFlagAndReset Check reset flag and reset
        %   Call reset if PrivResetFlag is false.
        if ~obj.PrivResetFlag
            reset(obj);
        end
    end         
    end
end