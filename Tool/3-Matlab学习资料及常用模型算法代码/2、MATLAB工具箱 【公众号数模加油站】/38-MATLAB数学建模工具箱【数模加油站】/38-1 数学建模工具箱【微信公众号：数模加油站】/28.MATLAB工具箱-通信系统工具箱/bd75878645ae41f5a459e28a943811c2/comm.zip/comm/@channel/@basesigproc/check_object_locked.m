function check_object_locked(h, propStr)
%CHECK_OBJECT_LOCKED

%   Copyright 1996-2011 The MathWorks, Inc.

if h.ObjectLocked
    error(message('comm:channel:basesigproc_check_object_locked:ObjectLocked', propStr)); 
end