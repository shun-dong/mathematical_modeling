function initialize(h)
%INITIALIZE  Initialize interpolating-filtered Gaussian source object.

%   Copyright 1996-2011 The MathWorks, Inc.

s = h.FiltGaussian;

if s.NumChannels ~= h.InterpFilter.NumChannels
    error(message('comm:channel_intfiltgaussian_initialize:numchannels'));
end

% Reset source, including random state.
if (legacychannelsim || s.PrivLegacyMode)
    WGNState = 0;
    reset(h, WGNState);
else
    reset(h);
end