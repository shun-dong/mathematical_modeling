function reset(alg)
%RESET  Reset adaptive algorithm object.

%   Copyright 1996-2003 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2004/01/09 17:34:15 $

% No properties to reset for baseclass.

