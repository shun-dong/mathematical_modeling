function reset(chan, randomstate) %#ok<INUSD>
%RESET  Reset channel object.
%   RESET(CHAN) resets the channel object CHAN, initializing the PathGains
%   and NumSamplesProcessed properties as well as internal filter states.
%   This syntax is useful when you want the effect of creating a new
%   channel.
%
%   RESET(CHAN, RANDSTATE) resets the channel object CHAN and initializes
%   the state of the random number generator that the channel uses.
%   RANDSTATE is a two-element column vector or a scalar integer (for more
%   information, type 'help randn').  This syntax is useful when you want to
%   repeat previous numerical results that started from a particular state.
%   RESET(CHAN, RANDSTATE) will not accept RANDSTATE in a future release.  See
%   LEGACYCHANNELSIM function for more information.
%  
%   See also RAYLEIGHCHAN, RICIANCHAN, CHANNEL/FILTER, CHANNEL/PLOT, RANDN,
%            LEGACYCHANNELSIM. 

%   Copyright 1996-2011 The MathWorks, Inc.

error(message('comm:channel_reset:InvalidResetChan'))