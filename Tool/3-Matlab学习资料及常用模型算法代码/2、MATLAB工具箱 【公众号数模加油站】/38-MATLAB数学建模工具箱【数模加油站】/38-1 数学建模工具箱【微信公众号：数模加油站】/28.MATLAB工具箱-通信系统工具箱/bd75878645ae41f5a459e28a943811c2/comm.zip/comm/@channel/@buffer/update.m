function y = update(h, x);
%UPDATE  Buffer update.

%   Copyright 1996-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2004/12/10 19:19:19 $
 
y = buffer_update(h, x);