classdef CRCGenerator
%CRCGenerator Generate CRC code bits and append to input data 
%   H = comm.CRCGenerator creates a cyclic redundancy code (CRC) generator
%   System object, H. This object generates CRC bits according to a
%   specified generator polynomial and appends them to the input data.
%
%   H = comm.CRCGenerator(Name,Value) creates a CRC generator object, H,
%   with the specified property Name set to the specified Value. You can
%   specify additional name-value pair arguments in any order as
%   (Name1,Value1,...,NameN,ValueN).
%
%   H = comm.CRCGenerator(POLY,Name,Value) creates a CRC generator object,
%   H, with the Polynomial property set to POLY, and other specified
%   property Names set to the specified Values.
%
%   Step method syntax:
%
%   Y = step(H,X) generates CRC checksums for an input message X and appends
%   the checksums to X. The input X must be a binary column vector and the
%   data type can be double or logical. The length of output Y is
%   length(X)+P*CheckSumsPerFrame, where P is the order of the polynomial
%   that you specify in the Polynomial property.
%
%   CRCGenerator methods:
%
%   step     - Generate CRC code and append it to the input signal
%              (see above)
%   release  - Allow property value and input characteristics changes
%   clone    - Create CRC generator object with same property values
%   isLocked - Locked status (logical)
%   reset    - Reset states of CRC generator object
%
%   CRCGenerator properties:
%
%   Polynomial        - Generator polynomial
%   InitialConditions - Initial conditions of shift register
%   CheckSumsPerFrame - Number of checksums per input frame
%
%   % Example:
%   %   Encode a signal and then detect the errors
%
%   % Transmit two message words of length 6
%   x = logical([1 0 1 1 0 1 0 1 1 1 0 1]');
%   % Encode the message words using a CRC generator
%   hGen = comm.CRCGenerator([1 0 0 1], 'CheckSumsPerFrame',2);
%   codeword = step(hGen, x);
%   % Add one bit error to each codeword
%   errorPattern = randerr(2,9,1).';
%   codewordWithError = xor(codeword, errorPattern(:)); 
%   % Decode messages with and without errors using a CRC decoder
%   hDetect = comm.CRCDetector([1 0 0 1], 'CheckSumsPerFrame',2);
%   [tx, err] = step(hDetect, codeword); 
%   [tx1, err1] = step(hDetect, codewordWithError);
%   disp(err) % err is [0;0], no errors in transmitted message words
%   disp(err1) % err1 is [1;1], errors in both transmitted message words
%
%   See also comm.CRCDetector.

 
%   Copyright 2008-2011 The MathWorks, Inc.

    methods
        function out=CRCGenerator
            %CRCGenerator Generate CRC code bits and append to input data 
            %   H = comm.CRCGenerator creates a cyclic redundancy code (CRC) generator
            %   System object, H. This object generates CRC bits according to a
            %   specified generator polynomial and appends them to the input data.
            %
            %   H = comm.CRCGenerator(Name,Value) creates a CRC generator object, H,
            %   with the specified property Name set to the specified Value. You can
            %   specify additional name-value pair arguments in any order as
            %   (Name1,Value1,...,NameN,ValueN).
            %
            %   H = comm.CRCGenerator(POLY,Name,Value) creates a CRC generator object,
            %   H, with the Polynomial property set to POLY, and other specified
            %   property Names set to the specified Values.
            %
            %   Step method syntax:
            %
            %   Y = step(H,X) generates CRC checksums for an input message X and appends
            %   the checksums to X. The input X must be a binary column vector and the
            %   data type can be double or logical. The length of output Y is
            %   length(X)+P*CheckSumsPerFrame, where P is the order of the polynomial
            %   that you specify in the Polynomial property.
            %
            %   CRCGenerator methods:
            %
            %   step     - Generate CRC code and append it to the input signal
            %              (see above)
            %   release  - Allow property value and input characteristics changes
            %   clone    - Create CRC generator object with same property values
            %   isLocked - Locked status (logical)
            %   reset    - Reset states of CRC generator object
            %
            %   CRCGenerator properties:
            %
            %   Polynomial        - Generator polynomial
            %   InitialConditions - Initial conditions of shift register
            %   CheckSumsPerFrame - Number of checksums per input frame
            %
            %   % Example:
            %   %   Encode a signal and then detect the errors
            %
            %   % Transmit two message words of length 6
            %   x = logical([1 0 1 1 0 1 0 1 1 1 0 1]');
            %   % Encode the message words using a CRC generator
            %   hGen = comm.CRCGenerator([1 0 0 1], 'CheckSumsPerFrame',2);
            %   codeword = step(hGen, x);
            %   % Add one bit error to each codeword
            %   errorPattern = randerr(2,9,1).';
            %   codewordWithError = xor(codeword, errorPattern(:)); 
            %   % Decode messages with and without errors using a CRC decoder
            %   hDetect = comm.CRCDetector([1 0 0 1], 'CheckSumsPerFrame',2);
            %   [tx, err] = step(hDetect, codeword); 
            %   [tx1, err1] = step(hDetect, codewordWithError);
            %   disp(err) % err is [0;0], no errors in transmitted message words
            %   disp(err1) % err1 is [1;1], errors in both transmitted message words
            %
            %   See also comm.CRCDetector.
        end

        function setPortDataTypeConnections(in) %#ok<MANU>
        end

    end
    methods (Abstract)
    end
    properties
        %CheckSumsPerFrame Number of checksums per input frame
        %   Specify the number of checksums that the object calculates for each
        %   input frame as a positive integer. The default is 1. The integer must
        %   divide the length of each input frame evenly. The object performs the
        %   following steps:
        %     1) Divides each input frame into CheckSumsPerFrame subframes of
        %        equal size.
        %     2) Prefixes the initial conditions vector to each of the
        %        subframes.
        %     3) Applies the CRC algorithm to each augmented subframe.
        %     4) Appends the resulting checksums at the end of each subframe.
        %     5) Outputs concatenated subframes. 
        %
        %   For example, for an input frame size of 10, degree of the generator
        %   polynomial set to 3, InitialConditions property set to 0, and the
        %   CheckSumsPerFrame property set to 2, the object: divides each input
        %   frame into two subframes of size 5 and appends a checksum of size 3 to
        %   each subframe. In this example, the output frame has a size 10 + 2*3 =
        %   16.
        %
        CheckSumsPerFrame;

        %InitialConditions Initial conditions of shift register
        %   Specify the initial conditions of the shift register as a binary,
        %   double or single precision data type scalar or vector. The vector
        %   length is the degree of the generator polynomial that you specify in
        %   the Polynomial property. When you specify initial conditions as a
        %   scalar, the object expands the value to a row vector of length equal
        %   to the degree of the generator polynomial. The default is 0.
        InitialConditions;

        %Polynomial Generator polynomial
        %   Specify the generator polynomial as a binary or integer row vector,
        %   with coefficients in descending order of powers. If you set this
        %   property to a binary vector, its length must be equal to the degree of
        %   the polynomial plus 1. If you set this property to an integer vector,
        %   it contains the powers of the nonzero terms of the polynomial. For
        %   example, [1 0 0 0 0 0 1 0 1] and [8 2 0] represent the same
        %   polynomial, g(z) = z^8 + z^2 + 1.
        %
        %   The following table lists commonly used generator polynomials.
        %   -------------------------------------------------------------------
        %   |CRC method       | Generator polynomial                          |
        %   -------------------------------------------------------------------
        %   |CRC-32           | [32 26 23 22 16 12 11 10 8 7 5 4 2 1 0]       |
        %   |CRC-24           | [24 23 14 12 8 0]                             |
        %   |CRC-16           | [16 15 2 0]                                   |
        %   |Reversed CRC-16  | [16 14 1 0]                                   |
        %   |CRC-8 	          | [8 7 6 4 2 0]                                 |
        %   |CRC-4 	          | [4 3 2 1 0]                                   |
        %   -------------------------------------------------------------------
        %
        %   The default is [1 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 1], which is
        %   equivalent to vector [16 12 5 0].
        Polynomial;

    end
end
