classdef MIMOChannel
%MIMOChannel Filter input signal through a MIMO multipath fading channel
%   H = comm.MIMOChannel creates a multiple-input multiple-output (MIMO)
%   frequency-selective or frequency-flat fading channel System object, H.
%   This object filters a real or complex input signal through the
%   multipath MIMO channel to obtain the channel impaired signal.
%
%   H = comm.MIMOChannel(Name,Value) creates a MIMO channel object, H,
%   with the specified property Name set to the specified Value. You can
%   specify additional name-value pair arguments in any order as
%   (Name1,Value1,...,NameN,ValueN).
%
%   Step method syntax:
%
%   Y = step(H,X) filters input signal X through a MIMO fading channel and
%   returns the result in Y. The input X can be a double precision data
%   type scalar, vector, or 2D matrix with real or complex values. X is of
%   size Ns x Nt, where Ns is the number of samples and Nt is the number of
%   transmit antennas that must match the NumTransmitAntennas property
%   value of H. Y is the output signal of size Ns x Nr, where Nr is the
%   number of receive antennas, i.e., the NumReceiveAntennas property value
%   of H. Y is of double precision data type with complex values.
%  
%   [Y,PATHGAINS] = step(H,X) returns the MIMO channel path gains of the
%   underlying fading process in PATHGAINS. This syntax applies when you
%   set the PathGainsOutputPort property of H to true. PATHGAINS is of size
%   Ns x Np x Nt x Nr, where Np is the number of paths, i.e., the length of
%   the PathDelays property value of H. PATHGAINS is of double precision
%   data type with complex values.
%
%   MIMOChannel methods:
%
%   step     - Filter input signal through a MIMO fading channel (see above)
%   release  - Allow property value and input characteristics changes
%   clone    - Create MIMO channel object with same property values
%   isLocked - Locked status (logical)
%   reset    - Reset states of filters, and random stream if the
%              RandomStream property is set to 'mt19937ar with seed'
%
%   MIMOChannel properties:
%
%   SampleRate                  - Input signal sample rate (Hz)
%   PathDelays                  - Discrete path delay vector (s)
%   AveragePathGains            - Average path gain vector (dB)
%   MaximumDopplerShift         - Maximum Doppler shift (Hz)
%   DopplerSpectrum             - Doppler spectrum object(s)
%   NumTransmitAntennas         - Number of transmit antennas
%   NumReceiveAntennas          - Number of receive antennas    
%   TransmitCorrelationMatrix   - Transmit correlation matrix (or 3-D array)
%   ReceiveCorrelationMatrix    - Receive correlation matrix (or 3-D array)
%   FadingDistribution          - Rayleigh or Rician fading
%   KFactor                     - Rician K-factor scalar or vector (linear scale)
%   DirectPathDopplerShift      - Doppler shift(s) of line-of-sight component(s) (Hz)
%   DirectPathInitialPhase      - Initial phase(s) of line-of-sight component(s) (rad)
%   RandomStream                - Source of random number stream
%   Seed                        - Initial seed of mt19937ar random number stream
%   NormalizePathGains          - Normalize path gains (logical)
%   NormalizeChannelOutputs     - Normalize channel outputs (logical)
%   PathGainsOutputPort         - Enable path gain output (logical)
%
%   % Example: 
%   %   Filter a 1000Hz input signal through a 2x2 Rayleigh
%   %   frequency-selective spatially correlated fading channel with a  
%   %   Jakes Doppler spectrum with a maximum frequency of 5Hz.
%
%   hMod = comm.PSKModulator; 
%   modData = step(hMod, randi([0 hMod.ModulationOrder-1],1e5,1));
%   % Split modulated data into two spatial streams
%   channelInput = reshape(modData, [2, 5e4]).';
%   hMIMOChan = comm.MIMOChannel(...
%       'SampleRate',                1000,...
%       'PathDelays',                [0, 1e-3],...
%       'AveragePathGains',          [3, 5],...
%       'MaximumDopplerShift',       5,...
%       'TransmitCorrelationMatrix', cat(3, eye(2), [1 0.1;0.1 1]),...
%       'ReceiveCorrelationMatrix',  cat(3, [1 0.2;0.2 1], eye(2)),...
%       'RandomStream',              'mt19937ar with seed',...
%       'Seed',                      33,...
%       'NormalizePathGains',        false,...
%       'PathGainsOutputPort',       true);
%   [channelOutput, pathGains] = step(hMIMOChan, channelInput);
%   % Check transmit and receive spatial correlation that should be close
%   % to the values of the TransmitCorrelationMatrix and
%   % ReceiveCorrelationMatrix properties of hMIMOChan, respectively.
%   disp('Tx spatial correlation, first path, first Rx:');
%   disp(corrcoef(squeeze(pathGains(:,1,:,1)))); % Close to an identity matrix
%   disp('Tx spatial correlation, second path, second Rx:');
%   disp(corrcoef(squeeze(pathGains(:,2,:,2)))); % Close to [1 0.1;0.1 1]
%   disp('Rx spatial correlation, first path, second Tx:');
%   disp(corrcoef(squeeze(pathGains(:,1,2,:)))); % Close to [1 0.2;0.2 1]
%   disp('Rx spatial correlation, second path, first Tx:');
%   disp(corrcoef(squeeze(pathGains(:,2,1,:)))); % Close to an identity matrix
%
%   See also comm.LTEMIMOChannel, rayleighchan, ricianchan,
%   comm.AWGNChannel.

 
% Copyright 2011-2012 The MathWorks, Inc.

    methods
        function out=MIMOChannel
            %MIMOChannel Filter input signal through a MIMO multipath fading channel
            %   H = comm.MIMOChannel creates a multiple-input multiple-output (MIMO)
            %   frequency-selective or frequency-flat fading channel System object, H.
            %   This object filters a real or complex input signal through the
            %   multipath MIMO channel to obtain the channel impaired signal.
            %
            %   H = comm.MIMOChannel(Name,Value) creates a MIMO channel object, H,
            %   with the specified property Name set to the specified Value. You can
            %   specify additional name-value pair arguments in any order as
            %   (Name1,Value1,...,NameN,ValueN).
            %
            %   Step method syntax:
            %
            %   Y = step(H,X) filters input signal X through a MIMO fading channel and
            %   returns the result in Y. The input X can be a double precision data
            %   type scalar, vector, or 2D matrix with real or complex values. X is of
            %   size Ns x Nt, where Ns is the number of samples and Nt is the number of
            %   transmit antennas that must match the NumTransmitAntennas property
            %   value of H. Y is the output signal of size Ns x Nr, where Nr is the
            %   number of receive antennas, i.e., the NumReceiveAntennas property value
            %   of H. Y is of double precision data type with complex values.
            %  
            %   [Y,PATHGAINS] = step(H,X) returns the MIMO channel path gains of the
            %   underlying fading process in PATHGAINS. This syntax applies when you
            %   set the PathGainsOutputPort property of H to true. PATHGAINS is of size
            %   Ns x Np x Nt x Nr, where Np is the number of paths, i.e., the length of
            %   the PathDelays property value of H. PATHGAINS is of double precision
            %   data type with complex values.
            %
            %   MIMOChannel methods:
            %
            %   step     - Filter input signal through a MIMO fading channel (see above)
            %   release  - Allow property value and input characteristics changes
            %   clone    - Create MIMO channel object with same property values
            %   isLocked - Locked status (logical)
            %   reset    - Reset states of filters, and random stream if the
            %              RandomStream property is set to 'mt19937ar with seed'
            %
            %   MIMOChannel properties:
            %
            %   SampleRate                  - Input signal sample rate (Hz)
            %   PathDelays                  - Discrete path delay vector (s)
            %   AveragePathGains            - Average path gain vector (dB)
            %   MaximumDopplerShift         - Maximum Doppler shift (Hz)
            %   DopplerSpectrum             - Doppler spectrum object(s)
            %   NumTransmitAntennas         - Number of transmit antennas
            %   NumReceiveAntennas          - Number of receive antennas    
            %   TransmitCorrelationMatrix   - Transmit correlation matrix (or 3-D array)
            %   ReceiveCorrelationMatrix    - Receive correlation matrix (or 3-D array)
            %   FadingDistribution          - Rayleigh or Rician fading
            %   KFactor                     - Rician K-factor scalar or vector (linear scale)
            %   DirectPathDopplerShift      - Doppler shift(s) of line-of-sight component(s) (Hz)
            %   DirectPathInitialPhase      - Initial phase(s) of line-of-sight component(s) (rad)
            %   RandomStream                - Source of random number stream
            %   Seed                        - Initial seed of mt19937ar random number stream
            %   NormalizePathGains          - Normalize path gains (logical)
            %   NormalizeChannelOutputs     - Normalize channel outputs (logical)
            %   PathGainsOutputPort         - Enable path gain output (logical)
            %
            %   % Example: 
            %   %   Filter a 1000Hz input signal through a 2x2 Rayleigh
            %   %   frequency-selective spatially correlated fading channel with a  
            %   %   Jakes Doppler spectrum with a maximum frequency of 5Hz.
            %
            %   hMod = comm.PSKModulator; 
            %   modData = step(hMod, randi([0 hMod.ModulationOrder-1],1e5,1));
            %   % Split modulated data into two spatial streams
            %   channelInput = reshape(modData, [2, 5e4]).';
            %   hMIMOChan = comm.MIMOChannel(...
            %       'SampleRate',                1000,...
            %       'PathDelays',                [0, 1e-3],...
            %       'AveragePathGains',          [3, 5],...
            %       'MaximumDopplerShift',       5,...
            %       'TransmitCorrelationMatrix', cat(3, eye(2), [1 0.1;0.1 1]),...
            %       'ReceiveCorrelationMatrix',  cat(3, [1 0.2;0.2 1], eye(2)),...
            %       'RandomStream',              'mt19937ar with seed',...
            %       'Seed',                      33,...
            %       'NormalizePathGains',        false,...
            %       'PathGainsOutputPort',       true);
            %   [channelOutput, pathGains] = step(hMIMOChan, channelInput);
            %   % Check transmit and receive spatial correlation that should be close
            %   % to the values of the TransmitCorrelationMatrix and
            %   % ReceiveCorrelationMatrix properties of hMIMOChan, respectively.
            %   disp('Tx spatial correlation, first path, first Rx:');
            %   disp(corrcoef(squeeze(pathGains(:,1,:,1)))); % Close to an identity matrix
            %   disp('Tx spatial correlation, second path, second Rx:');
            %   disp(corrcoef(squeeze(pathGains(:,2,:,2)))); % Close to [1 0.1;0.1 1]
            %   disp('Rx spatial correlation, first path, second Tx:');
            %   disp(corrcoef(squeeze(pathGains(:,1,2,:)))); % Close to [1 0.2;0.2 1]
            %   disp('Rx spatial correlation, second path, first Tx:');
            %   disp(corrcoef(squeeze(pathGains(:,2,1,:)))); % Close to an identity matrix
            %
            %   See also comm.LTEMIMOChannel, rayleighchan, ricianchan,
            %   comm.AWGNChannel.
        end

        function loadObjectImpl(in) %#ok<MANU>
        end

        function saveObjectImpl(in) %#ok<MANU>
        end

        function validatePropertiesImpl(in) %#ok<MANU>
        end

    end
    methods (Abstract)
    end
    properties
        %AveragePathGains Average path gains
        %   Specify the average gains of the discrete paths in dB as a double
        %   precision, real, scalar or row vector. AveragePathGains must have
        %   the same size as PathDelays. The default value of this property is
        %   0.
        AveragePathGains;

        %DirectPathDopplerShift Rician channel direct path Doppler shift
        %   Specify the Doppler shift(s) of the line-of-sight component(s) of a
        %   Rician fading channel in Hz as a double precision, real scalar or
        %   row vector. This property applies when you set the
        %   FadingDistribution property to 'Rician'. DirectPathDopplerShift
        %   must have the same size as KFactor. If DirectPathDopplerShift is a
        %   scalar, it is the line-of-sight component Doppler shift of the
        %   first discrete path that is a Rician fading process. If
        %   DirectPathDopplerShift is a row vector, the discrete path that is a
        %   Rician fading process indicated by a positive element of the
        %   KFactor vector has its line-of-sight component Doppler shift
        %   specified by the corresponding element of DirectPathDopplerShift.
        %   The default value of this property is 0.
        DirectPathDopplerShift;

        %DirectPathInitialPhase Rician channel direct path initial phase
        %   Specify the initial phase(s) of the line-of-sight component(s) of a
        %   Rician fading channel in radians as a double precision, real scalar
        %   or row vector. This property applies when you set the
        %   FadingDistribution property to 'Rician'. DirectPathInitialPhase
        %   must have the same size as KFactor. If DirectPathInitialPhase is a
        %   scalar, it is the line-of-sight component initial phase of the
        %   first discrete path that is a Rician fading process. If
        %   DirectPathInitialPhase is a row vector, the discrete path that is a
        %   Rician fading process indicated by a positive element of the
        %   KFactor vector has its line-of-sight component initial phase
        %   specified by the corresponding element of DirectPathInitialPhase.
        %   The default value of this property is 0.
        DirectPathInitialPhase;

        % DopplerSpectrum Doppler spectrum shape
        %   Specify the Doppler spectrum shape for the path(s) of the channel
        %   as a single object from the Doppler spectrum package or a row
        %   vector of such objects. The maximum Doppler shift value necessary
        %   to specify the Doppler spectrum/spectra is given by the
        %   MaximumDopplerShift property. This property applies when the
        %   MaximumDopplerShift property value is greater than 0.
        %   
        %   If DopplerSpectrum is assigned a single Doppler spectrum object,
        %   all paths have the same specified Doppler spectrum. The possible
        %   choices are
        %       doppler.jakes
        %       doppler.flat
        %       doppler.rjakes(...)
        %       doppler.ajakes(...)
        %       doppler.rounded(...)
        %       doppler.bell(...)
        %       doppler.gaussian(...)
        %       doppler.bigaussian(...)
        %   
        %   If DopplerSpectrum is assigned a vector of Doppler spectrum objects
        %   (which can be chosen from any of those listed above), each path has
        %   the Doppler spectrum specified by the corresponding Doppler
        %   spectrum object in the vector. In this case the length of
        %   DopplerSpectrum must be equal to the length of PathDelays.
        %  
        %   The default value of this property is a Jakes Doppler spectrum
        %   object, for which code generation of this object is supported. To
        %   generate code, do not explicitly specify this property.
        DopplerSpectrum;

        %FadingDistribution Fading distribution
        %   Specify the fading distribution of the channel as one of 'Rayleigh'
        %   | 'Rician'. The default value of this property is 'Rayleigh', i.e.,
        %   the channel is Rayleigh fading.
        FadingDistribution;

        %KFactor Rician channel K factor
        %   Specify the K factor of a Rician fading channel as a double
        %   precision, real, positive scalar or nonnegative, non-zero row
        %   vector of the same length as PathDelays. This property applies when
        %   you set the FadingDistribution property to 'Rician'. If KFactor is
        %   a scalar, the first discrete path is a Rician fading process with a
        %   Rician K-factor of KFactor and the remaining discrete paths are
        %   independent Rayleigh fading processes. If KFactor is a row vector,
        %   the discrete path corresponding to a positive element of the
        %   KFactor vector is a Rician fading process with a Rician K-factor
        %   specified by that element and the discrete path corresponding to a
        %   zero-valued element of the KFactor vector is a Rayleigh fading
        %   process. The default value of this property is 3.
        KFactor;

        %MaximumDopplerShift Maximum Doppler shift
        %   Specify the maximum Doppler shift for the path(s) of the channel in
        %   Hz as a double precision, real, nonnegative scalar. It applies to
        %   all the paths of the channel. When MaximumDopplerShift is 0, the
        %   channel is static for the entire input and you can use the reset
        %   method to generate a new channel realization. The
        %   MaximumDopplerShift must be smaller than SampleRate/10/fc for each
        %   path, where fc is the cutoff frequency factor of the path. For a
        %   Doppler spectrum type other than Gaussian and BiGaussian, the value
        %   of fc is 1; Otherwise, the value of fc is dependent on the Doppler
        %   spectrum object properties. Refer to the documentation of this
        %   System object for more details about how fc is defined. The default
        %   value of this property is 0.001.
        MaximumDopplerShift;

        %NumReceiveAntennas Number of receive antennas
        %   Specify the number of receive antennas as a numeric, real, positive
        %   integer scalar between 1 and 8, inclusive. The default value of
        %   this property is 2.
        NumReceiveAntennas;

        %NumTransmitAntennas Number of transmit antennas
        %   Specify the number of transmit antennas as a numeric, real,
        %   positive integer scalar between 1 and 8, inclusive. The default
        %   value of this property is 2.
        NumTransmitAntennas;

        %PathDelays Discrete path delays
        %   Specify the delays of the discrete paths in seconds as a double
        %   precision, real, scalar or row vector. When PathDelays is a scalar,
        %   the channel is frequency-flat; When PathDelays is a vector, the
        %   channel is frequency-selective. The default value of this property
        %   is 0.
        PathDelays;

        %ReceiveCorrelationMatrix Spatial correlation at receiver
        %   Specify the spatial correlation of the receiver as a double
        %   precision, real or complex, 2D matrix or 3D array. If the channel
        %   is frequency-flat, i.e., PathDelays is a scalar,
        %   ReceiveCorrelationMatrix is a 2D Hermitian matrix of size Nr x Nr,
        %   where Nr is the number of receive antennas, i.e., the
        %   NumReceiveAntennas property value. The main diagonal elements must
        %   be all ones, while the off-diagonal elements must be real or
        %   complex numbers with a magnitude smaller than or equal to one.
        %  
        %   If the channel is frequency-selective, i.e., PathDelays is a row
        %   vector of length Np, ReceiveCorrelationMatrix can be specified as
        %   a 2D matrix, in which case each path has the same receive spatial
        %   correlation matrix. Alternatively, it can be specified as a 3-D
        %   array of size Nr x Nr x Np, in which case each path can have its
        %   own different receive spatial correlation matrix.
        % 
        %   The default value of this property is [1 0;0 1].
        ReceiveCorrelationMatrix;

        %SampleRate Sample rate
        %   Specify the sample rate of the input signal in Hz as a double
        %   precision, real, positive scalar. The default value of this
        %   property is 1 Hz.
        SampleRate;

        %TransmitCorrelationMatrix Spatial correlation at transmitter
        %   Specify the spatial correlation of the transmitter as a double
        %   precision, real or complex, 2D matrix or 3D array. If the channel
        %   is frequency-flat, i.e., PathDelays is a scalar,
        %   TransmitCorrelationMatrix is a 2D Hermitian matrix of size Nt x Nt,
        %   where Nt is the number of transmit antennas, i.e., the
        %   NumTransmitAntennas property value. The main diagonal elements must
        %   be all ones, while the off-diagonal elements must be real or
        %   complex numbers with a magnitude smaller than or equal to one.
        %  
        %   If the channel is frequency-selective, i.e., PathDelays is a row
        %   vector of length Np, TransmitCorrelationMatrix can be specified as
        %   a 2D matrix, in which case each path has the same transmit spatial
        %   correlation matrix. Alternatively, it can be specified as a 3-D
        %   array of size Nt x Nt x Np, in which case each path can have its
        %   own different transmit spatial correlation matrix.
        % 
        %   The default value of this property is [1 0;0 1].
        TransmitCorrelationMatrix;

    end
end
