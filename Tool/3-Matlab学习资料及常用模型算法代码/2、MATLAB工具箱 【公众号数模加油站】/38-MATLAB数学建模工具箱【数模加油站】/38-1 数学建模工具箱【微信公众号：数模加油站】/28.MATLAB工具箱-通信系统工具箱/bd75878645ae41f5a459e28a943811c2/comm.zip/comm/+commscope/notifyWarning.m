function notifyWarning(hFig, me)
%NOTIFYWARNING Notify the warning event to the main GUI
%   NOTIFYWARNING(HFIG, ME) finds the main GUI handle in the main GUI figure
%   HGUI by getting the application data of the figure. Then, it calls the
%   warning method of the main GUI with MException ME. 

%   Copyright 2008-2012 The MathWorks, Inc.
%   $Revision: 1.1.6.3 $  $Date: 2012/05/15 14:03:28 $

hGui = getappdata(hFig, 'GuiObject');
eyediagramwarning(hGui, me);  % a local warning function. me came from Exception

%-------------------------------------------------------------------------------
%[EOF]
