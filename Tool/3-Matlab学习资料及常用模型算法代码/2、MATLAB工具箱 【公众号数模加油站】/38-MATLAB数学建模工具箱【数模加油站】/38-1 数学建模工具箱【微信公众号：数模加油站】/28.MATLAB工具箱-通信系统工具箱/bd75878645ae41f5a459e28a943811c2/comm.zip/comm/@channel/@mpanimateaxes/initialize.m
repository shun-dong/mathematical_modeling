function initialize(h);
%INITIALIZE  Initialize multipath animation axes object.

%   Copyright 1996-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2004/12/10 19:20:01 $

h.mpanimateaxes_initialize;
