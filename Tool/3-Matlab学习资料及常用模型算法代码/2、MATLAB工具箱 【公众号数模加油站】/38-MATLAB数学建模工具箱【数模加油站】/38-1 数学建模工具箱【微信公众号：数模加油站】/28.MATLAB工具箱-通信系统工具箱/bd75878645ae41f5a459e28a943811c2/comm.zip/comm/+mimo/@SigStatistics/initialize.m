function initialize(h)

%   Copyright 2008 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2008/10/31 05:55:18 $

% Reset buffer.  This method also flushes buffer.
reset(h);


