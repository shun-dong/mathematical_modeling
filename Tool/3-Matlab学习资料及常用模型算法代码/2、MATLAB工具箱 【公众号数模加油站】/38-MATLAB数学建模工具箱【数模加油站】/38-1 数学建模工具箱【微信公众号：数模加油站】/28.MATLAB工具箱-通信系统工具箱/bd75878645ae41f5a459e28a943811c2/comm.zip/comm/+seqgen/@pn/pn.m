classdef pn     
%ERROR: seqgen.pn has been removed. Use comm.PNSequence instead.
%    
    methods
        function obj = pn(varargin)
            error(message('comm:seqgen:pn:pn:DeprecatedFunction'));
        end
    end
end
