function reset(alg)
%RESET  Reset adaptive algorithm object.
%  RESET(ALG) resets the adaptive algorithm object ALG, initializing all
%  states.  
%  
%   See also LMS, SIGNLMS, NORMLMS, VARLMS, RLS, CMA, DFE, EQUALIZE,
%   EQUALIZER/RESET.

%   Copyright 1996-2011 The MathWorks, Inc.

error(message('comm:adaptalg_reset:InvalidResetAlg'));