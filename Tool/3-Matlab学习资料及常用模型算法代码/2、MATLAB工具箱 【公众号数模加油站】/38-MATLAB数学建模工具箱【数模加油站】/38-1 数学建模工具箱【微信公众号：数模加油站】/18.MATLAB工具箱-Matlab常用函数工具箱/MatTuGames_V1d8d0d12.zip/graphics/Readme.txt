Testing the graphic installation can be accomplished by the Matlab script: 

>> testcase_graphics  
