%MDWT -- Multi-dimension Wavelet Toolbox

%It's compatible with MATHWORKS Wavelet Toolbox in functions' name and usage.
%Some of functions make use of part of source code in MATHWORKS Wavelet Toolbox.
%Thanks the origin authers for their excellent work.
%This new toolbox can be used dependent of origin one 
%if you wish supply wavelet filter's data youself.
%Surely with the help of MATHWORKS Wavelet Toolbox the power will be doubled.

%Contents
%===============================================
%VERSION.M
%COPYING.M
%MDWT.M
%convnd.m
%convndcut.m
%dyaddownnd.m
%dyadupnd.m
%dwtnd1.m
%dwtndn.m
%wavedecnd.m
%idwtnd1.m
%idwtndn.m
%iwaverecnd.m
%packup.m
%fitscale.m
%show3d.m
%===============================================

