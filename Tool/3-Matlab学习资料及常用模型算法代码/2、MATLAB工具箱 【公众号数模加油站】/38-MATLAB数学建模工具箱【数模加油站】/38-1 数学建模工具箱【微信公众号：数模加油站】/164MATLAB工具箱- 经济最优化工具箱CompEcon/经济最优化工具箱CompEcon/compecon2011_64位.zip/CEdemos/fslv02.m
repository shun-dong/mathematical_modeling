function [f,d] = f1(x)
f = exp(-x)-1;
d = -exp(-x);
