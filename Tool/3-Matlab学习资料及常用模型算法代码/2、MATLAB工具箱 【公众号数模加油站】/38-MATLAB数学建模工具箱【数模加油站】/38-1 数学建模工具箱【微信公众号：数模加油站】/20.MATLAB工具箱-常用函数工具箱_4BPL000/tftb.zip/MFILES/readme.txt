These files are either new ones or improved versions of previous files.
They improve the efficiency of the time frequency toolbox.

For this, put the following files in the following subdirectories of the toolbox :

anaqpsk        mfiles
correlmx.m     mfiles
demotfrparam.m demos
imextrac.m     mfiles
instfreq.m     mfiles
noisecu.m      mfiles
parafrep.m     mfiles
tfrqview.m     mfiles
tfrmh.m        mfiles
tfrmhs.m       mfiles
tfrpage.m      mfiles
tfrparam.m     mfiles
tfrpmh.m       mfiles
tfrppage.m     mfiles
tfrqview.m     mfiles
tfrri.m        mfiles
tfrsp.m        mfiles
tfrstft.m      mfiles
tfrsurf.m      mfiles
tfrview.m      mfiles

