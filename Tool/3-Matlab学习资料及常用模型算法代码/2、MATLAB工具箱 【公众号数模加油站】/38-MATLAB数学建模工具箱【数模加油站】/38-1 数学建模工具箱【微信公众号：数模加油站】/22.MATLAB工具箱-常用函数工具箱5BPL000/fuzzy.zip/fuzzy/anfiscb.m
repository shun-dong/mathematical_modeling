% Copyright (c) 1994-98 by The MathWorks, Inc.
% $Revision: 1.2 $
function anfiscb()
StopHndl=findobj('Tag', 'StopBtn');
set(StopHndl, 'String', 'Stop');

