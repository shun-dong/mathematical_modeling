/***********************************************************************
 Parameterized membership functions
 **********************************************************************/
/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

/* Triangular membership function */
static double
#ifdef __STDC__
fisTriangleMf(double x, double *para)
#else
fisTriangleMf(x, para)
double x, *para;
#endif
{
	double a = para[0], b = para[1], c = para[2];

	if (a>b)
		fisError("Illegal parameters in fisTriangleMf() --> a > b");
	if (b>c)
		fisError("Illegal parameters in fisTriangleMf() --> b > c");

	if (a == b && b == c)
		return(x == a);
	if (a == b)
		return((c-x)/(c-b)*(b<=x)*(x<=c));
	if (b == c)
		return((x-a)/(b-a)*(a<=x)*(x<=b));
	return(MAX(MIN((x-a)/(b-a), (c-x)/(c-b)), 0));
}

/* Trapezpoidal membership function */
static double
#ifdef __STDC__
fisTrapezoidMf(double x, double *para)
#else
fisTrapezoidMf(x, para)
double x, *para;
#endif
{
	double a = para[0], b = para[1], c = para[2], d = para[3];
	double y1 = 0, y2 = 0;

	if (a>b) {
#ifndef NO_PRINTF
		printf("a = %f, b = %f, c = %f, d = %f\n", a, b, c, d);
#endif
		fisError("Illegal parameters in fisTrapezoidMf() --> a >= b");
	}
	if (c>d) {
#ifndef NO_PRINTF
		printf("a = %f, b = %f, c = %f, d = %f\n", a, b, c, d);
#endif
		fisError("Illegal parameters in fisTrapezoidMf() --> c >= d");
	}

	if (b <= x)
		y1 = 1;
	else if (x < a)
		y1 = 0;
	else if (a != b)
		y1 = (x-a)/(b-a);

	if (x <= c)
		y2 = 1;
	else if (d < x)
		y2 = 0;
	else if (c != d)
		y2 = (d-x)/(d-c);

	return(MIN(y1, y2));
	/*
	if (a == b && c == d)
		return((b<=x)*(x<=c));
	if (a == b)
		return(MIN(1, (d-x)/(d-c))*(b<=x)*(x<=d));
	if (c == d)
		return(MIN((x-a)/(b-a), 1)*(a<=x)*(x<=c));
	return(MAX(MIN(MIN((x-a)/(b-a), 1), (d-x)/(d-c)), 0));
	*/
}

/* Gaussian membership function */
static double
#ifdef __STDC__
fisGaussianMf(double x, double *para)
#else
fisGaussianMf(x, para)
double x, *para;
#endif
{
	double sigma = para[0], c = para[1];
	double tmp;

	if (sigma==0)
		fisError("Illegal parameters in fisGaussianMF() --> sigma = 0");
	tmp = (x-c)/sigma;
	return(exp(-tmp*tmp/2));
}

/* Extended Gaussian membership function */
static double
#ifdef __STDC__
fisGaussian2Mf(double x, double *para)
#else
fisGaussian2Mf(x, para)
double x, *para;
#endif
{
	double sigma1 = para[0], c1 = para[1];
	double sigma2 = para[2], c2 = para[3];
	double tmp1, tmp2;

	if ((sigma1 == 0) || (sigma2 == 0))
		fisError("Illegal parameters in fisGaussian2MF() --> sigma1 or sigma2 is zero");

	tmp1 = x >= c1? 1:exp(-pow((x-c1)/sigma1, 2.0)/2);
	tmp2 = x <= c2? 1:exp(-pow((x-c2)/sigma2, 2.0)/2);
	return(tmp1*tmp2);
}

/* Sigmoidal membership function */
static double
#ifdef __STDC__
fisSigmoidMf(double x, double *para)
#else
fisSigmoidMf(x, para)
double x, *para;
#endif
{
	double a = para[0], c = para[1];
	return(1/(1+exp(-a*(x-c))));
}

/* Product of two sigmoidal functions */
static double
#ifdef __STDC__
fisProductSigmoidMf(double x, double *para)
#else
fisProductSigmoidMf(x, para)
double x, *para;
#endif
{
	double a1 = para[0], c1 = para[1], a2 = para[2], c2 = para[3];
	double tmp1 = 1/(1+exp(-a1*(x-c1)));
	double tmp2 = 1/(1+exp(-a2*(x-c2)));
	return(tmp1*tmp2);
}

/* Absolute difference of two sigmoidal functions */
static double
#ifdef __STDC__
fisDifferenceSigmoidMf(double x, double *para)
#else
fisDifferenceSigmoidMf(x, para)
double x, *para;
#endif
{
	double a1 = para[0], c1 = para[1], a2 = para[2], c2 = para[3];
	double tmp1 = 1/(1+exp(-a1*(x-c1)));
	double tmp2 = 1/(1+exp(-a2*(x-c2)));
	return(fabs(tmp1-tmp2));
}

/* Generalized bell membership function */
static double
#ifdef __STDC__
fisGeneralizedBellMf(double x, double *para)
#else
fisGeneralizedBellMf(x, para)
double x, *para;
#endif
{
	double a = para[0], b = para[1], c = para[2];
	double tmp;
	if (a==0)
		fisError("Illegal parameters in fisGeneralizedBellMf() --> a = 0");
	tmp = pow((x-c)/a, 2.0);
	if (tmp == 0 && b == 0)
		return(0.5);
	else if (tmp == 0 && b < 0)
		return(0.0);
	else
		return(1/(1+pow(tmp, b)));
}

/* S membership function */
static double
#ifdef __STDC__
fisSMf(double x, double *para)
#else
fisSMf(x, para)
double x, *para;
#endif
{
	double a = para[0], b = para[1];
	double out;

	if (a >= b)
		return(x >= (a+b)/2);

	if (x <= a)
		out = 0;
	else if (x <= (a + b)/2)
		out = 2*pow((x-a)/(b-a), 2.0);
	else if (x <= b)
		out = 1-2*pow((b-x)/(b-a), 2.0);
	else
		out = 1;
	return(out);
}

/* Z membership function */
static double
#ifdef __STDC__
fisZMf(double x, double *para)
#else
fisZMf(x, para)
double x, *para;
#endif
{
	double a = para[0], b = para[1];
	double out;

	if (a >= b)
		return(x <= (a+b)/2);

	if (x <= a)
		out = 1;
	else if (x <= (a + b)/2)
		out = 1 - 2*pow((x-a)/(b-a), 2.0);
	else if (x <= b)
		out = 2*pow((b-x)/(b-a), 2.0);
	else
		out = 0;
	return(out);
}

/* pi membership function */
static double
#ifdef __STDC__
fisPiMf(double x, double *para)
#else
fisPiMf(x, para)
double x, *para;
#endif
{
	return(fisSMf(x, para)*fisZMf(x, para+2));
}

/* all membership function */
static double
#ifdef __STDC__
fisAllMf(double x, double *para)
#else
fisAllMf(x, para)
double x, *para;
#endif
{
	return(1);
}

/* returns the number of parameters of MF */
static int
#ifdef __STDC__
fisGetMfParaN(char *mfType)
#else
fisGetMfParaN(mfType)
char *mfType;
#endif
{
	if (strcmp(mfType, "trimf") == 0)
		return(3);
	if (strcmp(mfType, "trapmf") == 0)
		return(4);
	if (strcmp(mfType, "gaussmf") == 0)
		return(2);
	if (strcmp(mfType, "gauss2mf") == 0)
		return(4);
	if (strcmp(mfType, "sigmf") == 0)
		return(2);
	if (strcmp(mfType, "dsigmf") == 0)
		return(4);
	if (strcmp(mfType, "psigmf") == 0)
		return(4);
	if (strcmp(mfType, "gbellmf") == 0)
		return(3);
	if (strcmp(mfType, "smf") == 0)
		return(2);
	if (strcmp(mfType, "zmf") == 0)
		return(2);
	if (strcmp(mfType, "pimf") == 0)
		return(4);
#ifndef NO_PRINTF
	printf("Given MF type (%s) is unknown.\n", mfType);
#endif
	exit(1);
	return(0);	/* get rid of compiler warning */
}
