function display(mf)
% Display function for membership function objects
% Copyright (c) 1994-98 by The MathWorks, Inc.
% $Revision: 1.2 $
plot(mf.x,mf.y)
