/***********************************************************************
 File, arrays, matrices operations 
 **********************************************************************/
/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

/* display error message and exit */
static void
#ifdef __STDC__
fisError(char *msg)
#else
fisError(msg)
char *msg;
#endif
{
#ifdef MATLAB_MEX_FILE
	mexErrMsgTxt(msg);
#else
#ifndef NO_PRINTF
	printf(msg);
	printf("\n");
#endif
exit(1);
#endif
}

#ifndef NO_PRINTF         /*in case for rtw and dSPACE use */

/* an friendly interface to fopen() */
static FILE *
#ifdef __STDC__
fisOpenFile(char *file, char *mode)
#else
fisOpenFile(file, mode)
char *file;
char *mode;
#endif
{
	FILE *fp, *fopen();

	if ((fp = fopen(file, mode)) == NULL){
		printf("The file '%s'", file);
		fisError(" cannot be opened.\n");
	}
	return(fp);
}

#endif


char **
#ifdef __STDC__
fisCreateMatrix(int row_n, int col_n, int element_size)
#else
fisCreateMatrix(row_n, col_n, element_size)
int row_n;
int col_n;
int element_size;
#endif
{
	char **matrix;
	int i;

	if (row_n == 0 && col_n == 0)
		return(NULL);

	matrix = (char **)calloc(row_n, sizeof(char *));
	if (matrix == NULL)
		fisError("calloc error in fisCreateMatrix!");
	for (i = 0; i < row_n; i++) { 
		matrix[i] = (char *)calloc(col_n, element_size);
		if (matrix[i] == NULL)
			fisError("calloc error in fisCreateMatrix!");
	}
	return(matrix);
}

/* won't complain if given matrix is already freed */
static void
#ifdef __STDC__
fisFreeMatrix(void **matrix, int row_n)
#else
fisFreeMatrix(matrix, row_n)
void **matrix;
int row_n;
#endif
{
	int i;
	if (matrix != NULL) {
		for (i = 0; i < row_n; i++) {
			/*
			printf("i = %d\n", i);
			*/
			free(matrix[i]);
			/*
			matrix[i] = NULL;
			*/
		}
		free(matrix);
	}
}

/* complain if given matrix is already freed */
/*
static void
#ifdef __STDC__
fisFreeMatrix(void **matrix, int row_n)
#else
fisFreeMatrix(matrix, row_n)
void **matrix;
int row_n;
#endif
{
        int i;
        for (i = 0; i < row_n; i++) 
                if (matrix[i] == NULL)
#ifndef NO_PRINTF
                        printf("fisFreeMatrix: row %d is already free!\n", i);
#endif

                else {
                        free(matrix[i]);
                        matrix[i] = NULL;
                }

        if (matrix == NULL)
#ifndef NO_PRINTF
                printf("fisFreeMatrix: given matrix is already free!\n");
#endif
        else {
                free(matrix);
                matrix = NULL;
        }
}
*/

static double**
#ifdef __STDC__
fisCopyMatrix(double **source, int row_n, int col_n)
#else
fisCopyMatrix(source, row_n, col_n)
double **source;
int row_n;
int col_n;
#endif
{
	double **target;
	int i, j;

	target = (double **)fisCreateMatrix(row_n, col_n, sizeof(double));
	for (i = 0; i < row_n; i++)
		for (j = 0; j < col_n; j++)
			target[i][j] = source[i][j];
	return(target);
}

#ifndef NO_PRINTF        /* for rtw and dSPACE */
static void 
#ifdef __STDC__
fisPrintMatrix(double **matrix, int row_n, int col_n)
#else
fisPrintMatrix(matrix, row_n, col_n)
double **matrix;
int row_n;
int col_n;
#endif
{
	int i, j;
	for (i = 0; i < row_n; i++) {
		for (j = 0; j < col_n; j++)
			printf("%.3f ", matrix[i][j]);
		printf("\n");
	}
}

#endif

#ifndef NO_PRINTF   /* for dSPACE use */
static void
#ifdef __STDC__
fisPrintArray(double *array, int size)
#else
fisPrintArray(array, size)
double *array;
int size;
#endif
{
	int i;
	for (i = 0; i < size; i++)
		printf("%.3f ", array[i]);
	printf("\n");
}

#endif

#ifndef NO_PRINTF
static void
fisPause()
{
	printf("Hit RETURN to continue ...\n");
	getc(stdin);
}

#endif
