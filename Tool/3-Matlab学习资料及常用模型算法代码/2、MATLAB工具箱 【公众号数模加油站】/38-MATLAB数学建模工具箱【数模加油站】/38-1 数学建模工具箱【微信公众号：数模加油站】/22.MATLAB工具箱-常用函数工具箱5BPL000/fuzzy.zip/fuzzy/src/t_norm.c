/***********************************************************************
 T-norm and T-conorm operators
 **********************************************************************/
/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

static double
#ifdef __STDC__
fisMin(double x, double y)
#else
fisMin(x, y)
double x, y;
#endif
{return((x) < (y) ? (x) : (y));}

static double
#ifdef __STDC__
fisMax(double x, double y)
#else
fisMax(x, y)
double x, y;
#endif
{return((x) > (y) ? (x) : (y));}

static double
#ifdef __STDC__
fisProduct(double x, double y)
#else
fisProduct(x, y)
double x, y;
#endif
{return(x*y);} 

static double
#ifdef __STDC__
fisProbOr(double x, double y)
#else
fisProbOr(x, y)
double x, y;
#endif
{return(x + y - x*y);} 

static double
#ifdef __STDC__
fisSum(double x, double y)
#else
fisSum(x, y)
double x, y;
#endif
{return(x + y);} 

/* apply given function to an array */
static double
#ifdef __STDC__
fisArrayOperation(double *array, int size, double (*fcn)())
#else
fisArrayOperation(array, size, fcn)
double *array;
int size;
double (*fcn)();
#endif
{
	int i;
	double out;

	if (size == 0)
		fisError("Given size is zero!");

	out = array[0];
	for (i = 1; i < size; i++)
		out = (*fcn)(out, array[i]);
	return(out);
}
