/*
 * SIMULINK MEX S-function for fuzzy controllers
 * J.-S. Roger Jang, 1994.
 * Copyright (c) 1994-98 by The MathWorks, Inc.
 * $Revision: $  $Date: $  
 */

/*
 * Syntax  [sys, x0] = sffis(t, x, u, flag, FISMATRIX)
 */

/*
 * The following #define is used to specify the name of this S-Function.
 */
#define S_FUNCTION_NAME sffis

#include <stdio.h>	/* needed for declaration of sprintf */
#include <stdlib.h>	/* needed for declaration of calloc */

/*
 * need to include simstruc.h for the definition of the SimStruct and
 * its associated macro definitions.
 */
#include "simstruc.h"
/* For RTW */
#if defined(RT) || defined(NRT)  

#define __MEX_H__ /* don't include mex.h */

#undef  mexCallMATLAB
#define mexCallMATLAB(a,b,c,d,e) \
    fisError("User-defined functions for FLT are not allowed in RTW!\n");

#undef  mexPrintf
#define mexPrintf printf

#endif
/* Includes other FIS files */ 
#include "fis.h"
#include "lib.c"
#include "mf.c"
#include "t_norm.c"
#include "defuzz.c"
#include "callml.c"
#include "list.c"
#include "list2.c"
#include "evaluate.c"
#include "mt2ceval.c"

/*
 * Defines for easy access to the FIS matrix that are passed in
 */
#define FISMATRIX	ssGetSFcnParam(S,0)

/*
 * mdlInitializeSizes - initialize the sizes array
 */

static void mdlInitializeSizes(SimStruct *S)
{
	double *tmp;
	int in_n, out_n;
        mxArray *fispointer;


	if (ssGetNumArgs(S) == 1) {
           fispointer=mxGetField(FISMATRIX, 0,"input");
	   in_n = mxGetN(fispointer);
	   fispointer=mxGetField(FISMATRIX, 0,"output");
           out_n = mxGetN(fispointer);

		ssSetNumContStates(S, 0);	/* no. of continuous states */
		ssSetNumDiscStates(S, 0);	/* no. of discrete states */
		ssSetNumInputs(S, in_n);	/* no. of inputs */
		ssSetNumOutputs(S, out_n);	/* no. of outputs */
		ssSetDirectFeedThrough(S, 1);	/* direct feedthrough flag */
		ssSetNumSampleTimes(S, 1);	/* no. of sample times */
		ssSetNumInputArgs(S, 1);	/* no. of input arguments */
		ssSetNumRWork(S, 0);	/* no. of real work vector elements */
		ssSetNumIWork(S, 0);	/* no. of int. work vector elements */
		ssSetNumPWork(S, 1);	/* no. of ptr. work vector elements */
                ssSetNumModes(S, 0);            /* number of mode work vector elements   */
                ssSetNumNonsampledZCs(S, 0);    /* number of nonsampled zero crossings   */
                ssSetOptions(S, 0);             /* general options (SS_OPTION_xx)        */
					/* This is the FIS pointer */
	} else {
#ifdef MATLAB_MEX_FILE
	    mexErrMsgTxt("Need FIS matrix as an additional input.");
#endif
	}
}

/*
 * mdlInitializeSampleTimes - initialize the sample times array
 *
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTimeEvent(S, 0, INHERITED_SAMPLE_TIME);
    ssSetOffsetTimeEvent(S, 0, 0.0);
}

/*
 * mdlInitializeConditions - initialize the states
 *
 * In this function, you should initialize the continuous and discrete
 * states for your S-function block.  The initial states are placed
 * in the x0 variable.  You can also perform any other initialization
 * activities that your S-function may require.
 */
static void mdlInitializeConditions(double *x0, SimStruct *S)
{
	int m, n, i, j;
	FIS *fis;


	/* Create FIS node */
	fis = (FIS *)calloc(1, sizeof(FIS));
	/*fisBuildFisNode(fis, FISMATRIX, n);*/
   /*======use Structure=======*/
   fis=matlab2cStr(FISMATRIX, 101);

	fis->next = NULL;

	
	/* Set fis as the Pwork for this S function */
	ssGetPWork(S)[0] = fis;
}

/*
 * mdlOutputs - compute the outputs (y)
 */
static void mdlOutputs(real_T *y, const real_T *x, const real_T *u, 
                       SimStruct *S, int_T tid)
{
	FIS *fis; /* obtained from Pwork */
	int_T j;

	fis = (FIS *)ssGetPWork(S)[0];

	/* Dispatch the inputs */
	for (j = 0; j < fis->in_n; j++)
		fis->input[j]->value = u[j];
	/* Compute the output */
	fisEvaluate(fis, 101);
	/* Collect the output */
	for (j = 0; j < fis->out_n; j++)
		y[j] = fis->output[j]->value;
}

/*
 * mdlUpdate - perform action at major integration time step
 *
 * This function is called once for every major integration time step.
 * Discrete states are typically updated here, but this function is useful
 * for performing any tasks that should only take place once per integration
 * step.
 */
static void mdlUpdate(real_T *x, const real_T *u, SimStruct *S, int_T tid)
{
}

/*
 * mdlDerivatives - compute the derivatives (dx)
 */
static void mdlDerivatives(real_T *dx, const real_T *x, const real_T *u, 
                           SimStruct *S, int_T tid)
{
}

/*
 * mdlTerminate - called when the simulation is terminated.
 */
static void mdlTerminate(SimStruct *S)
{
	FIS *fis; /* obtained from Pwork */

	fis = (FIS *)ssGetPWork(S)[0];
	fisFreeFisNode(fis);
}

#ifdef	MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
