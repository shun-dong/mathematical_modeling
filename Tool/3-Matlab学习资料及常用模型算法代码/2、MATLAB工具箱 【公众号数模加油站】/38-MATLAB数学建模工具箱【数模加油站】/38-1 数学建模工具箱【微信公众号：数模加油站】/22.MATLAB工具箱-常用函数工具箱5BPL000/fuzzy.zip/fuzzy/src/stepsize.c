/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: 1.5 $  $Date: 1997/12/01 21:45:52 $  $Author: moler $ */

/* return 1 if the step size needs to be increased, 0 otherwise */
int 
#ifdef __STDC__
anfisCheckIncreaseSs(double *error_array, int last_change, int current)
#else
anfisCheckIncreaseSs(error_array, last_change, current)
double *error_array;
int last_change, current;
#endif
{
	if (current - last_change < 4)
		return(0);
	if ((error_array[current]     < error_array[current - 1]) &&
	    (error_array[current - 1] < error_array[current - 2]) &&
	    (error_array[current - 2] < error_array[current - 3]) &&
	    (error_array[current - 3] < error_array[current - 4])) 
		return(1);
	return(0);
}

/* return 1 if the step size needs to be decreased, 0 otherwise */
int 
#ifdef __STDC__
anfisCheckDecreaseSs(double *error_array, int last_change, int current)
#else
anfisCheckDecreaseSs(error_array, last_change, current)
double *error_array;
int last_change, current;
#endif
{
	if (current - last_change < 4)
		return(0);
	if ((error_array[current]     < error_array[current - 1]) &&
	    (error_array[current - 1] > error_array[current - 2]) &&
	    (error_array[current - 2] < error_array[current - 3]) &&
	    (error_array[current - 3] > error_array[current - 4])) 
		return(1);
	return(0);
}

/* update step size */
static void
#ifdef __STDC__
anfisUpdateStepSize(FIS *fis, int i)
#else
anfisUpdateStepSize(fis, i)
FIS *fis;
int i;
#endif
{
	if (anfisCheckDecreaseSs(fis->trn_error, fis->last_dec_ss, i) &&
		fis->ss_dec_rate != 1) {
		fis->ss *= fis->ss_dec_rate;
		if (fis->display_ss)
		printf("Step size decreases to %f after epoch %d.\n", fis->ss, i+1);
		fis->last_dec_ss = i;
		return;
	}

	if (anfisCheckIncreaseSs(fis->trn_error, fis->last_inc_ss, i) &&
		fis->ss_inc_rate != 1) {
		fis->ss *= fis->ss_inc_rate;
		if (fis->display_ss)
		printf("Step size increases to %f after epoch %d.\n", fis->ss, i+1);
		fis->last_inc_ss = i;
		return;
	}
}
