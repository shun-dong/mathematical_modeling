/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

/* strings in a data array are guarded both left and right by 0 */
static int
#ifdef __STDC__
fisGetString(double *data_array, int position, char *string)
#else
fisGetString(data_array, position, string)
double *data_array;
int position;
char *string;
#endif
{
	int i;
	if (!isnan(data_array[position])) {
		printf("data_array[%d] = %lf\n", position, data_array[position]);
		fisError("Given position is not holding an NaN!");
	}
	for (i = position + 1; !isnan(data_array[i]); i++)
		string[i-position-1] = (int)data_array[i];
	string[i-position-1] = '\0';
	return(i+1);
}

static void 
#ifdef __STDC__
fisBuildFisNode(FIS *fis, double *struct_data)
#else
fisBuildFisNode(fis, struct_data)
FIS *fis;
double *struct_data;
#endif
{
	IO *p;
	int i, j, k;
	int *in_mf_n, *out_mf_n;
	IO *first_node, *tmp;
	int next_pos, start;

	next_pos = fisGetString(struct_data, 0, fis->name);
	next_pos = fisGetString(struct_data, next_pos, fis->type); 
	fis->in_n = struct_data[next_pos];
	fis->out_n = struct_data[next_pos+1];

	in_mf_n = (int *)calloc(fis->in_n, sizeof(int));
	start = next_pos + 2;
	for (i = start; i < start + fis->in_n; i++)
		in_mf_n[i - start] = struct_data[i];
	first_node = fisBuildIoList(fis->in_n, in_mf_n);
	free(in_mf_n);
	fis->input = (IO **)calloc(fis->in_n, sizeof(IO *));
	i = 0;
	for (tmp = first_node; tmp != NULL; tmp = tmp->next)
		fis->input[i++] = tmp;

	out_mf_n = (int *)calloc(fis->out_n, sizeof(int));
	start = start + fis->in_n;
	for (i = start; i < start + fis->out_n; i++)
		out_mf_n[i - start] = struct_data[i];
	first_node = fisBuildIoList(fis->out_n, out_mf_n);
	free(out_mf_n);
	fis->output = (IO **)calloc(fis->out_n, sizeof(IO *));
	i = 0;
	for (tmp = first_node; tmp != NULL; tmp = tmp->next)
		fis->output[i++] = tmp;

	start = start + fis->out_n;
	fis->rule_n = struct_data[start];

	next_pos = start + 1;
	next_pos = fisGetString(struct_data, next_pos, fis->andMethod); 
	next_pos = fisGetString(struct_data, next_pos, fis->orMethod); 
	next_pos = fisGetString(struct_data, next_pos, fis->impMethod); 
	next_pos = fisGetString(struct_data, next_pos, fis->aggMethod); 
	next_pos = fisGetString(struct_data, next_pos, fis->defuzzMethod); 

	/* For efficiency, I/O names and MF labels are not stored */
	for (i = 0; i < fis->in_n; i++) {
		fis->input[i]->name[0] = '\0';
		for (j = 0; j < fis->input[i]->mf_n; j++)
			fis->input[i]->mf[j]->label[0] = '\0';
	}
	for (i = 0; i < fis->out_n; i++) {
		fis->output[i]->name[0] = '\0';
		for (j = 0; j < fis->output[i]->mf_n; j++)
			fis->output[i]->mf[j]->label[0] = '\0';
	}

	start = next_pos;
	for (i = start; i < start + fis->in_n; i++) {
		fis->input[i-start]->bound[0] = struct_data[(i-start)*2+start];
		fis->input[i-start]->bound[1] = struct_data[(i-start)*2+start+1];
	}

	start = start + 2*fis->in_n;
	for (i = start; i < start + fis->out_n; i++) {
		fis->output[i-start]->bound[0] = struct_data[(i-start)*2+start];
		fis->output[i-start]->bound[1] = struct_data[(i-start)*2+start+1];
	}

	next_pos = start + 2*fis->out_n;
	for (i = 0; i < fis->in_n; i++)
		for (j = 0; j < fis->input[i]->mf_n; j++)
			next_pos = fisGetString(struct_data, next_pos,
				fis->input[i]->mf[j]->type);

	for (i = 0; i < fis->out_n; i++)
		for (j = 0; j < fis->output[i]->mf_n; j++)
			next_pos = fisGetString(struct_data, next_pos,
				fis->output[i]->mf[j]->type);

	start = next_pos;
	fis->rule_list = (int **)fisCreateMatrix
		(fis->rule_n, fis->in_n + fis->out_n, sizeof(int));
	fis->rule_weight = (double *)calloc(fis->rule_n, sizeof(double));
	fis->and_or = (int *)calloc(fis->rule_n, sizeof(int));
	for (i = 0; i < fis->rule_n; i++) {
		for (j = 0; j < fis->in_n + fis->out_n; j++)
			fis->rule_list[i][j] = (int)struct_data[start++];
		fis->rule_weight[i] = struct_data[start++];
		fis->and_or[i] = (int)struct_data[start++];
	}

	fisAssignMfPointer(fis);
	fisAssignFunctionPointer(fis);
	fis->firing_strength = (double *)calloc(fis->rule_n, sizeof(double));
	fis->rule_output = (double *)calloc(fis->rule_n, sizeof(double));
	fis->fcn_value = (double *)calloc(MF_POINT_N, sizeof(double));
}

static void 
#ifdef __STDC__
fisLoadParameter(FIS *fis, double *para_data)
#else
fisLoadParameter(fis, para_data)
FIS *fis;
double *para_data;
#endif
{
	int start = 0;
	int i, j, k;

	for (i = 0; i < fis->in_n; i++) {
		for (j = 0; j < fis->input[i]->mf_n; j++)
			for (k = 0; k < MF_PARA_N; k++)
				fis->input[i]->mf[j]->para[k] = para_data[start++];
	}

	if (strcmp(fis->type, "mamdani") == 0) {
		for (i = 0; i < fis->out_n; i++)
			for (j = 0; j < fis->output[i]->mf_n; j++) {
				if (fis->load_param != 1)
					fis->output[i]->mf[j]->value_array =
						(double *)calloc(MF_POINT_N, sizeof(double));
				for (k = 0; k < MF_PARA_N; k++)
					fis->output[i]->mf[j]->para[k] = para_data[start++];
			}
		fisComputeOutputMfValueArray(fis);
		fis->load_param = 1;
	} else if (strcmp(fis->type, "sugeno") == 0) {
		for (i = 0; i < fis->out_n; i++)
			for (j = 0; j < fis->output[i]->mf_n; j++) {
				if (fis->load_param != 1)
					fis->output[i]->mf[j]->sugeno_coef =
						(double *)calloc(fis->in_n+1, sizeof(double));
				for (k = 0; k < fis->in_n+1; k++)
					fis->output[i]->mf[j]->sugeno_coef[k] =
						para_data[start++];
			}
		fis->load_param = 1;
	} else
		fisError("Unknown fis type!");
}

/* Returns a FIS pointer if there is a match; otherwise signals error */
static FIS *
#ifdef __STDC__
fisMatchHandle(FIS *head, int handle)
#else
fisMatchHandle(head, handle)
FIS *head;
int handle;
#endif
{
	FIS *p;

	for (p = head; p != NULL; p = p->next)
		if (p->handle == handle)
			break;
	if (p == NULL) {
		printf("Given handle is %d.\n", handle);
		fisError("Cannot find an FIS with this handle.");
	}
	return(p);
}

/* Returns the FIS handle that matches a given name */
/* If more than two are qualified, the largest handle is returned.  */
static FIS *
#ifdef __STDC__
fisMatchName(FIS *head, char *name)
#else
fisMatchName(head, name)
FIS *head;
char *name;
#endif
{
	FIS *p, *matched_p = NULL;

	for (p = head; p != NULL; p = p->next)
		if (strcmp(p->name, name) == 0)
			matched_p = p;
	return(matched_p);
}

static int
#ifdef __STDC__
fisFindMaxHandle(FIS *head)
#else
fisFindMaxHandle(head)
FIS *head;
#endif
{
	FIS *p;
	int max_handle = 0;

	if (head == NULL)
		return(0);

	for (p = head; p != NULL; p = p->next)
		if (p->handle > max_handle)
			max_handle = p->handle;
	return(max_handle);
}
