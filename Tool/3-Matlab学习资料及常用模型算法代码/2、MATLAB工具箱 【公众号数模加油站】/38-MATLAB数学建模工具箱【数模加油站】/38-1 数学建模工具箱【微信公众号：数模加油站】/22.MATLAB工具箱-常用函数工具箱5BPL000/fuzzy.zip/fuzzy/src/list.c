/***********************************************************************
 Data structure: construction, printing, and destruction 
 **********************************************************************/
/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

IO *
#ifdef __STDC__
fisBuildIoList(int node_n, int *mf_n)
#else
fisBuildIoList(node_n, mf_n)
int node_n;
int *mf_n;
#endif
{
	IO *io_list;
	int i, j;

	io_list = (IO *)calloc(node_n, sizeof(MF));
	for (i = 0; i < node_n; i++) {
		io_list[i].mf_n = mf_n[i];
		io_list[i].mf = (MF **)calloc(mf_n[i], sizeof(MF *));
		if (mf_n[i] > 0)	/* check if no MF at all */
			io_list[i].mf[0] = (MF *)calloc(mf_n[i], sizeof(MF));
		for (j = 0; j < mf_n[i]; j++)
			io_list[i].mf[j] = io_list[i].mf[0] + j;
	}
	return(io_list);
}

/* Assign a MF pointer to each MF node based on the MF node's type */
void
#ifdef __STDC__
fisAssignMfPointer(FIS *fis)
#else
fisAssignMfPointer(fis)
FIS *fis;
#endif
{
	int i, j, k, mfTypeN = 13, found;
	MF *mf_node;
#ifdef __STDC__
	struct command {
		char *mfType;
		double (*mfFcn)();
	} dispatch[] = {
		{ "trimf",	fisTriangleMf },
		{ "trapmf",	fisTrapezoidMf },
		{ "gaussmf",	fisGaussianMf },
		{ "gauss2mf",	fisGaussian2Mf },
		{ "sigmf",	fisSigmoidMf },
		{ "dsigmf",	fisDifferenceSigmoidMf },
		{ "psigmf",	fisProductSigmoidMf },
		{ "gbellmf",	fisGeneralizedBellMf },
		{ "smf",	fisSMf },
		{ "zmf",	fisZMf },
		{ "pimf",	fisPiMf },
		{ "linear",	NULL },
		{ "constant",	NULL }
	};
#else
	struct command {
		char mfType[20];
		double (*mfFcn)();
	} dispatch[20];
	
	strcpy(dispatch[0].mfType, "trimf");
	dispatch[0].mfFcn = fisTriangleMf;
	strcpy(dispatch[1].mfType, "trapmf");
	dispatch[1].mfFcn = fisTrapezoidMf;
	strcpy(dispatch[2].mfType, "gaussmf");
	dispatch[2].mfFcn = fisGaussianMf;
	strcpy(dispatch[3].mfType, "gauss2mf");
	dispatch[3].mfFcn = fisGaussian2Mf;
	strcpy(dispatch[4].mfType, "sigmf");
	dispatch[4].mfFcn = fisSigmoidMf;
	strcpy(dispatch[5].mfType, "dsigmf");
	dispatch[5].mfFcn = fisDifferenceSigmoidMf;
	strcpy(dispatch[6].mfType, "psigmf");
	dispatch[6].mfFcn = fisProductSigmoidMf;
	strcpy(dispatch[7].mfType, "gbellmf");
	dispatch[7].mfFcn = fisGeneralizedBellMf;
	strcpy(dispatch[8].mfType, "smf");
	dispatch[8].mfFcn = fisSMf;
	strcpy(dispatch[9].mfType, "zmf");
	dispatch[9].mfFcn = fisZMf;
	strcpy(dispatch[10].mfType, "pimf");
	dispatch[10].mfFcn = fisPiMf;
	strcpy(dispatch[11].mfType, "linear");
	dispatch[11].mfFcn = NULL;
	strcpy(dispatch[12].mfType, "constant");
	dispatch[12].mfFcn = NULL;
#endif

	/* input MF's */
	for (i = 0; i < fis->in_n; i++)
		for (j = 0; j < fis->input[i]->mf_n; j++) {
			mf_node = fis->input[i]->mf[j];
			found = 0;
			for (k = 0; k < mfTypeN-2; k++) {
				if (strcmp(mf_node->type, dispatch[k].mfType) == 0) {
					mf_node->mfFcn = dispatch[k].mfFcn;
					found = 1;
					break;
				}
			}
			if (found == 0) {
#ifdef MATLAB_MEX_FILE
			{
				double function_type;
				function_type = fisCallMatlabExist(mf_node->type);
				if (function_type == 0) {
					printf("MF '%s' does not exist!\n", mf_node->type);
					fisError("Exiting ...");
				}
				if (function_type == 1) {
					printf("MF '%s' is a MATLAB variable!\n", mf_node->type);
					fisError("Exiting ...");
				}
				mf_node->userDefined = 1;
			}
#else
#ifndef NO_PRINTF
				printf("MF type '%s' for input %d is unknown.\n",
					mf_node->type, i+1);
				printf("Legal input MF types: ");
				for (i = 0; i < mfTypeN-2; i++)
					printf("%s ", dispatch[i].mfType);
				/*
				printf("\n\nIf '%s' is a customized MF, use M-file command FISEVAL1 or FISEVAL2 instead.\n", mf_node->type);
				*/
				printf("\n");
#endif
				fisError("\n");
#endif
			}
		}

	/* output MF's */
	for (i = 0; i < fis->out_n; i++)
		for (j = 0; j < fis->output[i]->mf_n; j++) {
			mf_node = fis->output[i]->mf[j];
			found = 0;
			for (k = 0; k < mfTypeN; k++) {
				if (strcmp(mf_node->type, dispatch[k].mfType) == 0) {
					mf_node->mfFcn = dispatch[k].mfFcn;
					found = 1;
					break;
				}
			}
			if (found == 0) {
#ifdef MATLAB_MEX_FILE
			{
				double function_type;
				function_type = fisCallMatlabExist(mf_node->type);
				if (function_type == 0) {
					printf("MATLAB function '%s' does not exist!\n", mf_node->type);
					fisError("Exiting ...");
				}
				if (function_type == 1) {
					printf("'%s' is a MATLAB variable!\n", mf_node->type);
					fisError("Exiting ...");
				}
				mf_node->userDefined = 1;
			}
#else
#ifndef NO_PRINTF
				printf("MF type '%s' for output %d is unknown.\n",
					mf_node->type, i+1);
				printf("Legal output MF types: ");
				for (i = 0; i < mfTypeN-1; i++)
					printf("%s ", dispatch[i].mfType);
				/*
				printf("\n\nIf '%s' is a customized MF, use M-file command FISEVAL1 or FISEVAL2 instead.\n", mf_node->type);
				*/
				printf("\n");
#endif
				fisError("\n");
#endif
			}
		}
}

/* Assign a other function pointers */
void
#ifdef __STDC__
fisAssignFunctionPointer(FIS *fis)
#else
fisAssignFunctionPointer(fis)
FIS *fis;
#endif
{
	/* assign andMethod function pointer */
	if (strcmp(fis->andMethod, "prod") == 0)
		fis->andFcn = fisProduct;
	else if (strcmp(fis->andMethod, "min") == 0)
		fis->andFcn = fisMin;
	else {
#ifdef MATLAB_MEX_FILE
	{
		double function_type;
		function_type = fisCallMatlabExist(fis->andMethod);
		if (function_type == 0) {
			printf("AND function '%s' does not exist!\n", fis->andMethod);
			fisError("Exiting ...");
		}
		if (function_type == 1) {
			printf("AND function '%s' is a MATLAB variable!\n", fis->andMethod);
			fisError("Exiting ...");
		}
		fis->userDefinedAnd = 1;
	}
#else
#ifndef NO_PRINTF
		printf("Given andMethod %s is unknown.\n", fis->andMethod);
#endif
		fisError("Legal andMethod: min, prod");
#endif
	}

	/* assign orMethod function pointer */
	if (strcmp(fis->orMethod, "probor") == 0)
		fis->orFcn = fisProbOr;
	else if (strcmp(fis->orMethod, "max") == 0)
		fis->orFcn = fisMax;
	else {
#ifdef MATLAB_MEX_FILE
	{
		double function_type;
		function_type = fisCallMatlabExist(fis->orMethod);
		if (function_type == 0) {
			printf("OR function '%s' does not exist!\n", fis->orMethod);
			fisError("Exiting ...");
		}
		if (function_type == 1) {
			printf("OR function '%s' is a MATLAB variable!\n", fis->orMethod);
			fisError("Exiting ...");
		}
		fis->userDefinedOr = 1;
	}
#else
#ifndef NO_PRINTF
		printf("Given orMethod %s is unknown.\n", fis->orMethod);
#endif
		fisError("Legal orMethod: max, probor");
#endif
	}

	/* assign impMethod function pointer */
	if (strcmp(fis->impMethod, "prod") == 0)
		fis->impFcn = fisProduct;
	else if (strcmp(fis->impMethod, "min") == 0)
		fis->impFcn = fisMin;
	else {
#ifdef MATLAB_MEX_FILE
	{
		double function_type;
		function_type = fisCallMatlabExist(fis->impMethod);
		if (function_type == 0) {
			printf("IMPLICATION function '%s' does not exist!\n", fis->impMethod);
			fisError("Exiting ...");
		}
		if (function_type == 1) {
			printf("IMPLICATION function '%s' is a MATLAB variable!\n", fis->impMethod);
			fisError("Exiting ...");
		}
		fis->userDefinedImp = 1;
	}
#else
#ifndef NO_PRINTF
		printf("Given impMethod %s is unknown.\n", fis->impMethod);
#endif
		fisError("Legal impMethod: min, prod");
#endif
	}

	/* assign aggMethod function pointer */
	if (strcmp(fis->aggMethod, "max") == 0)
		fis->aggFcn = fisMax;
	else if (strcmp(fis->aggMethod, "probor") == 0)
		fis->aggFcn = fisProbOr;
	else if (strcmp(fis->aggMethod, "sum") == 0)
		fis->aggFcn = fisSum;
	else {
#ifdef MATLAB_MEX_FILE
	{
		double function_type;
		function_type = fisCallMatlabExist(fis->aggMethod);
		if (function_type == 0) {
			printf("AGGREGATE function '%s' does not exist!\n", fis->aggMethod);
			fisError("Exiting ...");
		}
		if (function_type == 1) {
			printf("AGGREGATE function '%s' is a MATLAB variable!\n", fis->aggMethod);
			fisError("Exiting ...");
		}
		fis->userDefinedAgg = 1;
	}
#else
#ifndef NO_PRINTF
		printf("Given aggMethod %s is unknown.\n", fis->aggMethod);
#endif
		fisError("Legal aggMethod: max, probor, sum");
#endif
	}

	/* assign defuzzification function pointer */
	if (strcmp(fis->defuzzMethod, "centroid") == 0)
		fis->defuzzFcn = defuzzCentroid;
	else if (strcmp(fis->defuzzMethod, "bisector") == 0)
		fis->defuzzFcn = defuzzBisector;
	else if (strcmp(fis->defuzzMethod, "mom") == 0)
		fis->defuzzFcn = defuzzMeanOfMax;
	else if (strcmp(fis->defuzzMethod, "som") == 0)
		fis->defuzzFcn = defuzzSmallestOfMax;
	else if (strcmp(fis->defuzzMethod, "lom") == 0)
		fis->defuzzFcn = defuzzLargestOfMax;
	else if (strcmp(fis->defuzzMethod, "wtaver") == 0)
		;
	else if (strcmp(fis->defuzzMethod, "wtsum") == 0)
		;
	else {
#ifdef MATLAB_MEX_FILE
	{
		double function_type;
		function_type = fisCallMatlabExist(fis->defuzzMethod);
		if (function_type == 0) {
			printf("DEFUZZIFICATION function '%s' does not exist!\n", fis->defuzzMethod);
			fisError("Exiting ...");
		}
		if (function_type == 1) {
			printf("DEFUZZIFICATION function '%s' is a MATLAB variable!\n", fis->defuzzMethod);
			fisError("Exiting ...");
		}
		fis->userDefinedDefuzz = 1;
	}
#else
#ifndef NO_PRINTF
		printf("Given defuzzification method %s is unknown.\n", fis->defuzzMethod);
#endif
		fisError("Legal defuzzification methods: centroid, bisector, mom, som, lom, wtaver, wtsum");
#endif
	}
}

#ifndef NO_PRINTF
static void
#ifdef __STDC__
fisPrintData(FIS *fis)
#else
fisPrintData(fis)
FIS *fis;
#endif
{
	int i, j, k;

	if (fis == NULL)
		fisError("Given fis pointer is NULL, no data to print!");

	printf("fis_name = %s\n", fis->name);
	printf("fis_type = %s\n", fis->type);
	printf("in_n = %d\n", fis->in_n);
	printf("out_n = %d\n", fis->out_n);

	printf("in_mf_n: ");
	for (i = 0; i < fis->in_n; i++)
		printf("%d ", fis->input[i]->mf_n);
	printf("\n");

	printf("out_mf_n: ");
	for (i = 0; i < fis->out_n; i++)
		printf("%d ", fis->output[i]->mf_n);
	printf("\n");

	printf("rule_n = %d\n", fis->rule_n);

	printf("andMethod = %s\n", fis->andMethod);
	printf("orMethod = %s\n", fis->orMethod);
	printf("impMethod = %s\n", fis->impMethod);
	printf("aggMethod = %s\n", fis->aggMethod);
	printf("defuzzMethod = %s\n", fis->defuzzMethod);

	/*
	for (i = 0; i < fis->in_n; i++) {
		printf("Input variable %d = %s\n", i+1, fis->input[i]->name);
		for (j = 0; j < fis->input[i]->mf_n; j++)
			printf("\t Label for MF %d = %s\n", j+1, fis->input[i]->mf[j]->label);
	}

	for (i = 0; i < fis->out_n; i++) {
		printf("Output variable %d = %s\n", i+1, fis->output[i]->name);
		for (j = 0; j < fis->output[i]->mf_n; j++)
			printf("\t Label for MF %d = %s\n", j+1, fis->output[i]->mf[j]->label);
	}
	*/

	for (i = 0; i < fis->in_n; i++)
		printf("Bounds for input variable %d: [%6.3f %6.3f]\n", i+1,
			fis->input[i]->bound[0], fis->input[i]->bound[1]);

	for (i = 0; i < fis->out_n; i++)
		printf("Bounds for output variable %d: [%6.3f %6.3f]\n", i+1,
			fis->output[i]->bound[0], fis->output[i]->bound[1]);

	for (i = 0; i < fis->in_n; i++) {
		printf("MF for input variable %d (%s):\n", i+1, fis->input[i]->name);
		for (j = 0; j < fis->input[i]->mf_n; j++)
			printf("\t Type for MF %d = %s\n", j+1, fis->input[i]->mf[j]->type);
	}

	for (i = 0; i < fis->out_n; i++) {
		printf("MF for output variable %d (%s):\n", i+1, fis->output[i]->name);
		for (j = 0; j < fis->output[i]->mf_n; j++)
			printf("\t Type for MF %d = %s\n", j+1, fis->output[i]->mf[j]->type);
	}

	printf("Rule list:\n");
	for (i = 0; i < fis->rule_n; i++) {
		for (j = 0; j < fis->in_n + fis->out_n; j++)
			printf("%d ", fis->rule_list[i][j]);
		printf("\n");
	}

	printf("Rule weights:\n");
	for (i = 0; i < fis->rule_n; i++)
		printf("%f\n", fis->rule_weight[i]);

	printf("AND-OR indicator:\n");
	for (i = 0; i < fis->rule_n; i++)
		printf("%d\n", fis->and_or[i]);

	for (i = 0; i < fis->in_n; i++) {
		printf("MF parameters for input variable %d (%s):\n",
			i+1, fis->input[i]->name);
		for (j = 0; j < fis->input[i]->mf_n; j++) {
			printf("\tParameters for MF %d (%s) (%s): ",
				j+1, fis->input[i]->mf[j]->label,
				fis->input[i]->mf[j]->type);
			for (k = 0; k < MF_PARA_N; k++)
				printf("%6.3f ", fis->input[i]->mf[j]->para[k]);
			printf("\n");
		}
	}
	if (strcmp(fis->type, "mamdani") == 0) {
		for (i = 0; i < fis->out_n; i++) {
			printf("MF parameters for output variable %d (%s):\n",
				i+1, fis->output[i]->name);
			for (j = 0; j < fis->output[i]->mf_n; j++) {
				printf("\tParameters for MF %d (%s) (%s): ",
					j+1, fis->output[i]->mf[j]->label,
					fis->output[i]->mf[j]->type);
				for (k = 0; k < MF_PARA_N; k++)
					printf("%6.3f ", fis->output[i]->mf[j]->para[k]);
				printf("\n");
			}
		}
	} else if (strcmp(fis->type, "sugeno") == 0) {
		for (i = 0; i < fis->out_n; i++) {
			printf("Sugeno model parameters for output variable %d (%s):\n",
				i+1, fis->output[i]->name);
			for (j = 0; j < fis->output[i]->mf_n; j++) {
				printf("\tSugeno model parameters for list %d (%s) (%s): ",
					j+1, fis->output[i]->mf[j]->label,
					fis->output[i]->mf[j]->type);
				for (k = 0; k < fis->in_n + 1; k++)
					printf("%6.3f ", fis->output[i]->mf[j]->sugeno_coef[k]);
				printf("\n");
			}
		}
	} else {
		printf("fis->type = %s\n", fis->type);
		fisError("Unknown fis type!");
	}
}
#endif


static void
#ifdef __STDC__
fisFreeMfList(MF *mf_list, int n)
#else
fisFreeMfList(mf_list, n)
MF *mf_list;
int n;
#endif
{
	int i;

	for (i = 0; i < n; i++) {
		free(mf_list[i].sugeno_coef);
		free(mf_list[i].value_array);
	}
	free(mf_list);
}

static void
#ifdef __STDC__
fisFreeIoList(IO *io_list, int n)
#else
fisFreeIoList(io_list, n)
IO *io_list;
int n;
#endif
{
	int i;
	for (i = 0; i < n; i++) {
		if (io_list[i].mf_n > 0)	/* check if no MF at all */
			fisFreeMfList(io_list[i].mf[0], io_list[i].mf_n);
		free(io_list[i].mf);
	}
	free(io_list);
}

void
#ifdef __STDC__
fisFreeFisNode(FIS *fis)
#else
fisFreeFisNode(fis)
FIS *fis;
#endif
{
	if (fis == NULL)
		return;
	fisFreeIoList(fis->input[0], fis->in_n);
	free(fis->input);
	fisFreeIoList(fis->output[0], fis->out_n);
	free(fis->output);
#ifdef FREEMAT
	FREEMAT((void **)fis->rule_list, fis->rule_n);
#else
	fisFreeMatrix((void **)fis->rule_list, fis->rule_n);
#endif
	free(fis->rule_weight);
	free(fis->and_or);
	free(fis->firing_strength);
	free(fis->rule_output);
	free(fis->BigOutMfMatrix);
	free(fis->BigWeightMatrix);
	free(fis->mfs_of_rule);
	free(fis);
}

/* Compute arrays of MF values (for Mamdani model only) */
/* This is done whenever new parameters are loaded */
void
#ifdef __STDC__
fisComputeOutputMfValueArray(FIS *fis, int numofpoints)
#else
fisComputeOutputMfValueArray(fis)
FIS *fis;
int numofpoints
#endif
{
	int i, j, k;
	double x, lx, ux, dx;
	MF *mf_node;

	for (i = 0; i < fis->out_n; i++) {
		lx = fis->output[i]->bound[0];
		ux = fis->output[i]->bound[1];
		dx = (ux - lx)/(numofpoints - 1);
		for (j = 0; j < fis->output[i]->mf_n; j++) {
			mf_node = fis->output[i]->mf[j];
			if (!mf_node->userDefined)
				for (k = 0; k < numofpoints; k++) {
					x = lx + k*dx;
					mf_node->value_array[k] =
					(*mf_node->mfFcn)(x, mf_node->para);
				}
			else { 	/* user defined MF */
#ifdef MATLAB_MEX_FILE
				/* this is non-vector version */
				/*
				for (k = 0; k < numofpoints; k++) {
					x = lx + k*dx;
					mf_node->value_array[k] =
					fisCallMatlabMf(x, mf_node->para,
					mf_node->type);
				}
				*/
				/* this is vector version */
				{
                		double *X;
                                X = (double *)calloc(numofpoints, sizeof(double));
			/*	double X[numofpoints]; */
				for (k = 0; k < numofpoints; k++)
					X[k] = lx + k*dx;
				fisCallMatlabMf2(X, mf_node->para,
				mf_node->type, numofpoints, mf_node->value_array);
                                free(X);
				}
#else
#ifndef NO_PRINTF
				printf("Cannot find MF type %s!\n", mf_node->type);
#endif
				fisError("Exiting ...");
#endif
			}
		}
	}
}

























