/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: 1.7 $ */

#ifdef MATLAB_MEX_FILE
FIS *matlab2cStr(const mxArray *matlabmat, int numofpoints)
{
        mxArray *fispointer, *inputpointer, *mfpointer;
        char *buf;
	int i, j,k, param_size, data_n, in_n;
	FIS *fis;

        int status, buflen=100;	
        int io_vector_size;
        double *real_data_ptr;
	int *in_mf_n, *out_mf_n;
	IO *io_list;

	/*----------- Create FIS node -------------------*/
        buf=mxCalloc(buflen, sizeof(char));
        /* get fis name, type, ....*/
        fis = (FIS *)calloc(1, sizeof(FIS));
        fispointer=mxGetField(matlabmat, 0,"name");
        status=mxGetString(fispointer, fis->name, buflen);

        /* fis->type */
        fispointer=mxGetField(matlabmat, 0,"type");
        status=mxGetString(fispointer, fis->type, buflen);
        if (status!=0)
           fisError("Can not get fis type");
        /* fis->andMethod */
        fispointer=mxGetField(matlabmat, 0,"andMethod");
        status=mxGetString(fispointer, fis->andMethod, buflen);
        if (status!=0)
           fisError("Can not get fis andMethod");
        /* fis->orMethod */
        fispointer=mxGetField(matlabmat, 0,"orMethod");
        status=mxGetString(fispointer, fis->orMethod, buflen);
        if (status!=0)
           fisError("Can not get fis orMethod");
        /* fis->defuzzMethod */
        fispointer=mxGetField(matlabmat, 0,"defuzzMethod");
        status=mxGetString(fispointer, fis->defuzzMethod, buflen);
        if (status!=0)
           fisError("Can not get fis defuzzMethod");
        /* fis->impMethod */
        fispointer=mxGetField(matlabmat, 0,"impMethod");
        status=mxGetString(fispointer, fis->impMethod, buflen);
        if (status!=0)
           fisError("Can not get fis impMethod");
        /* fis->aggMethod */
        fispointer=mxGetField(matlabmat, 0,"aggMethod");
        status=mxGetString(fispointer, fis->aggMethod, buflen);
        if (status!=0)
           fisError("Can not get fis aggMethod");

        fispointer=mxGetField(matlabmat, 0,"input");
	io_vector_size = mxGetN(fispointer);
	fis->in_n=io_vector_size;
	fis->input = (IO **)calloc(io_vector_size, sizeof(IO *));
       
	/* create input node list, each in_mf_n's element containts the number of mf */
	in_mf_n = (int *)calloc(fis->in_n, sizeof(int));
	for (i = 0; i < fis->in_n; i++){
           inputpointer=mxGetField(fispointer, i, "mf"); 
           if (inputpointer!=NULL)
            in_mf_n[i]=mxGetN(inputpointer);
           else
            in_mf_n[i]=0;
        }
	io_list = fisBuildIoList(fis->in_n, in_mf_n);
       
	free(in_mf_n);
	fis->input = (IO **)calloc(fis->in_n, sizeof(IO *));
	for (i = 0; i < fis->in_n; i++)
		fis->input[i] = io_list+i;
        /*finished input memory allocation */

	for(i=0; i<fis->in_n; i++){
          inputpointer=mxGetField(fispointer, i, "name");
          status=mxGetString(inputpointer, fis->input[i]->name, buflen);

          inputpointer=mxGetField(fispointer, i, "range");
          real_data_ptr=(double *)mxGetPr(inputpointer);
          fis->input[i]->bound[0]=*real_data_ptr;
          fis->input[i]->bound[1]=*(real_data_ptr+1);

          inputpointer=mxGetField(fispointer, i, "mf");
          if (inputpointer!=NULL)
            fis->input[i]->mf_n=mxGetN(inputpointer);
          else
            fis->input[i]->mf_n=0;
          for(j=0; j<fis->input[i]->mf_n; j++){
             mfpointer=mxGetField(inputpointer, j, "name");
             status=mxGetString(mfpointer, fis->input[i]->mf[j]->label, buflen);
             mfpointer=mxGetField(inputpointer, j, "type");
             status=mxGetString(mfpointer, fis->input[i]->mf[j]->type, buflen);
             mfpointer=mxGetField(inputpointer, j, "params");
             param_size=mxGetN(mfpointer);
             real_data_ptr=(double *)mxGetPr(mfpointer);
             for(k=0; k<param_size; k++){
               fis->input[i]->mf[j]->para[k]=*real_data_ptr++;
	     }
          }      
        }
	/*output*/
        fispointer=mxGetField(matlabmat, 0,"output");
	io_vector_size = mxGetN(fispointer);
	fis->out_n=io_vector_size;

	/* create output node list, each in_mf_n's element containts the number of mf */
	out_mf_n = (int *)calloc(fis->out_n, sizeof(int));
	for (i = 0; i < fis->out_n; i++){
                inputpointer=mxGetField(fispointer, i, "mf"); 
		out_mf_n[i]=mxGetN(inputpointer);
        }
	io_list = fisBuildIoList(fis->out_n, out_mf_n);
	free(out_mf_n); 
	fis->output = (IO **)calloc(fis->out_n, sizeof(IO *));
	for (i = 0; i < fis->out_n; i++)
		fis->output[i] = io_list+i;
        /*finished output memory allocation */
	
	for(i=0; i<fis->out_n; i++){
          inputpointer=mxGetField(fispointer, i, "name");
          status=mxGetString(inputpointer, fis->output[i]->name, buflen);

          inputpointer=mxGetField(fispointer, i, "range");
          real_data_ptr=(double *)mxGetPr(inputpointer);
          fis->output[i]->bound[0]=*real_data_ptr;
          fis->output[i]->bound[1]=*(real_data_ptr+1);

          inputpointer=mxGetField(fispointer, i, "mf");
          if (inputpointer!=NULL)
           fis->output[i]->mf_n=mxGetN(inputpointer);
          else
           fis->output[i]->mf_n=0;
          for(j=0; j<fis->output[i]->mf_n; j++){
             mfpointer=mxGetField(inputpointer, j, "name");
             status=mxGetString(mfpointer, fis->output[i]->mf[j]->label, buflen);
             mfpointer=mxGetField(inputpointer, j, "type");
             status=mxGetString(mfpointer, fis->output[i]->mf[j]->type, buflen);
             mfpointer=mxGetField(inputpointer, j, "params");
             param_size=mxGetN(mfpointer);
             real_data_ptr=(double *)mxGetPr(mfpointer);

	     /* get Mamdani output MF parameters and compute MF value array */
	      if (strcmp(fis->type, "mamdani") == 0) {
		  fis->output[i]->mf[j]->value_array =(double *)calloc(numofpoints, sizeof(double)); 	
	          for(k=0; k<param_size; k++)
                   fis->output[i]->mf[j]->para[k]=*real_data_ptr++;
	     /* get Sugeno output equation parameters */
		  } else if (strcmp(fis->type, "sugeno") == 0) {
		      fis->output[i]->mf[j]->sugeno_coef =
					(double *)calloc(fis->in_n+1, sizeof(double));
                     if (strcmp(fis->output[i]->mf[j]->type, "linear") == 0) {
		      for (k = 0; k < fis->in_n+1; k++)
		        fis->output[i]->mf[j]->sugeno_coef[k] =*real_data_ptr++;
                    } else{
		      for (k = 0; k < fis->in_n; k++)
                        fis->output[i]->mf[j]->sugeno_coef[k]=0;
		      fis->output[i]->mf[j]->sugeno_coef[fis->in_n] =*real_data_ptr;
                  }   
                     
	        } else {
#ifndef NO_PRINTF
		printf("fis->type = %s\n", fis->type);
#endif
		fisError("Unknown fis type!");
	     }
          }      
        }

        fispointer=mxGetField(matlabmat, 0,"rule");
        if (fispointer==NULL)
         fis->rule_n=0;
        else
	 fis->rule_n = mxGetN(fispointer);
	fis->rule_list = (int **)fisCreateMatrix(fis->rule_n, fis->in_n + fis->out_n, sizeof(int));
	fis->rule_weight = (double *)calloc(fis->rule_n, sizeof(double));
	fis->and_or = (int *)calloc(fis->rule_n, sizeof(int));
	
	for (i = 0; i < fis->rule_n; i++) {
            inputpointer=mxGetField(fispointer, i, "antecedent");
            real_data_ptr=(double *)mxGetPr(inputpointer);
	    for (j = 0; j < fis->in_n ; j++)
		fis->rule_list[i][j] = *real_data_ptr++;
            inputpointer=mxGetField(fispointer, i, "consequent");
            real_data_ptr=(double *)mxGetPr(inputpointer);
	    for (j = 0; j < fis->out_n ; j++)
		fis->rule_list[i][j+fis->in_n] = *real_data_ptr++;
            inputpointer=mxGetField(fispointer, i, "weight");
            real_data_ptr=(double *)mxGetPr(inputpointer);
	    fis->rule_weight[i] = *real_data_ptr;
            inputpointer=mxGetField(fispointer, i, "connection");
            real_data_ptr=(double *)mxGetPr(inputpointer);
	    fis->and_or[i] =*real_data_ptr; 
	}
		fisAssignMfPointer(fis);
	fisAssignFunctionPointer(fis); 
	fis->firing_strength = (double *)calloc(fis->rule_n, sizeof(double));
	fis->rule_output = (double *)calloc(fis->rule_n, sizeof(double));

	if (strcmp(fis->type, "mamdani") == 0) {
		fis->BigOutMfMatrix = (double *)
			calloc(fis->rule_n*numofpoints, sizeof(double));
		fis->BigWeightMatrix = (double *)
			calloc(fis->rule_n*numofpoints, sizeof(double));
	}
	fis->mfs_of_rule = (double *)calloc(fis->in_n, sizeof(double));
        if (strcmp(fis->type, "mamdani") == 0) {
    	  for (i = 0; i < fis->out_n; i++)
         	fisComputeOutputMfValueArray(fis, numofpoints);
	} 
       	fisCheckDataStructure(fis);

	/*----------finished setting fis structure-------------------*/
	fis->next = NULL;
        return(fis);
}
#else
# define matlab2cStr(matlabmat, numofpoints)  NULL
#endif
