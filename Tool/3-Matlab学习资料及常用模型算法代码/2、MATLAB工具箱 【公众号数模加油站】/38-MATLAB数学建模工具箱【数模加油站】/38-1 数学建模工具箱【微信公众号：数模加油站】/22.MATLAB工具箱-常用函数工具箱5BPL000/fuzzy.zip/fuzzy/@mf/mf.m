function out=mf(x,y)
% MF Fuzzy arithmetics object constructor
%    OUT = MF(X, Y) returns a fuzzy arithmetics object. Fuzzy arithmetics 
%    object overwrites MATLAB '+', '-', '*', and '/' operation with fuzzy
%    arithmetic oprations.
%
%    See also
%        fuzarith

% Copyright (c) 1994-98 by The MathWorks, Inc.
% $Revision: 1.2 $

%use colume vector
if size(x,1)<size(x,2),
    x=x';
end
if size(y,1)<size(y,2),
    y=y';
end
if size(x, 1)~=size(y, 1)
  disp('x and y should have the same size for mf object');
  out=[];
  return
end
out.x=x;
out.y=y;
out = class(out,'mf');
