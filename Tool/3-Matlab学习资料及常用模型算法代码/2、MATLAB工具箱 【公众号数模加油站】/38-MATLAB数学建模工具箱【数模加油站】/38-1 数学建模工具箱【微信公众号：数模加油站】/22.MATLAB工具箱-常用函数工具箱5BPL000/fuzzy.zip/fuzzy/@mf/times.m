% Copyright (c) 1994-98 by The MathWorks, Inc.
% $Revision: 1.2 $
function out=mtimes(mf1,mf2)
out=fuzarith(mf1.x,mf1.y,mf2.y,'prod');
plot(mf1.x,[mf1.y mf2.y mf3.y])
