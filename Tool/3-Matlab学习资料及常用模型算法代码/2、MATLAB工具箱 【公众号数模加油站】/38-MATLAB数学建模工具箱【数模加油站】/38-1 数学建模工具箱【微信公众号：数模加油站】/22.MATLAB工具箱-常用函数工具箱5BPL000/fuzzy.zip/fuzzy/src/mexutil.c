/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

#include "mex.h"

/* transform matlab matrix to C matrix */
static double **
matlab2c(const mxArray *matlabmat)
{
	int m = mxGetM(matlabmat);
	int n = mxGetN(matlabmat);
	double *mat = mxGetPr(matlabmat);
	double **out = (double **)fisCreateMatrix(m, n, sizeof(double));
	int i, j;

	for (i = 0; i < m; i++)
		for(j = 0; j < n; j++)
			out[i][j] = mat[j*m + i];
	return(out);
}

/* transform C matrix to matlab matrix */
static mxArray *
c2matlab(double **cmat, int row_n, int col_n)
{
	mxArray *OUT = mxCreateDoubleMatrix(row_n, col_n, mxREAL);
	double *out = mxGetPr(OUT);
	int i, j;

	for (i = 0; i < row_n; i++)
		for (j = 0; j < col_n; j++)
			out[j*row_n+i] = cmat[i][j];
	return(OUT);
}
