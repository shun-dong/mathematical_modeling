% Copyright (c) 1994-98 by The MathWorks, Inc.
% $Revision: 1.2 $
function out=uminus(mf1)
mf2.x=mf1.x;
mf2.y=1-mf1.y;
plot(mf1.x,[mf1.y mf2.y]);
out=mf(mf2.x,mf2.y);
