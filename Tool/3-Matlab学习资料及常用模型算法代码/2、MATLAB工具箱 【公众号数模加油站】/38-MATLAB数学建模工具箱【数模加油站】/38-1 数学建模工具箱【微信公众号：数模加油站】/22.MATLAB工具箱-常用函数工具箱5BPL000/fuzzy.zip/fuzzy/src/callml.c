/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

#ifdef MATLAB_MEX_FILE
/***********************************************************************
 MATLAB function calls 
 **********************************************************************/

/* V4 --> v5
mxFreeMatrix --> mxDestroyArray
Matrix --> mxArray;
mxCreateFull(*, *, 0) --> mxCreateDoubleMatrix(*, *, mxREAL)
mexCallMATLAB(*, *, prhs, *) --> mexCallMATLAB(*, *, (mxArray **)prhs, *)
*/

/* execute MATLAB MF function, scalar version */
static double
#ifdef __STDC__
fisCallMatlabMf(double x, double *para, char *mf_type)
#else
fisCallMatlabMf(x, para, mf_type)
double x, *para;
char *mf_type;
#endif
{
	int i;
	mxArray *PARA = mxCreateDoubleMatrix(MF_PARA_N, 1, mxREAL);
	mxArray *X = mxCreateDoubleMatrix(1, 1, mxREAL);
	mxArray *OUT;
	double out;
	mxArray *prhs[2];

	/* data transfer */
	for (i = 0; i < MF_PARA_N; i++)
		mxGetPr(PARA)[i] = para[i];
	mxGetPr(X)[0] = x;

	prhs[0] = X; prhs[1] = PARA;
	
	/* call matlab MF function */
	mexCallMATLAB(1, &OUT, 2, (mxArray **)prhs, mf_type);
	out = mxGetScalar(OUT);

	/* free allocated matrix */
	mxDestroyArray(X);
	mxDestroyArray(PARA);
	mxDestroyArray(OUT);

	/* return output */
	return(out);
}

/* execute MATLAB MF function, vector version */
/* this is used in fisComputeOutputMfValueArray() */ 
static void
#ifdef __STDC__
fisCallMatlabMf2(double *x, double *para, char *mf_type, int leng, double *out)
#else
fisCallMatlabMf2(x, para, mf_type, leng, out)
double *x, *para;
char *mf_type;
int leng;
double *out;
#endif
{
	int i;
	mxArray *PARA = mxCreateDoubleMatrix(MF_PARA_N, 1, mxREAL);
	mxArray *X = mxCreateDoubleMatrix(leng, 1, mxREAL);
	mxArray *OUT;
	mxArray *prhs[2];

	/* transfer data in */
	for (i = 0; i < MF_PARA_N; i++)
		mxGetPr(PARA)[i] = para[i];
	for (i = 0; i < leng; i++)
		mxGetPr(X)[i] = x[i];

	prhs[0] = X; prhs[1] = PARA;
	/* call matlab MF function */
	mexCallMATLAB(1, &OUT, 2, (mxArray **)prhs, mf_type);

	/* transfer data out */
	for (i = 0; i < leng; i++)
		out[i] = mxGetPr(OUT)[i]; 

	/* free allocated matrix */
	mxDestroyArray(X);
	mxDestroyArray(PARA);
	mxDestroyArray(OUT);
}

#ifdef MATLAB_MEX_FILE /* This is only for MEX files, not for RTW */
/* use MATLAB 'exist' to check the type of a variable or function */
static double
#ifdef __STDC__
fisCallMatlabExist(char *variable)
#else
fisCallMatlabExist(variable)
char *variable;
#endif
{
	double out;
#ifndef NO_PRINTF
	mxArray *VARIABLE = mxCreateString(variable);
#else
        mxArray *VARIABLE;
#endif
	mxArray *OUT;

	/* call matlab 'exist' */
	mexCallMATLAB(1, &OUT, 1, &VARIABLE, "exist");
	out = mxGetScalar(OUT);

	/* free allocated matrix */
	mxDestroyArray(VARIABLE);
	mxDestroyArray(OUT);

	/*
	printf("%s\n", variable);
	printf("out = %f\n", out);
	*/

	/* return output */
	return(out);
}
#endif

/* execute MATLAB function with a vector input */
/* qualified MATLAB functions are min, sum, max, etc */
static double
#ifdef __STDC__
fisCallMatlabFcn(double *x, int leng, char *func)
#else
fisCallMatlabFcn(x, leng, func)
double *x;
int leng;
char *func;
#endif
{
	double out;
	mxArray *X = mxCreateDoubleMatrix(leng, 1, mxREAL);
	mxArray *OUT;
	int i;

	/* transfer data */
	for (i = 0; i < leng; i++)
		mxGetPr(X)[i] = x[i];

	/* call matlab function */
	mexCallMATLAB(1, &OUT, 1, &X, func);
	out = mxGetScalar(OUT);

	/* free allocated matrix */
	mxDestroyArray(X);
	mxDestroyArray(OUT);

	/* return output */
	return(out);
}

/* execute MATLAB function with a matrix input */
/* qualified MATLAB functions are min, sum, max, etc */
static void
#ifdef __STDC__
fisCallMatlabFcn1(double *x, int m, int n, char *func, double *out)
#else
fisCallMatlabFcn1(x, m, n, func, out)
double *x;
int m, n;
char *func;
double *out;
#endif
{
	mxArray *X, *OUT;
	int i;

	/* allocate memory */
	X = mxCreateDoubleMatrix(m, n, mxREAL);

	/* transfer data in */
	for (i = 0; i < m*n; i++)
		mxGetPr(X)[i] = x[i];

	/* call matlab function */
	mexCallMATLAB(1, &OUT, 1, &X, func);

	/* transfer data out */
	if (m == 1)
		out[0] = mxGetScalar(OUT);
	else
		for (i = 0; i < n; i++)
			out[i] = mxGetPr(OUT)[i]; 

	/* free allocated matrix */
	mxDestroyArray(X);
	mxDestroyArray(OUT);
}

/* execute MATLAB function with two matrix inputs */
/* qualified MATLAB functions are min, sum, max, etc */
static void
#ifdef __STDC__
fisCallMatlabFcn2(double *x, double *y, int m, int n, char *func, double *out)
#else
fisCallMatlabFcn2(x, y, m, n, func, out)
double *x, *y;
int m, n;
char *func;
double *out;
#endif
{
	mxArray *X, *Y, *OUT, *prhs[2];
	int i;

	/* allocate memory */
	X = mxCreateDoubleMatrix(m, n, mxREAL);
	Y = mxCreateDoubleMatrix(m, n, mxREAL);
	prhs[0] = X;
	prhs[1] = Y;

	/* transfer data in */
	for (i = 0; i < m*n; i++) {
		mxGetPr(X)[i] = x[i];
		mxGetPr(Y)[i] = y[i];
	}

	/* call matlab function */
	mexCallMATLAB(1, &OUT, 2, (mxArray **)prhs, func);

	/* transfer data out */
	for (i = 0; i < m*n; i++)
			out[i] = mxGetPr(OUT)[i]; 

	/* free allocated matrix */
	mxDestroyArray(X);
	mxDestroyArray(Y);
	mxDestroyArray(OUT);
}

/* execute MATLAB function for defuzzification */
static double
#ifdef __STDC__
fisCallMatlabDefuzz(double *x, double *mf, int leng, char *defuzz_fcn)
#else
fisCallMatlabDefuzz(x, mf, leng, defuzz_fcn)
double *x, *mf;
int leng;
char *defuzz_fcn;
#endif
{
	double out;
	mxArray *X = mxCreateDoubleMatrix(leng, 1, mxREAL);
	/* MF is used as type word in fis.h */
	/* gcc is ok with MF being used here, but cc needs a different name */
	mxArray *MF_ = mxCreateDoubleMatrix(leng, 1, mxREAL);
	mxArray *OUT;
	mxArray *prhs[2];
	int i;

	/* transfer data */
	for (i = 0; i < leng; i++) {
		mxGetPr(X)[i] = x[i];
		mxGetPr(MF_)[i] = mf[i];
	}

	/* call matlab function */
	prhs[0] = X;
	prhs[1] = MF_;
	mexCallMATLAB(1, &OUT, 2, (mxArray **)prhs, defuzz_fcn);
	out = mxGetScalar(OUT);

	/* free allocated matrix */
	mxDestroyArray(X);
	mxDestroyArray(MF_);
	mxDestroyArray(OUT);

	/* return output */
	return(out);
}
#else

# define fisCallMatlabMf(x,para,mf_type)               /* do nothing */
# define fisCallMatlabMf2(x, para, mf_type, leng, out) /* do nothing */
# define fisCallMatlabExist(variable)                  /* do nothing */
# define fisCallMatlabFcn(x, leng, func)               /* do nothing */
# define fisCallMatlabFcn1(x, m, n, func, out)         /* do nothing */
# define fisCallMatlabFcn2(x, y, m, n, func, out)      /* do nothing */
# define fisCallMatlabDefuzz(x, mf, leng, defuzz_fcn)  /* do nothing */

#endif /* MATLAB_MEX_FILE */
