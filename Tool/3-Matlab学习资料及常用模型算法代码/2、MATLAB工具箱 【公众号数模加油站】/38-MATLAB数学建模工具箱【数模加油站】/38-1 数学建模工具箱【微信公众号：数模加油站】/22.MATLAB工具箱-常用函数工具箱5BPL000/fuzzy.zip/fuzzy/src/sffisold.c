/*
 * SIMULINK MEX S-function for fuzzy controllers
 * J.-S. Roger Jang, 1994.
 * Copyright (c) 1994-98 by The MathWorks, Inc.
 * $Revision: $  $Date: $  
 */

/*
 * Syntax  [sys, x0] = sffis(t, x, u, flag, FISMATRIX)
 */

/*
 * The following #define is used to specify the name of this S-Function.
 */
#define S_FUNCTION_NAME sffis

#include <stdio.h>	/* needed for declaration of sprintf */
#include <stdlib.h>	/* needed for declaration of calloc */

/*
 * need to include simstruc.h for the definition of the SimStruct and
 * its associated macro definitions.
 */
#include "simstruc.h"
/* For RTW */
#if defined(RT) || defined(NRT)  

#define __MEX_H__ /* don't include mex.h */

#undef  mexCallMATLAB
#define mexCallMATLAB(a,b,c,d,e) \
    fisError("User-defined functions for FLT are not allowed in RTW!\n");

#undef  mexPrintf
#define mexPrintf printf

#endif
#ifndef __FIS__
#define __FIS__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/***********************************************************************
 Macros and definitions
 **********************************************************************/

#ifndef ABS
#define ABS(x)   ( (x) > (0) ? (x): (-(x)) )
#endif
#ifndef MAX
#define MAX(x,y) ( (x) > (y) ? (x) : (y) )
#endif
#ifndef MIN
#define MIN(x,y) ( (x) < (y) ? (x) : (y) )
#endif
#define MF_PARA_N 4
#define STR_LEN 500
#define MF_POINT_N 101

/* debugging macros */
/*
#define PRINT(expr) printf(#expr " = %g\n", (double)expr)
#define PRINTMAT(mat,m,n) printf(#mat " = \n"); fisPrintMatrix(mat,m,n)
#define FREEMAT(mat,m) printf("Free " #mat " ...\n"); fisFreeMatrix(mat,m)
#define FREEARRAY(array) printf("Free " #array " ...\n"); free(array)
*/
#define FREEMAT(mat,m) fisFreeMatrix(mat,m)
#define FREEARRAY(array) free(array)

/***********************************************************************
 Data types
 **********************************************************************/

typedef struct fis_node {
	int handle;
	int load_param;
	char name[STR_LEN];
	char type[STR_LEN];
	char andMethod[STR_LEN];
	char orMethod[STR_LEN];
	char impMethod[STR_LEN];
	char aggMethod[STR_LEN];
	char defuzzMethod[STR_LEN];
	int userDefinedAnd;
	int userDefinedOr;
	int userDefinedImp;
	int userDefinedAgg;
	int userDefinedDefuzz;
	int in_n;
	int out_n;
	int rule_n;
	int **rule_list;
	double *rule_weight;
	int *and_or;	/* AND-OR indicator */
	double *firing_strength;
	double *rule_output;
	/* Sugeno: output for each rules */
	/* Mamdani: constrained output MF values of rules */
	struct io_node **input;
	struct io_node **output;
#ifdef __STDC__
	double (*andFcn)(double, double);
	double (*orFcn)(double, double);
	double (*impFcn)(double, double);
	double (*aggFcn)(double, double);
#else
	double (*andFcn)();
	double (*orFcn)();
	double (*impFcn)();
	double (*aggFcn)();
#endif
	double (*defuzzFcn)();
	double *BigOutMfMatrix;	/* used for Mamdani system only */
	double *BigWeightMatrix;/* used for Mamdani system only */
	double *mfs_of_rule;	/* MF values in a rule */
	struct fis_node *next;
} FIS;

typedef struct io_node {
	char name[STR_LEN];
	int mf_n;
	double bound[2];
	double value;
	struct mf_node **mf;
} IO;

typedef struct mf_node {
	char label[STR_LEN];
	char type[STR_LEN];
#ifdef __STDC__
	double (*mfFcn)(double, double *); /* pointer to a mem. fcn */ 
#else
	double (*mfFcn)(); /* pointer to a mem. fcn */ 
#endif
	double para[MF_PARA_N];
	double *sugeno_coef;	/* for Sugeno only */
	double value;		/* for Sugeno only */
	double *value_array;	/* for Mamdani only, array of MF values */
	int userDefined;	/* 1 if the MF is user-defined */
} MF;

#endif /* __FIS__ */
/***********************************************************************
 File, arrays, matrices operations 
 **********************************************************************/
/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

/* display error message and exit */
static void
#ifdef __STDC__
fisError(char *msg)
#else
fisError(msg)
char *msg;
#endif
{
#ifdef MATLAB_MEX_FILE
	mexErrMsgTxt(msg);
#else
#ifndef NO_PRINTF
	printf(msg);
	printf("\n");
#endif
exit(1);
#endif
}

#ifndef NO_PRINTF         /*in case for rtw and dSPACE use */

/* an friendly interface to fopen() */
static FILE *
#ifdef __STDC__
fisOpenFile(char *file, char *mode)
#else
fisOpenFile(file, mode)
char *file;
char *mode;
#endif
{
	FILE *fp, *fopen();

	if ((fp = fopen(file, mode)) == NULL){
		printf("The file '%s'", file);
		fisError(" cannot be opened.\n");
	}
	return(fp);
}

#endif


char **
#ifdef __STDC__
fisCreateMatrix(int row_n, int col_n, int element_size)
#else
fisCreateMatrix(row_n, col_n, element_size)
int row_n;
int col_n;
int element_size;
#endif
{
	char **matrix;
	int i;

	if (row_n == 0 && col_n == 0)
		return(NULL);

	matrix = (char **)calloc(row_n, sizeof(char *));
	if (matrix == NULL)
		fisError("calloc error in fisCreateMatrix!");
	for (i = 0; i < row_n; i++) { 
		matrix[i] = (char *)calloc(col_n, element_size);
		if (matrix[i] == NULL)
			fisError("calloc error in fisCreateMatrix!");
	}
	return(matrix);
}

/* won't complain if given matrix is already freed */
static void
#ifdef __STDC__
fisFreeMatrix(void **matrix, int row_n)
#else
fisFreeMatrix(matrix, row_n)
void **matrix;
int row_n;
#endif
{
	int i;
	if (matrix != NULL) {
		for (i = 0; i < row_n; i++) {
			/*
			printf("i = %d\n", i);
			*/
			free(matrix[i]);
			/*
			matrix[i] = NULL;
			*/
		}
		free(matrix);
	}
}

/* complain if given matrix is already freed */
/*
static void
#ifdef __STDC__
fisFreeMatrix(void **matrix, int row_n)
#else
fisFreeMatrix(matrix, row_n)
void **matrix;
int row_n;
#endif
{
        int i;
        for (i = 0; i < row_n; i++) 
                if (matrix[i] == NULL)
#ifndef NO_PRINTF
                        printf("fisFreeMatrix: row %d is already free!\n", i);
#endif

                else {
                        free(matrix[i]);
                        matrix[i] = NULL;
                }

        if (matrix == NULL)
#ifndef NO_PRINTF
                printf("fisFreeMatrix: given matrix is already free!\n");
#endif
        else {
                free(matrix);
                matrix = NULL;
        }
}
*/

static double**
#ifdef __STDC__
fisCopyMatrix(double **source, int row_n, int col_n)
#else
fisCopyMatrix(source, row_n, col_n)
double **source;
int row_n;
int col_n;
#endif
{
	double **target;
	int i, j;

	target = (double **)fisCreateMatrix(row_n, col_n, sizeof(double));
	for (i = 0; i < row_n; i++)
		for (j = 0; j < col_n; j++)
			target[i][j] = source[i][j];
	return(target);
}

#ifndef NO_PRINTF        /* for rtw and dSPACE */
static void 
#ifdef __STDC__
fisPrintMatrix(double **matrix, int row_n, int col_n)
#else
fisPrintMatrix(matrix, row_n, col_n)
double **matrix;
int row_n;
int col_n;
#endif
{
	int i, j;
	for (i = 0; i < row_n; i++) {
		for (j = 0; j < col_n; j++)
			printf("%.3f ", matrix[i][j]);
		printf("\n");
	}
}

#endif

#ifndef NO_PRINTF   /* for dSPACE use */
static void
#ifdef __STDC__
fisPrintArray(double *array, int size)
#else
fisPrintArray(array, size)
double *array;
int size;
#endif
{
	int i;
	for (i = 0; i < size; i++)
		printf("%.3f ", array[i]);
	printf("\n");
}

#endif

#ifndef NO_PRINTF
static void
fisPause()
{
	printf("Hit RETURN to continue ...\n");
	getc(stdin);
}

#endif
/***********************************************************************
 Parameterized membership functions
 **********************************************************************/
/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

/* Triangular membership function */
static double
#ifdef __STDC__
fisTriangleMf(double x, double *para)
#else
fisTriangleMf(x, para)
double x, *para;
#endif
{
	double a = para[0], b = para[1], c = para[2];

	if (a>b)
		fisError("Illegal parameters in fisTriangleMf() --> a > b");
	if (b>c)
		fisError("Illegal parameters in fisTriangleMf() --> b > c");

	if (a == b && b == c)
		return(x == a);
	if (a == b)
		return((c-x)/(c-b)*(b<=x)*(x<=c));
	if (b == c)
		return((x-a)/(b-a)*(a<=x)*(x<=b));
	return(MAX(MIN((x-a)/(b-a), (c-x)/(c-b)), 0));
}

/* Trapezpoidal membership function */
static double
#ifdef __STDC__
fisTrapezoidMf(double x, double *para)
#else
fisTrapezoidMf(x, para)
double x, *para;
#endif
{
	double a = para[0], b = para[1], c = para[2], d = para[3];
	double y1 = 0, y2 = 0;

	if (a>b) {
#ifndef NO_PRINTF
		printf("a = %f, b = %f, c = %f, d = %f\n", a, b, c, d);
#endif
		fisError("Illegal parameters in fisTrapezoidMf() --> a >= b");
	}
	if (c>d) {
#ifndef NO_PRINTF
		printf("a = %f, b = %f, c = %f, d = %f\n", a, b, c, d);
#endif
		fisError("Illegal parameters in fisTrapezoidMf() --> c >= d");
	}

	if (b <= x)
		y1 = 1;
	else if (x < a)
		y1 = 0;
	else if (a != b)
		y1 = (x-a)/(b-a);

	if (x <= c)
		y2 = 1;
	else if (d < x)
		y2 = 0;
	else if (c != d)
		y2 = (d-x)/(d-c);

	return(MIN(y1, y2));
	/*
	if (a == b && c == d)
		return((b<=x)*(x<=c));
	if (a == b)
		return(MIN(1, (d-x)/(d-c))*(b<=x)*(x<=d));
	if (c == d)
		return(MIN((x-a)/(b-a), 1)*(a<=x)*(x<=c));
	return(MAX(MIN(MIN((x-a)/(b-a), 1), (d-x)/(d-c)), 0));
	*/
}

/* Gaussian membership function */
static double
#ifdef __STDC__
fisGaussianMf(double x, double *para)
#else
fisGaussianMf(x, para)
double x, *para;
#endif
{
	double sigma = para[0], c = para[1];
	double tmp;

	if (sigma==0)
		fisError("Illegal parameters in fisGaussianMF() --> sigma = 0");
	tmp = (x-c)/sigma;
	return(exp(-tmp*tmp/2));
}

/* Extended Gaussian membership function */
static double
#ifdef __STDC__
fisGaussian2Mf(double x, double *para)
#else
fisGaussian2Mf(x, para)
double x, *para;
#endif
{
	double sigma1 = para[0], c1 = para[1];
	double sigma2 = para[2], c2 = para[3];
	double tmp1, tmp2;

	if ((sigma1 == 0) || (sigma2 == 0))
		fisError("Illegal parameters in fisGaussian2MF() --> sigma1 or sigma2 is zero");

	tmp1 = x >= c1? 1:exp(-pow((x-c1)/sigma1, 2.0)/2);
	tmp2 = x <= c2? 1:exp(-pow((x-c2)/sigma2, 2.0)/2);
	return(tmp1*tmp2);
}

/* Sigmoidal membership function */
static double
#ifdef __STDC__
fisSigmoidMf(double x, double *para)
#else
fisSigmoidMf(x, para)
double x, *para;
#endif
{
	double a = para[0], c = para[1];
	return(1/(1+exp(-a*(x-c))));
}

/* Product of two sigmoidal functions */
static double
#ifdef __STDC__
fisProductSigmoidMf(double x, double *para)
#else
fisProductSigmoidMf(x, para)
double x, *para;
#endif
{
	double a1 = para[0], c1 = para[1], a2 = para[2], c2 = para[3];
	double tmp1 = 1/(1+exp(-a1*(x-c1)));
	double tmp2 = 1/(1+exp(-a2*(x-c2)));
	return(tmp1*tmp2);
}

/* Absolute difference of two sigmoidal functions */
static double
#ifdef __STDC__
fisDifferenceSigmoidMf(double x, double *para)
#else
fisDifferenceSigmoidMf(x, para)
double x, *para;
#endif
{
	double a1 = para[0], c1 = para[1], a2 = para[2], c2 = para[3];
	double tmp1 = 1/(1+exp(-a1*(x-c1)));
	double tmp2 = 1/(1+exp(-a2*(x-c2)));
	return(fabs(tmp1-tmp2));
}

/* Generalized bell membership function */
static double
#ifdef __STDC__
fisGeneralizedBellMf(double x, double *para)
#else
fisGeneralizedBellMf(x, para)
double x, *para;
#endif
{
	double a = para[0], b = para[1], c = para[2];
	double tmp;
	if (a==0)
		fisError("Illegal parameters in fisGeneralizedBellMf() --> a = 0");
	tmp = pow((x-c)/a, 2.0);
	if (tmp == 0 && b == 0)
		return(0.5);
	else if (tmp == 0 && b < 0)
		return(0.0);
	else
		return(1/(1+pow(tmp, b)));
}

/* S membership function */
static double
#ifdef __STDC__
fisSMf(double x, double *para)
#else
fisSMf(x, para)
double x, *para;
#endif
{
	double a = para[0], b = para[1];
	double out;

	if (a >= b)
		return(x >= (a+b)/2);

	if (x <= a)
		out = 0;
	else if (x <= (a + b)/2)
		out = 2*pow((x-a)/(b-a), 2.0);
	else if (x <= b)
		out = 1-2*pow((b-x)/(b-a), 2.0);
	else
		out = 1;
	return(out);
}

/* Z membership function */
static double
#ifdef __STDC__
fisZMf(double x, double *para)
#else
fisZMf(x, para)
double x, *para;
#endif
{
	double a = para[0], b = para[1];
	double out;

	if (a >= b)
		return(x <= (a+b)/2);

	if (x <= a)
		out = 1;
	else if (x <= (a + b)/2)
		out = 1 - 2*pow((x-a)/(b-a), 2.0);
	else if (x <= b)
		out = 2*pow((b-x)/(b-a), 2.0);
	else
		out = 0;
	return(out);
}

/* pi membership function */
static double
#ifdef __STDC__
fisPiMf(double x, double *para)
#else
fisPiMf(x, para)
double x, *para;
#endif
{
	return(fisSMf(x, para)*fisZMf(x, para+2));
}

/* all membership function */
static double
#ifdef __STDC__
fisAllMf(double x, double *para)
#else
fisAllMf(x, para)
double x, *para;
#endif
{
	return(1);
}

/* returns the number of parameters of MF */
static int
#ifdef __STDC__
fisGetMfParaN(char *mfType)
#else
fisGetMfParaN(mfType)
char *mfType;
#endif
{
	if (strcmp(mfType, "trimf") == 0)
		return(3);
	if (strcmp(mfType, "trapmf") == 0)
		return(4);
	if (strcmp(mfType, "gaussmf") == 0)
		return(2);
	if (strcmp(mfType, "gauss2mf") == 0)
		return(4);
	if (strcmp(mfType, "sigmf") == 0)
		return(2);
	if (strcmp(mfType, "dsigmf") == 0)
		return(4);
	if (strcmp(mfType, "psigmf") == 0)
		return(4);
	if (strcmp(mfType, "gbellmf") == 0)
		return(3);
	if (strcmp(mfType, "smf") == 0)
		return(2);
	if (strcmp(mfType, "zmf") == 0)
		return(2);
	if (strcmp(mfType, "pimf") == 0)
		return(4);
#ifndef NO_PRINTF
	printf("Given MF type (%s) is unknown.\n", mfType);
#endif
	exit(1);
	return(0);	/* get rid of compiler warning */
}
/***********************************************************************
 T-norm and T-conorm operators
 **********************************************************************/
/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

static double
#ifdef __STDC__
fisMin(double x, double y)
#else
fisMin(x, y)
double x, y;
#endif
{return((x) < (y) ? (x) : (y));}

static double
#ifdef __STDC__
fisMax(double x, double y)
#else
fisMax(x, y)
double x, y;
#endif
{return((x) > (y) ? (x) : (y));}

static double
#ifdef __STDC__
fisProduct(double x, double y)
#else
fisProduct(x, y)
double x, y;
#endif
{return(x*y);} 

static double
#ifdef __STDC__
fisProbOr(double x, double y)
#else
fisProbOr(x, y)
double x, y;
#endif
{return(x + y - x*y);} 

static double
#ifdef __STDC__
fisSum(double x, double y)
#else
fisSum(x, y)
double x, y;
#endif
{return(x + y);} 

/* apply given function to an array */
static double
#ifdef __STDC__
fisArrayOperation(double *array, int size, double (*fcn)())
#else
fisArrayOperation(array, size, fcn)
double *array;
int size;
double (*fcn)();
#endif
{
	int i;
	double out;

	if (size == 0)
		fisError("Given size is zero!");

	out = array[0];
	for (i = 1; i < size; i++)
		out = (*fcn)(out, array[i]);
	return(out);
}
/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

/***********************************************************************
 Defuzzification methods
 **********************************************************************/

/* return the center of area of combined output MF (specified by mf)
   of output m */
/* numofpoints is the number of partition for integration */
static double 
#ifdef __STDC__
defuzzCentroid(FIS *fis, int m, double *mf, int numofpoints)
#else
defuzzCentroid(fis, m, mf)
FIS *fis;
int m;
double *mf;
int numofpoints;
#endif
{
	double min = fis->output[m]->bound[0];
	double max = fis->output[m]->bound[1];
	double step = (max - min)/(numofpoints - 1);
	double total_mf = 0;
	double sum = 0;
	int i;

	for (i = 0; i < numofpoints; i++){
		total_mf += mf[i];
       		sum += mf[i]*(min + step*i);
	}
	if (total_mf == 0) {
#ifndef NO_PRINTF
		printf("Total area is zero in defuzzCentroid() for output %d!\n", m+1);
		printf("Average of the range of this output variable is used as the output value.\n\n");
#endif
		return((fis->output[m]->bound[0] + fis->output[m]->bound[1])/2);
	} 
	return(sum/total_mf);
}

/* return the bisector of area of mf */
static double 
#ifdef __STDC__
defuzzBisector(FIS *fis, int m, double *mf, int numofpoints)
#else
defuzzBisector(fis, m, mf)
FIS *fis;
int m;
double *mf;
int numofpoints;
#endif
{
	double min = fis->output[m]->bound[0];
	double max = fis->output[m]->bound[1];
	double step = (max - min)/(numofpoints - 1); 
	double area, sub_area;
	int i;

	/* find the total area */
	area = 0;
	for (i = 0; i < numofpoints; i++)
		area += mf[i];

	if (area == 0) {
#ifndef NO_PRINTF
		printf("Total area is zero in defuzzBisector() for output %d!\n", m+1);
		printf("Average of the range of this output variable is used as the output value.\n");
#endif
		return((fis->output[m]->bound[0] + fis->output[m]->bound[1])/2);
	} 
     
	sub_area = 0;
	for (i = 0; i < numofpoints; i++) {
		sub_area += mf[i];
		if (sub_area >= area/2)
			break;
	}
	return(min + step*i);
}

/* Returns the mean of maximizing x of mf */
static double 
#ifdef __STDC__
defuzzMeanOfMax(FIS *fis, int m, double *mf, int numofpoints)
#else
defuzzMeanOfMax(fis, m, mf)
FIS *fis;
int m;
double *mf;
int numofpoints;
#endif
{
	double min = fis->output[m]->bound[0];
	double max = fis->output[m]->bound[1];
	double step = (max - min)/(numofpoints - 1); 
	double mf_max;
	double sum;
	int count;
	int i;

	mf_max = fisArrayOperation(mf, numofpoints, fisMax);

	sum = 0;
	count = 0;
	for (i = 0; i < numofpoints; i++)
		if (mf[i] == mf_max) {
			count++;
			sum += i;
		}
	return(min+step*sum/count);
}

/* Returns the smallest (in magnitude) maximizing x of mf */
static double 
#ifdef __STDC__
defuzzSmallestOfMax(FIS *fis, int m, double *mf, int numofpoints)
#else
defuzzSmallestOfMax(fis, m, mf)
FIS *fis;
int m;
double *mf;
int numofpoints;
#endif
{
	double min = fis->output[m]->bound[0];
	double max = fis->output[m]->bound[1];
	double step = (max - min)/(numofpoints - 1); 
	double mf_max;
	int i, min_index = 0;
	double min_distance = pow(2.0, 31.0)-1;
	double distance; /* distance to the origin */

	mf_max = fisArrayOperation(mf, numofpoints, fisMax);
	for (i = 0; i < numofpoints; i++)
		if (mf[i] == mf_max) {
			distance = ABS(min + step*i);
			if (min_distance > distance) {
				min_distance = distance;
				min_index = i;
			}
		}
	return(min + step*min_index);
}

/* Returns the largest (in magnitude) maximizing x of mf */
static double 
#ifdef __STDC__
defuzzLargestOfMax(FIS *fis, int m, double *mf, int numofpoints)
#else
defuzzLargestOfMax(fis, m, mf)
FIS *fis;
int m;
double *mf;
int numofpoints;
#endif
{
	double min = fis->output[m]->bound[0];
	double max = fis->output[m]->bound[1];
	double step = (max - min)/(numofpoints - 1); 
	double mf_max;
	int i, max_index = 0;
	double max_distance = -(pow(2.0, 31.0)-1);
	double distance; /* distance to the origin */

	mf_max = fisArrayOperation(mf, numofpoints, fisMax);
	for (i = 0; i < numofpoints; i++)
		if (mf[i] == mf_max) {
			distance = ABS(min + step*i);
			if (max_distance < distance) {
				max_distance = distance;
				max_index = i;
			}
		}
	return(min + step*max_index);
}
/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

#ifdef MATLAB_MEX_FILE
/***********************************************************************
 MATLAB function calls 
 **********************************************************************/

/* V4 --> v5
mxFreeMatrix --> mxDestroyArray
Matrix --> mxArray;
mxCreateFull(*, *, 0) --> mxCreateDoubleMatrix(*, *, mxREAL)
mexCallMATLAB(*, *, prhs, *) --> mexCallMATLAB(*, *, (mxArray **)prhs, *)
*/

/* execute MATLAB MF function, scalar version */
static double
#ifdef __STDC__
fisCallMatlabMf(double x, double *para, char *mf_type)
#else
fisCallMatlabMf(x, para, mf_type)
double x, *para;
char *mf_type;
#endif
{
	int i;
	mxArray *PARA = mxCreateDoubleMatrix(MF_PARA_N, 1, mxREAL);
	mxArray *X = mxCreateDoubleMatrix(1, 1, mxREAL);
	mxArray *OUT;
	double out;
	mxArray *prhs[2];

	/* data transfer */
	for (i = 0; i < MF_PARA_N; i++)
		mxGetPr(PARA)[i] = para[i];
	mxGetPr(X)[0] = x;

	prhs[0] = X; prhs[1] = PARA;
	
	/* call matlab MF function */
	mexCallMATLAB(1, &OUT, 2, (mxArray **)prhs, mf_type);
	out = mxGetScalar(OUT);

	/* free allocated matrix */
	mxDestroyArray(X);
	mxDestroyArray(PARA);
	mxDestroyArray(OUT);

	/* return output */
	return(out);
}

/* execute MATLAB MF function, vector version */
/* this is used in fisComputeOutputMfValueArray() */ 
static void
#ifdef __STDC__
fisCallMatlabMf2(double *x, double *para, char *mf_type, int leng, double *out)
#else
fisCallMatlabMf2(x, para, mf_type, leng, out)
double *x, *para;
char *mf_type;
int leng;
double *out;
#endif
{
	int i;
	mxArray *PARA = mxCreateDoubleMatrix(MF_PARA_N, 1, mxREAL);
	mxArray *X = mxCreateDoubleMatrix(leng, 1, mxREAL);
	mxArray *OUT;
	mxArray *prhs[2];

	/* transfer data in */
	for (i = 0; i < MF_PARA_N; i++)
		mxGetPr(PARA)[i] = para[i];
	for (i = 0; i < leng; i++)
		mxGetPr(X)[i] = x[i];

	prhs[0] = X; prhs[1] = PARA;
	/* call matlab MF function */
	mexCallMATLAB(1, &OUT, 2, (mxArray **)prhs, mf_type);

	/* transfer data out */
	for (i = 0; i < leng; i++)
		out[i] = mxGetPr(OUT)[i]; 

	/* free allocated matrix */
	mxDestroyArray(X);
	mxDestroyArray(PARA);
	mxDestroyArray(OUT);
}

#ifdef MATLAB_MEX_FILE /* This is only for MEX files, not for RTW */
/* use MATLAB 'exist' to check the type of a variable or function */
static double
#ifdef __STDC__
fisCallMatlabExist(char *variable)
#else
fisCallMatlabExist(variable)
char *variable;
#endif
{
	double out;
#ifndef NO_PRINTF
	mxArray *VARIABLE = mxCreateString(variable);
#else
        mxArray *VARIABLE;
#endif
	mxArray *OUT;

	/* call matlab 'exist' */
	mexCallMATLAB(1, &OUT, 1, &VARIABLE, "exist");
	out = mxGetScalar(OUT);

	/* free allocated matrix */
	mxDestroyArray(VARIABLE);
	mxDestroyArray(OUT);

	/*
	printf("%s\n", variable);
	printf("out = %f\n", out);
	*/

	/* return output */
	return(out);
}
#endif

/* execute MATLAB function with a vector input */
/* qualified MATLAB functions are min, sum, max, etc */
static double
#ifdef __STDC__
fisCallMatlabFcn(double *x, int leng, char *func)
#else
fisCallMatlabFcn(x, leng, func)
double *x;
int leng;
char *func;
#endif
{
	double out;
	mxArray *X = mxCreateDoubleMatrix(leng, 1, mxREAL);
	mxArray *OUT;
	int i;

	/* transfer data */
	for (i = 0; i < leng; i++)
		mxGetPr(X)[i] = x[i];

	/* call matlab function */
	mexCallMATLAB(1, &OUT, 1, &X, func);
	out = mxGetScalar(OUT);

	/* free allocated matrix */
	mxDestroyArray(X);
	mxDestroyArray(OUT);

	/* return output */
	return(out);
}

/* execute MATLAB function with a matrix input */
/* qualified MATLAB functions are min, sum, max, etc */
static void
#ifdef __STDC__
fisCallMatlabFcn1(double *x, int m, int n, char *func, double *out)
#else
fisCallMatlabFcn1(x, m, n, func, out)
double *x;
int m, n;
char *func;
double *out;
#endif
{
	mxArray *X, *OUT;
	int i;

	/* allocate memory */
	X = mxCreateDoubleMatrix(m, n, mxREAL);

	/* transfer data in */
	for (i = 0; i < m*n; i++)
		mxGetPr(X)[i] = x[i];

	/* call matlab function */
	mexCallMATLAB(1, &OUT, 1, &X, func);

	/* transfer data out */
	if (m == 1)
		out[0] = mxGetScalar(OUT);
	else
		for (i = 0; i < n; i++)
			out[i] = mxGetPr(OUT)[i]; 

	/* free allocated matrix */
	mxDestroyArray(X);
	mxDestroyArray(OUT);
}

/* execute MATLAB function with two matrix inputs */
/* qualified MATLAB functions are min, sum, max, etc */
static void
#ifdef __STDC__
fisCallMatlabFcn2(double *x, double *y, int m, int n, char *func, double *out)
#else
fisCallMatlabFcn2(x, y, m, n, func, out)
double *x, *y;
int m, n;
char *func;
double *out;
#endif
{
	mxArray *X, *Y, *OUT, *prhs[2];
	int i;

	/* allocate memory */
	X = mxCreateDoubleMatrix(m, n, mxREAL);
	Y = mxCreateDoubleMatrix(m, n, mxREAL);
	prhs[0] = X;
	prhs[1] = Y;

	/* transfer data in */
	for (i = 0; i < m*n; i++) {
		mxGetPr(X)[i] = x[i];
		mxGetPr(Y)[i] = y[i];
	}

	/* call matlab function */
	mexCallMATLAB(1, &OUT, 2, (mxArray **)prhs, func);

	/* transfer data out */
	for (i = 0; i < m*n; i++)
			out[i] = mxGetPr(OUT)[i]; 

	/* free allocated matrix */
	mxDestroyArray(X);
	mxDestroyArray(Y);
	mxDestroyArray(OUT);
}

/* execute MATLAB function for defuzzification */
static double
#ifdef __STDC__
fisCallMatlabDefuzz(double *x, double *mf, int leng, char *defuzz_fcn)
#else
fisCallMatlabDefuzz(x, mf, leng, defuzz_fcn)
double *x, *mf;
int leng;
char *defuzz_fcn;
#endif
{
	double out;
	mxArray *X = mxCreateDoubleMatrix(leng, 1, mxREAL);
	/* MF is used as type word in fis.h */
	/* gcc is ok with MF being used here, but cc needs a different name */
	mxArray *MF_ = mxCreateDoubleMatrix(leng, 1, mxREAL);
	mxArray *OUT;
	mxArray *prhs[2];
	int i;

	/* transfer data */
	for (i = 0; i < leng; i++) {
		mxGetPr(X)[i] = x[i];
		mxGetPr(MF_)[i] = mf[i];
	}

	/* call matlab function */
	prhs[0] = X;
	prhs[1] = MF_;
	mexCallMATLAB(1, &OUT, 2, (mxArray **)prhs, defuzz_fcn);
	out = mxGetScalar(OUT);

	/* free allocated matrix */
	mxDestroyArray(X);
	mxDestroyArray(MF_);
	mxDestroyArray(OUT);

	/* return output */
	return(out);
}
#else

# define fisCallMatlabMf(x,para,mf_type)               /* do nothing */
# define fisCallMatlabMf2(x, para, mf_type, leng, out) /* do nothing */
# define fisCallMatlabExist(variable)                  /* do nothing */
# define fisCallMatlabFcn(x, leng, func)               /* do nothing */
# define fisCallMatlabFcn1(x, m, n, func, out)         /* do nothing */
# define fisCallMatlabFcn2(x, y, m, n, func, out)      /* do nothing */
# define fisCallMatlabDefuzz(x, mf, leng, defuzz_fcn)  /* do nothing */

#endif /* MATLAB_MEX_FILE */
/***********************************************************************
 Data structure: construction, printing, and destruction 
 **********************************************************************/
/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

IO *
#ifdef __STDC__
fisBuildIoList(int node_n, int *mf_n)
#else
fisBuildIoList(node_n, mf_n)
int node_n;
int *mf_n;
#endif
{
	IO *io_list;
	int i, j;

	io_list = (IO *)calloc(node_n, sizeof(MF));
	for (i = 0; i < node_n; i++) {
		io_list[i].mf_n = mf_n[i];
		io_list[i].mf = (MF **)calloc(mf_n[i], sizeof(MF *));
		if (mf_n[i] > 0)	/* check if no MF at all */
			io_list[i].mf[0] = (MF *)calloc(mf_n[i], sizeof(MF));
		for (j = 0; j < mf_n[i]; j++)
			io_list[i].mf[j] = io_list[i].mf[0] + j;
	}
	return(io_list);
}

/* Assign a MF pointer to each MF node based on the MF node's type */
void
#ifdef __STDC__
fisAssignMfPointer(FIS *fis)
#else
fisAssignMfPointer(fis)
FIS *fis;
#endif
{
	int i, j, k, mfTypeN = 13, found;
	MF *mf_node;
#ifdef __STDC__
	struct command {
		char *mfType;
		double (*mfFcn)();
	} dispatch[] = {
		{ "trimf",	fisTriangleMf },
		{ "trapmf",	fisTrapezoidMf },
		{ "gaussmf",	fisGaussianMf },
		{ "gauss2mf",	fisGaussian2Mf },
		{ "sigmf",	fisSigmoidMf },
		{ "dsigmf",	fisDifferenceSigmoidMf },
		{ "psigmf",	fisProductSigmoidMf },
		{ "gbellmf",	fisGeneralizedBellMf },
		{ "smf",	fisSMf },
		{ "zmf",	fisZMf },
		{ "pimf",	fisPiMf },
		{ "linear",	NULL },
		{ "constant",	NULL }
	};
#else
	struct command {
		char mfType[20];
		double (*mfFcn)();
	} dispatch[20];
	
	strcpy(dispatch[0].mfType, "trimf");
	dispatch[0].mfFcn = fisTriangleMf;
	strcpy(dispatch[1].mfType, "trapmf");
	dispatch[1].mfFcn = fisTrapezoidMf;
	strcpy(dispatch[2].mfType, "gaussmf");
	dispatch[2].mfFcn = fisGaussianMf;
	strcpy(dispatch[3].mfType, "gauss2mf");
	dispatch[3].mfFcn = fisGaussian2Mf;
	strcpy(dispatch[4].mfType, "sigmf");
	dispatch[4].mfFcn = fisSigmoidMf;
	strcpy(dispatch[5].mfType, "dsigmf");
	dispatch[5].mfFcn = fisDifferenceSigmoidMf;
	strcpy(dispatch[6].mfType, "psigmf");
	dispatch[6].mfFcn = fisProductSigmoidMf;
	strcpy(dispatch[7].mfType, "gbellmf");
	dispatch[7].mfFcn = fisGeneralizedBellMf;
	strcpy(dispatch[8].mfType, "smf");
	dispatch[8].mfFcn = fisSMf;
	strcpy(dispatch[9].mfType, "zmf");
	dispatch[9].mfFcn = fisZMf;
	strcpy(dispatch[10].mfType, "pimf");
	dispatch[10].mfFcn = fisPiMf;
	strcpy(dispatch[11].mfType, "linear");
	dispatch[11].mfFcn = NULL;
	strcpy(dispatch[12].mfType, "constant");
	dispatch[12].mfFcn = NULL;
#endif

	/* input MF's */
	for (i = 0; i < fis->in_n; i++)
		for (j = 0; j < fis->input[i]->mf_n; j++) {
			mf_node = fis->input[i]->mf[j];
			found = 0;
			for (k = 0; k < mfTypeN-2; k++) {
				if (strcmp(mf_node->type, dispatch[k].mfType) == 0) {
					mf_node->mfFcn = dispatch[k].mfFcn;
					found = 1;
					break;
				}
			}
			if (found == 0) {
#ifdef MATLAB_MEX_FILE
			{
				double function_type;
				function_type = fisCallMatlabExist(mf_node->type);
				if (function_type == 0) {
					printf("MF '%s' does not exist!\n", mf_node->type);
					fisError("Exiting ...");
				}
				if (function_type == 1) {
					printf("MF '%s' is a MATLAB variable!\n", mf_node->type);
					fisError("Exiting ...");
				}
				mf_node->userDefined = 1;
			}
#else
#ifndef NO_PRINTF
				printf("MF type '%s' for input %d is unknown.\n",
					mf_node->type, i+1);
				printf("Legal input MF types: ");
				for (i = 0; i < mfTypeN-2; i++)
					printf("%s ", dispatch[i].mfType);
				/*
				printf("\n\nIf '%s' is a customized MF, use M-file command FISEVAL1 or FISEVAL2 instead.\n", mf_node->type);
				*/
				printf("\n");
#endif
				fisError("\n");
#endif
			}
		}

	/* output MF's */
	for (i = 0; i < fis->out_n; i++)
		for (j = 0; j < fis->output[i]->mf_n; j++) {
			mf_node = fis->output[i]->mf[j];
			found = 0;
			for (k = 0; k < mfTypeN; k++) {
				if (strcmp(mf_node->type, dispatch[k].mfType) == 0) {
					mf_node->mfFcn = dispatch[k].mfFcn;
					found = 1;
					break;
				}
			}
			if (found == 0) {
#ifdef MATLAB_MEX_FILE
			{
				double function_type;
				function_type = fisCallMatlabExist(mf_node->type);
				if (function_type == 0) {
					printf("MATLAB function '%s' does not exist!\n", mf_node->type);
					fisError("Exiting ...");
				}
				if (function_type == 1) {
					printf("'%s' is a MATLAB variable!\n", mf_node->type);
					fisError("Exiting ...");
				}
				mf_node->userDefined = 1;
			}
#else
#ifndef NO_PRINTF
				printf("MF type '%s' for output %d is unknown.\n",
					mf_node->type, i+1);
				printf("Legal output MF types: ");
				for (i = 0; i < mfTypeN-1; i++)
					printf("%s ", dispatch[i].mfType);
				/*
				printf("\n\nIf '%s' is a customized MF, use M-file command FISEVAL1 or FISEVAL2 instead.\n", mf_node->type);
				*/
				printf("\n");
#endif
				fisError("\n");
#endif
			}
		}
}

/* Assign a other function pointers */
void
#ifdef __STDC__
fisAssignFunctionPointer(FIS *fis)
#else
fisAssignFunctionPointer(fis)
FIS *fis;
#endif
{
	/* assign andMethod function pointer */
	if (strcmp(fis->andMethod, "prod") == 0)
		fis->andFcn = fisProduct;
	else if (strcmp(fis->andMethod, "min") == 0)
		fis->andFcn = fisMin;
	else {
#ifdef MATLAB_MEX_FILE
	{
		double function_type;
		function_type = fisCallMatlabExist(fis->andMethod);
		if (function_type == 0) {
			printf("AND function '%s' does not exist!\n", fis->andMethod);
			fisError("Exiting ...");
		}
		if (function_type == 1) {
			printf("AND function '%s' is a MATLAB variable!\n", fis->andMethod);
			fisError("Exiting ...");
		}
		fis->userDefinedAnd = 1;
	}
#else
#ifndef NO_PRINTF
		printf("Given andMethod %s is unknown.\n", fis->andMethod);
#endif
		fisError("Legal andMethod: min, prod");
#endif
	}

	/* assign orMethod function pointer */
	if (strcmp(fis->orMethod, "probor") == 0)
		fis->orFcn = fisProbOr;
	else if (strcmp(fis->orMethod, "max") == 0)
		fis->orFcn = fisMax;
	else {
#ifdef MATLAB_MEX_FILE
	{
		double function_type;
		function_type = fisCallMatlabExist(fis->orMethod);
		if (function_type == 0) {
			printf("OR function '%s' does not exist!\n", fis->orMethod);
			fisError("Exiting ...");
		}
		if (function_type == 1) {
			printf("OR function '%s' is a MATLAB variable!\n", fis->orMethod);
			fisError("Exiting ...");
		}
		fis->userDefinedOr = 1;
	}
#else
#ifndef NO_PRINTF
		printf("Given orMethod %s is unknown.\n", fis->orMethod);
#endif
		fisError("Legal orMethod: max, probor");
#endif
	}

	/* assign impMethod function pointer */
	if (strcmp(fis->impMethod, "prod") == 0)
		fis->impFcn = fisProduct;
	else if (strcmp(fis->impMethod, "min") == 0)
		fis->impFcn = fisMin;
	else {
#ifdef MATLAB_MEX_FILE
	{
		double function_type;
		function_type = fisCallMatlabExist(fis->impMethod);
		if (function_type == 0) {
			printf("IMPLICATION function '%s' does not exist!\n", fis->impMethod);
			fisError("Exiting ...");
		}
		if (function_type == 1) {
			printf("IMPLICATION function '%s' is a MATLAB variable!\n", fis->impMethod);
			fisError("Exiting ...");
		}
		fis->userDefinedImp = 1;
	}
#else
#ifndef NO_PRINTF
		printf("Given impMethod %s is unknown.\n", fis->impMethod);
#endif
		fisError("Legal impMethod: min, prod");
#endif
	}

	/* assign aggMethod function pointer */
	if (strcmp(fis->aggMethod, "max") == 0)
		fis->aggFcn = fisMax;
	else if (strcmp(fis->aggMethod, "probor") == 0)
		fis->aggFcn = fisProbOr;
	else if (strcmp(fis->aggMethod, "sum") == 0)
		fis->aggFcn = fisSum;
	else {
#ifdef MATLAB_MEX_FILE
	{
		double function_type;
		function_type = fisCallMatlabExist(fis->aggMethod);
		if (function_type == 0) {
			printf("AGGREGATE function '%s' does not exist!\n", fis->aggMethod);
			fisError("Exiting ...");
		}
		if (function_type == 1) {
			printf("AGGREGATE function '%s' is a MATLAB variable!\n", fis->aggMethod);
			fisError("Exiting ...");
		}
		fis->userDefinedAgg = 1;
	}
#else
#ifndef NO_PRINTF
		printf("Given aggMethod %s is unknown.\n", fis->aggMethod);
#endif
		fisError("Legal aggMethod: max, probor, sum");
#endif
	}

	/* assign defuzzification function pointer */
	if (strcmp(fis->defuzzMethod, "centroid") == 0)
		fis->defuzzFcn = defuzzCentroid;
	else if (strcmp(fis->defuzzMethod, "bisector") == 0)
		fis->defuzzFcn = defuzzBisector;
	else if (strcmp(fis->defuzzMethod, "mom") == 0)
		fis->defuzzFcn = defuzzMeanOfMax;
	else if (strcmp(fis->defuzzMethod, "som") == 0)
		fis->defuzzFcn = defuzzSmallestOfMax;
	else if (strcmp(fis->defuzzMethod, "lom") == 0)
		fis->defuzzFcn = defuzzLargestOfMax;
	else if (strcmp(fis->defuzzMethod, "wtaver") == 0)
		;
	else if (strcmp(fis->defuzzMethod, "wtsum") == 0)
		;
	else {
#ifdef MATLAB_MEX_FILE
	{
		double function_type;
		function_type = fisCallMatlabExist(fis->defuzzMethod);
		if (function_type == 0) {
			printf("DEFUZZIFICATION function '%s' does not exist!\n", fis->defuzzMethod);
			fisError("Exiting ...");
		}
		if (function_type == 1) {
			printf("DEFUZZIFICATION function '%s' is a MATLAB variable!\n", fis->defuzzMethod);
			fisError("Exiting ...");
		}
		fis->userDefinedDefuzz = 1;
	}
#else
#ifndef NO_PRINTF
		printf("Given defuzzification method %s is unknown.\n", fis->defuzzMethod);
#endif
		fisError("Legal defuzzification methods: centroid, bisector, mom, som, lom, wtaver, wtsum");
#endif
	}
}

#ifndef NO_PRINTF
static void
#ifdef __STDC__
fisPrintData(FIS *fis)
#else
fisPrintData(fis)
FIS *fis;
#endif
{
	int i, j, k;

	if (fis == NULL)
		fisError("Given fis pointer is NULL, no data to print!");

	printf("fis_name = %s\n", fis->name);
	printf("fis_type = %s\n", fis->type);
	printf("in_n = %d\n", fis->in_n);
	printf("out_n = %d\n", fis->out_n);

	printf("in_mf_n: ");
	for (i = 0; i < fis->in_n; i++)
		printf("%d ", fis->input[i]->mf_n);
	printf("\n");

	printf("out_mf_n: ");
	for (i = 0; i < fis->out_n; i++)
		printf("%d ", fis->output[i]->mf_n);
	printf("\n");

	printf("rule_n = %d\n", fis->rule_n);

	printf("andMethod = %s\n", fis->andMethod);
	printf("orMethod = %s\n", fis->orMethod);
	printf("impMethod = %s\n", fis->impMethod);
	printf("aggMethod = %s\n", fis->aggMethod);
	printf("defuzzMethod = %s\n", fis->defuzzMethod);

	/*
	for (i = 0; i < fis->in_n; i++) {
		printf("Input variable %d = %s\n", i+1, fis->input[i]->name);
		for (j = 0; j < fis->input[i]->mf_n; j++)
			printf("\t Label for MF %d = %s\n", j+1, fis->input[i]->mf[j]->label);
	}

	for (i = 0; i < fis->out_n; i++) {
		printf("Output variable %d = %s\n", i+1, fis->output[i]->name);
		for (j = 0; j < fis->output[i]->mf_n; j++)
			printf("\t Label for MF %d = %s\n", j+1, fis->output[i]->mf[j]->label);
	}
	*/

	for (i = 0; i < fis->in_n; i++)
		printf("Bounds for input variable %d: [%6.3f %6.3f]\n", i+1,
			fis->input[i]->bound[0], fis->input[i]->bound[1]);

	for (i = 0; i < fis->out_n; i++)
		printf("Bounds for output variable %d: [%6.3f %6.3f]\n", i+1,
			fis->output[i]->bound[0], fis->output[i]->bound[1]);

	for (i = 0; i < fis->in_n; i++) {
		printf("MF for input variable %d (%s):\n", i+1, fis->input[i]->name);
		for (j = 0; j < fis->input[i]->mf_n; j++)
			printf("\t Type for MF %d = %s\n", j+1, fis->input[i]->mf[j]->type);
	}

	for (i = 0; i < fis->out_n; i++) {
		printf("MF for output variable %d (%s):\n", i+1, fis->output[i]->name);
		for (j = 0; j < fis->output[i]->mf_n; j++)
			printf("\t Type for MF %d = %s\n", j+1, fis->output[i]->mf[j]->type);
	}

	printf("Rule list:\n");
	for (i = 0; i < fis->rule_n; i++) {
		for (j = 0; j < fis->in_n + fis->out_n; j++)
			printf("%d ", fis->rule_list[i][j]);
		printf("\n");
	}

	printf("Rule weights:\n");
	for (i = 0; i < fis->rule_n; i++)
		printf("%f\n", fis->rule_weight[i]);

	printf("AND-OR indicator:\n");
	for (i = 0; i < fis->rule_n; i++)
		printf("%d\n", fis->and_or[i]);

	for (i = 0; i < fis->in_n; i++) {
		printf("MF parameters for input variable %d (%s):\n",
			i+1, fis->input[i]->name);
		for (j = 0; j < fis->input[i]->mf_n; j++) {
			printf("\tParameters for MF %d (%s) (%s): ",
				j+1, fis->input[i]->mf[j]->label,
				fis->input[i]->mf[j]->type);
			for (k = 0; k < MF_PARA_N; k++)
				printf("%6.3f ", fis->input[i]->mf[j]->para[k]);
			printf("\n");
		}
	}
	if (strcmp(fis->type, "mamdani") == 0) {
		for (i = 0; i < fis->out_n; i++) {
			printf("MF parameters for output variable %d (%s):\n",
				i+1, fis->output[i]->name);
			for (j = 0; j < fis->output[i]->mf_n; j++) {
				printf("\tParameters for MF %d (%s) (%s): ",
					j+1, fis->output[i]->mf[j]->label,
					fis->output[i]->mf[j]->type);
				for (k = 0; k < MF_PARA_N; k++)
					printf("%6.3f ", fis->output[i]->mf[j]->para[k]);
				printf("\n");
			}
		}
	} else if (strcmp(fis->type, "sugeno") == 0) {
		for (i = 0; i < fis->out_n; i++) {
			printf("Sugeno model parameters for output variable %d (%s):\n",
				i+1, fis->output[i]->name);
			for (j = 0; j < fis->output[i]->mf_n; j++) {
				printf("\tSugeno model parameters for list %d (%s) (%s): ",
					j+1, fis->output[i]->mf[j]->label,
					fis->output[i]->mf[j]->type);
				for (k = 0; k < fis->in_n + 1; k++)
					printf("%6.3f ", fis->output[i]->mf[j]->sugeno_coef[k]);
				printf("\n");
			}
		}
	} else {
		printf("fis->type = %s\n", fis->type);
		fisError("Unknown fis type!");
	}
}
#endif


static void
#ifdef __STDC__
fisFreeMfList(MF *mf_list, int n)
#else
fisFreeMfList(mf_list, n)
MF *mf_list;
int n;
#endif
{
	int i;

	for (i = 0; i < n; i++) {
		free(mf_list[i].sugeno_coef);
		free(mf_list[i].value_array);
	}
	free(mf_list);
}

static void
#ifdef __STDC__
fisFreeIoList(IO *io_list, int n)
#else
fisFreeIoList(io_list, n)
IO *io_list;
int n;
#endif
{
	int i;
	for (i = 0; i < n; i++) {
		if (io_list[i].mf_n > 0)	/* check if no MF at all */
			fisFreeMfList(io_list[i].mf[0], io_list[i].mf_n);
		free(io_list[i].mf);
	}
	free(io_list);
}

void
#ifdef __STDC__
fisFreeFisNode(FIS *fis)
#else
fisFreeFisNode(fis)
FIS *fis;
#endif
{
	if (fis == NULL)
		return;
	fisFreeIoList(fis->input[0], fis->in_n);
	free(fis->input);
	fisFreeIoList(fis->output[0], fis->out_n);
	free(fis->output);
#ifdef FREEMAT
	FREEMAT((void **)fis->rule_list, fis->rule_n);
#else
	fisFreeMatrix((void **)fis->rule_list, fis->rule_n);
#endif
	free(fis->rule_weight);
	free(fis->and_or);
	free(fis->firing_strength);
	free(fis->rule_output);
	free(fis->BigOutMfMatrix);
	free(fis->BigWeightMatrix);
	free(fis->mfs_of_rule);
	free(fis);
}

/* Compute arrays of MF values (for Mamdani model only) */
/* This is done whenever new parameters are loaded */
void
#ifdef __STDC__
fisComputeOutputMfValueArray(FIS *fis, int numofpoints)
#else
fisComputeOutputMfValueArray(fis)
FIS *fis;
int numofpoints
#endif
{
	int i, j, k;
	double x, lx, ux, dx;
	MF *mf_node;

	for (i = 0; i < fis->out_n; i++) {
		lx = fis->output[i]->bound[0];
		ux = fis->output[i]->bound[1];
		dx = (ux - lx)/(numofpoints - 1);
		for (j = 0; j < fis->output[i]->mf_n; j++) {
			mf_node = fis->output[i]->mf[j];
			if (!mf_node->userDefined)
				for (k = 0; k < numofpoints; k++) {
					x = lx + k*dx;
					mf_node->value_array[k] =
					(*mf_node->mfFcn)(x, mf_node->para);
				}
			else { 	/* user defined MF */
#ifdef MATLAB_MEX_FILE
				/* this is non-vector version */
				/*
				for (k = 0; k < numofpoints; k++) {
					x = lx + k*dx;
					mf_node->value_array[k] =
					fisCallMatlabMf(x, mf_node->para,
					mf_node->type);
				}
				*/
				/* this is vector version */
				{
                		double *X;
                                X = (double *)calloc(numofpoints, sizeof(double));
			/*	double X[numofpoints]; */
				for (k = 0; k < numofpoints; k++)
					X[k] = lx + k*dx;
				fisCallMatlabMf2(X, mf_node->para,
				mf_node->type, numofpoints, mf_node->value_array);
                                free(X);
				}
#else
#ifndef NO_PRINTF
				printf("Cannot find MF type %s!\n", mf_node->type);
#endif
				fisError("Exiting ...");
#endif
			}
		}
	}
}

























/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

/* copy string (the first 'length' characters) from array to target string */
static void
#ifdef __STDC__
fisGetString2(char *target, double *array, int max_leng)
#else
fisGetString2(target, array, max_leng)
char *target;
double *array;
int max_leng;
#endif
{
	int i;
	int actual_leng;

	/* Find the actual length of the string */
	/* If the string is not ended with 0, take max_leng */
	for (actual_leng = 0; actual_leng < max_leng; actual_leng++)
		if (array[actual_leng] == 0)
			break;

	if (actual_leng + 1 > STR_LEN) {
#ifndef NO_PRINTF
		printf("actual_leng = %d\n", actual_leng);
		printf("STR_LEN = %d\n", STR_LEN);
#endif
		fisError("String too long!");
	}
	for (i = 0; i < actual_leng; i++)
		target[i] = (int)array[i];
	target[actual_leng] = 0;
}

/* Check if there are abnormal situations is the FIS data structure */
/* Things being checked:
	1. MF indices out of bound.
	2. Rules with no premise part.
	3. Sugeno system with negated consequent.
	4. Sugeno system with zero consequent.
*/
void
#ifdef __STDC__
fisCheckDataStructure(FIS *fis)
#else
fisCheckDataStructure(fis)
FIS *fis;
#endif
{
	int i, j, mf_index;
	int found;

	/* check if MF indices are out of bound */
	for (i = 0; i < fis->rule_n; i++) {
		for (j = 0; j < fis->in_n; j++) {
			mf_index = fis->rule_list[i][j];
			if (ABS(mf_index) > fis->input[j]->mf_n) {
#ifndef NO_PRINTF
				printf("MF index for input %d in rule %d is out of bound.\n", 
					j+1, i+1);
#endif
				fisFreeFisNode(fis);
				fisError("Exiting ...");
			}
		}
		for (j = 0; j < fis->out_n; j++) {
			mf_index = fis->rule_list[i][fis->in_n+j];
			if (ABS(mf_index) > fis->output[j]->mf_n) {
#ifndef NO_PRINTF
				printf("MF index for output %d in rule %d is out of bound.\n", 
					j+1, i+1);
#endif
				fisFreeFisNode(fis);
				fisError("Exiting ...");
			}
		}
	}
	/* check if there is a rule whose premise MF indice are all zeros */ 
	for (i = 0; i < fis->rule_n; i++) {
		found = 1;
		for (j = 0; j < fis->in_n; j++) {
			mf_index = fis->rule_list[i][j];
			if (mf_index != 0) {
				found = 0;
				break;
			}
		}
		if (found == 1) {
#ifndef NO_PRINTF
			printf("Rule %d has no premise part.\n", i+1);
#endif
			fisFreeFisNode(fis);
			fisError("Exiting ...");
		}
	}
	/* check if it's sugeno system with "NOT" consequent */
	if (strcmp(fis->type, "sugeno") == 0)
	for (i = 0; i < fis->rule_n; i++)
		for (j = 0; j < fis->out_n; j++) {
			mf_index = fis->rule_list[i][fis->in_n+j];
			if (mf_index < 0) {
#ifndef NO_PRINTF
				printf("Rule %d has a 'NOT' consequent.\n", i+1);
				printf("Sugeno fuzzy inference system does not allow this.\n");
#endif
				fisError("Exiting ...");
			}
		}
	/* check if it's sugeno system with zero consequent */
	if (strcmp(fis->type, "sugeno") == 0)
	for (i = 0; i < fis->rule_n; i++)
		for (j = 0; j < fis->out_n; j++) {
			mf_index = fis->rule_list[i][fis->in_n+j];
			if (mf_index == 0) {
#ifndef NO_PRINTF
				printf("\nWarning: Output %d in rule %d has a zero MF index.\n", j+1, i+1);
				printf("This output in the rule is assumed zero in subsequent calculation.\n\n");
#endif
			}
		}
}

/* Build FIS node and load parameter from fismatrix directly */
/* col_n is the number of columns of the fismatrix */
static void 
#ifdef __STDC__
fisBuildFisNode(FIS *fis, double **fismatrix, int col_n, int numofpoints)
#else
fisBuildFisNode(fis, fismatrix, col_n)
FIS *fis;
double **fismatrix;
int col_n;
int numofpoints;
#endif
{
	int i, j, k;
	int *in_mf_n, *out_mf_n;
	IO *io_list;
	int start;

	fisGetString2(fis->name, fismatrix[0], col_n);
	fisGetString2(fis->type, fismatrix[1], col_n);
	fis->in_n = fismatrix[2][0];
	fis->out_n = fismatrix[2][1];

	/* create input node list */
	in_mf_n = (int *)calloc(fis->in_n, sizeof(int));
	for (i = 0; i < fis->in_n; i++)
		in_mf_n[i] = fismatrix[3][i];
	io_list = fisBuildIoList(fis->in_n, in_mf_n);
	free(in_mf_n);
	fis->input = (IO **)calloc(fis->in_n, sizeof(IO *));
	for (i = 0; i < fis->in_n; i++)
		fis->input[i] = io_list+i;

	/* create output node list */
	out_mf_n = (int *)calloc(fis->out_n, sizeof(int));
	for (i = 0; i < fis->out_n; i++)
		out_mf_n[i] = fismatrix[4][i];
	io_list = fisBuildIoList(fis->out_n, out_mf_n);
	free(out_mf_n);
	fis->output = (IO **)calloc(fis->out_n, sizeof(IO *));
	for (i = 0; i < fis->out_n; i++)
		fis->output[i] = io_list+i;

	fis->rule_n = fismatrix[5][0];

	fisGetString2(fis->andMethod, fismatrix[6], col_n);
	fisGetString2(fis->orMethod, fismatrix[7], col_n);
	fisGetString2(fis->impMethod, fismatrix[8], col_n);
	fisGetString2(fis->aggMethod, fismatrix[9], col_n);
	fisGetString2(fis->defuzzMethod, fismatrix[10], col_n);

	start = 11;
	/* For efficiency, I/O names and MF labels are not stored */
	for (i = 0; i < fis->in_n; i++) {
		fis->input[i]->name[0] = '\0';
		for (j = 0; j < fis->input[i]->mf_n; j++)
			fis->input[i]->mf[j]->label[0] = '\0';
	}
	for (i = 0; i < fis->out_n; i++) {
		fis->output[i]->name[0] = '\0';
		for (j = 0; j < fis->output[i]->mf_n; j++)
			fis->output[i]->mf[j]->label[0] = '\0';
	}

	start = start + fis->in_n + fis->out_n;
	for (i = start; i < start + fis->in_n; i++) {
		fis->input[i-start]->bound[0] = fismatrix[i][0];
		fis->input[i-start]->bound[1] = fismatrix[i][1];
	}

	start = start + fis->in_n;
	for (i = start; i < start + fis->out_n; i++) {
		fis->output[i-start]->bound[0] = fismatrix[i][0];
		fis->output[i-start]->bound[1] = fismatrix[i][1];
	}

	/* update "start" to skip reading of MF labels */
	for (i = 0; i < fis->in_n; start += fis->input[i]->mf_n, i++);
	for (i = 0; i < fis->out_n; start += fis->output[i]->mf_n, i++);

	start = start + fis->out_n;
	for (i = 0; i < fis->in_n; i++)
		for (j = 0; j < fis->input[i]->mf_n; j++) {
			fisGetString2(fis->input[i]->mf[j]->type, fismatrix[start], col_n);
			start++;
		}

	for (i = 0; i < fis->out_n; i++)
		for (j = 0; j < fis->output[i]->mf_n; j++) {
			fisGetString2(fis->output[i]->mf[j]->type, fismatrix[start], col_n);
			start++;
		}

	fisAssignMfPointer(fis);
	fisAssignFunctionPointer(fis);

	/* get input MF parameters */
	for (i = 0; i < fis->in_n; i++) {
		for (j = 0; j < fis->input[i]->mf_n; j++) {
			for (k = 0; k < MF_PARA_N; k++)
				fis->input[i]->mf[j]->para[k] = 
					fismatrix[start][k];
			start++;
		}
	}
	/* get Mamdani output MF parameters and compute MF value array */
	if (strcmp(fis->type, "mamdani") == 0) {
		for (i = 0; i < fis->out_n; i++)
			for (j = 0; j < fis->output[i]->mf_n; j++) {
				fis->output[i]->mf[j]->value_array =
					(double *)calloc(numofpoints, sizeof(double));
				for (k = 0; k < MF_PARA_N; k++)
					fis->output[i]->mf[j]->para[k] =
						fismatrix[start][k];
				start++;
			}
		fisComputeOutputMfValueArray(fis, numofpoints);
	/* get Sugeno output equation parameters */
	} else if (strcmp(fis->type, "sugeno") == 0) {
		for (i = 0; i < fis->out_n; i++)
			for (j = 0; j < fis->output[i]->mf_n; j++) {
				fis->output[i]->mf[j]->sugeno_coef =
					(double *)calloc(fis->in_n+1, sizeof(double));
				for (k = 0; k < fis->in_n+1; k++)
					fis->output[i]->mf[j]->sugeno_coef[k] =
						fismatrix[start][k];
				start++;
			}
	} else {
#ifndef NO_PRINTF
		printf("fis->type = %s\n", fis->type);
#endif
		fisError("Unknown fis type!");
	}

	fis->rule_list = (int **)fisCreateMatrix
		(fis->rule_n, fis->in_n + fis->out_n, sizeof(int));
	fis->rule_weight = (double *)calloc(fis->rule_n, sizeof(double));
	fis->and_or = (int *)calloc(fis->rule_n, sizeof(int));
	for (i = 0; i < fis->rule_n; i++) {
		for (j = 0; j < fis->in_n + fis->out_n; j++)
			fis->rule_list[i][j] = (int)fismatrix[start][j];
		fis->rule_weight[i] = fismatrix[start][fis->in_n+fis->out_n];
		fis->and_or[i] = (int)fismatrix[start][fis->in_n+fis->out_n+1];
		start++;
	}

	fis->firing_strength = (double *)calloc(fis->rule_n, sizeof(double));
	fis->rule_output = (double *)calloc(fis->rule_n, sizeof(double));
	if (strcmp(fis->type, "mamdani") == 0) {
		fis->BigOutMfMatrix = (double *)
			calloc(fis->rule_n*numofpoints, sizeof(double));
		fis->BigWeightMatrix = (double *)
			calloc(fis->rule_n*numofpoints, sizeof(double));
	}
	fis->mfs_of_rule = (double *)calloc(fis->in_n, sizeof(double));
	fisCheckDataStructure(fis);
}

/* load parameters and rule list from given fismatrix */
static void 
#ifdef __STDC__
fisLoadParameter(FIS *fis, double **fismatrix, int numofpoints)
#else
fisLoadParameter(fis, fismatrix)
FIS *fis;
double **fismatrix;
int numofpoints;
#endif
{
	int start;
	int i, j, k;

	start = 11 + 2*(fis->in_n + fis->out_n);
	for (i = 0; i < fis->in_n; start += fis->input[i]->mf_n, i++);
	for (i = 0; i < fis->out_n; start += fis->output[i]->mf_n, i++);
	for (i = 0; i < fis->in_n; start += fis->input[i]->mf_n, i++);
	for (i = 0; i < fis->out_n; start += fis->output[i]->mf_n, i++);

	/* get input MF parameters */
	for (i = 0; i < fis->in_n; i++) {
		for (j = 0; j < fis->input[i]->mf_n; j++) {
			for (k = 0; k < MF_PARA_N; k++)
				fis->input[i]->mf[j]->para[k] = 
					fismatrix[start][k];
			start++;
		}
	}
	/* get Mamdani output MF parameters */
	if (strcmp(fis->type, "mamdani") == 0) {
		for (i = 0; i < fis->out_n; i++)
			for (j = 0; j < fis->output[i]->mf_n; j++) {
				for (k = 0; k < MF_PARA_N; k++)
					fis->output[i]->mf[j]->para[k] =
						fismatrix[start][k];
				start++;
			}
		fisComputeOutputMfValueArray(fis, numofpoints);
	/* get Sugeno output equation parameters */
	} else if (strcmp(fis->type, "sugeno") == 0) {
		for (i = 0; i < fis->out_n; i++)
			for (j = 0; j < fis->output[i]->mf_n; j++) {
				for (k = 0; k < fis->in_n+1; k++)
					fis->output[i]->mf[j]->sugeno_coef[k] =
						fismatrix[start][k];
				start++;
			}
	} else {
#ifndef NO_PRINTF
		printf("fis->type = %s\n", fis->type);
#endif
		fisError("Unknown fis type!");
	}

	for (i = 0; i < fis->rule_n; i++) {
		for (j = 0; j < fis->in_n + fis->out_n; j++)
			fis->rule_list[i][j] = (int)fismatrix[start][j];
		fis->rule_weight[i] = fismatrix[start][fis->in_n+fis->out_n];
		fis->and_or[i] = (int)fismatrix[start][fis->in_n+fis->out_n+1];
		start++;
	}
}

/* load parameters contain in the given parameter array */
/* (Note that the array is compact, no zero padding */
static void 
#ifdef __STDC__
fisLoadParameter1(FIS *fis, double *para_array, int numofpoints)
#else
fisLoadParameter1(fis, para_array)
FIS *fis;
double *para_array;
int numofpoints;
#endif
{
	int start = 0;
	int paraN;
	int i, j, k;

	/* get input MF parameters */
	for (i = 0; i < fis->in_n; i++)
		for (j = 0; j < fis->input[i]->mf_n; j++) {
			paraN = fisGetMfParaN(fis->input[i]->mf[j]->type);
			for (k = 0; k < paraN; k++)
				fis->input[i]->mf[j]->para[k] = para_array[start++];
		}

	/* get Mamdani output MF parameters */
	if (strcmp(fis->type, "mamdani") == 0) {
		for (i = 0; i < fis->out_n; i++)
			for (j = 0; j < fis->output[i]->mf_n; j++) {
				paraN = fisGetMfParaN(fis->input[i]->mf[j]->type);
				for (k = 0; k < paraN; k++)
					fis->output[i]->mf[j]->para[k] = para_array[start++];
			}
		fisComputeOutputMfValueArray(fis, numofpoints);
	/* get Sugeno output equation parameters */
	} else if (strcmp(fis->type, "sugeno") == 0) {
		for (i = 0; i < fis->out_n; i++)
			for (j = 0; j < fis->output[i]->mf_n; j++)
				for (k = 0; k < fis->in_n+1; k++)
					fis->output[i]->mf[j]->sugeno_coef[k] =
						para_array[start++];
	} else {
#ifndef NO_PRINTF
		printf("fis->type = %s\n", fis->type);
#endif
		fisError("Unknown fis type!");
	}
}

/* Returns a FIS pointer if there is a match; otherwise signals error */
static FIS *
#ifdef __STDC__
fisMatchHandle(FIS *head, int handle)
#else
fisMatchHandle(head, handle)
FIS *head;
int handle;
#endif
{
	FIS *p;

	for (p = head; p != NULL; p = p->next)
		if (p->handle == handle)
			break;
	if (p == NULL) {
#ifndef NO_PRINTF
		printf("Given handle is %d.\n", handle);
#endif
		fisError("Cannot find an FIS with this handle.");
	}
	return(p);
}

/* Returns the FIS handle that matches a given name */
/* If more than two are qualified, the largest handle is returned.  */
static FIS *
#ifdef __STDC__
fisMatchName(FIS *head, char *name)
#else
fisMatchName(head, name)
FIS *head;
char *name;
#endif
{
	FIS *p, *matched_p = NULL;

	for (p = head; p != NULL; p = p->next)
		if (strcmp(p->name, name) == 0)
			matched_p = p;
	return(matched_p);
}

static int
#ifdef __STDC__
fisFindMaxHandle(FIS *head)
#else
fisFindMaxHandle(head)
FIS *head;
#endif
{
	FIS *p;
	int max_handle = 0;

	if (head == NULL)
		return(0);

	for (p = head; p != NULL; p = p->next)
		if (p->handle > max_handle)
			max_handle = p->handle;
	return(max_handle);
}
/***********************************************************************
 Main functions for fuzzy inference 
 **********************************************************************/
/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: $  $Date: $  */

/* Compute MF values for all input variables */
static void
#ifdef __STDC__
fisComputeInputMfValue(FIS *fis)
#else
fisComputeInputMfValue(fis)
FIS *fis;
#endif
{
	int i, j;
	MF *mf_node;

	for (i = 0; i < fis->in_n; i++)
		for (j = 0; j < fis->input[i]->mf_n; j++) {
			mf_node = fis->input[i]->mf[j];
			if (!mf_node->userDefined)
				mf_node->value = (*mf_node->mfFcn)
					(fis->input[i]->value, mf_node->para);
			else {
#ifdef MATLAB_MEX_FILE
				mf_node->value =
					fisCallMatlabMf(fis->input[i]->value, mf_node->para, mf_node->type);
#else
#ifndef NO_PRINTF
				printf("Given MF %s is unknown.\n", mf_node->label);
#endif
				fisError("Exiting ...");
#endif
			}
		}
}

/* Compute rule output (for Sugeno model only) */
static void
#ifdef __STDC__
fisComputeTskRuleOutput(FIS *fis)
#else
fisComputeTskRuleOutput(fis)
FIS *fis;
#endif
{
	int i, j, k;
	double out;
	MF *mf_node;

	for (i = 0; i < fis->out_n; i++)
		for (j = 0; j < fis->output[i]->mf_n; j++) {
			mf_node = fis->output[i]->mf[j];
			out = 0;
			for (k = 0; k < fis->in_n; k++)
				out += (fis->input[k]->value)*(mf_node->sugeno_coef[k]);
			out = out + mf_node->sugeno_coef[fis->in_n];
			mf_node->value = out;
		}
}

/* Compute firing strengths */
static void
#ifdef __STDC__
fisComputeFiringStrength(FIS *fis)
#else
fisComputeFiringStrength(fis)
FIS *fis;
#endif
{
	double out = 0, mf_value;
	int i, j, which_mf;

	/* Compute original firing strengths via andFcn or orFcn */
	for (i = 0; i < fis->rule_n; i++) {
		if (fis->and_or[i] == 1) {	/* AND premise */
			for (j = 0; j < fis->in_n; j++) {
				which_mf = fis->rule_list[i][j];
				if (which_mf > 0)
					mf_value =fis->input[j]->mf[which_mf-1]->value;
				else if (which_mf == 0) /* Don't care */
					mf_value = 1;
				else		/* Linguistic hedge NOT */
					mf_value = 1 - fis->input[j]->mf[-which_mf-1]->value;
				fis->mfs_of_rule[j] = mf_value;
			}
			if (!fis->userDefinedAnd)
				out = fisArrayOperation(
					fis->mfs_of_rule, fis->in_n, fis->andFcn);
			else {
#ifdef MATLAB_MEX_FILE
				out = fisCallMatlabFcn(
					fis->mfs_of_rule, fis->in_n, fis->andMethod);
#else
#ifndef NO_PRINTF
				printf("Given AND method %s is unknown.\n", fis->andMethod);
#endif
				fisError("Exiting ...");
#endif
			}
		} else {			/* OR premise */
			for (j = 0; j < fis->in_n; j++) {
				which_mf = fis->rule_list[i][j];
				if (which_mf > 0)
					mf_value =fis->input[j]->mf[which_mf-1]->value;
				else if (which_mf == 0) /* Don't care */
					mf_value = 0;
				else		/* Linguistic hedge NOT */
					mf_value = 1 - fis->input[j]->mf[-which_mf-1]->value;
				fis->mfs_of_rule[j] = mf_value;
			}
			if (!fis->userDefinedOr)
				out = fisArrayOperation(
					fis->mfs_of_rule, fis->in_n, fis->orFcn);
			else {
#ifdef MATLAB_MEX_FILE
				out = fisCallMatlabFcn(
					fis->mfs_of_rule, fis->in_n, fis->orMethod);
#else
#ifndef NO_PRINTF
				printf("Given OR method %s is unknown.\n", fis->orMethod);
#endif
				fisError("Exiting ...");
#endif
			}
		}
		fis->firing_strength[i] = out;
	}

	/*
	for (i = 0; i < fis->rule_n; i++)
		printf("%f ", fis->firing_strength[i]);
	printf("\n");
	*/

	/* Scale the original firing strength by rule_weight */
	for (i = 0; i < fis->rule_n; i++)
		fis->firing_strength[i] = 
			fis->rule_weight[i]*fis->firing_strength[i];
}

#ifdef MATLAB_MEX_FILE
/* Returns the n-th value of combined m-th output MF. */
/* (n is the index into the MF value arrays of the m-th output.) */
/* Both m and n are zero-offset */
/* (for Mamdani's model only */
/* This is used in mexFunction() of evalfis.c only */
static double
#ifdef __STDC__
fisFinalOutputMf(FIS *fis, int m, int n)
#else
fisFinalOutputMf(fis, m, n)
FIS *fis;
int m;
int n;
#endif
{
	int i, which_mf;
	double mf_value, out;

	/* The following should not be based on t-conorm */
	for (i = 0; i < fis->rule_n; i++) {
		/* rule_list is 1-offset */
		which_mf = fis->rule_list[i][fis->in_n+m];
		if (which_mf > 0)
			mf_value = fis->output[m]->mf[which_mf-1]->value_array[n];
		else if (which_mf == 0)	/* Don't care */
			mf_value = 0;
		else
			mf_value = 1-fis->output[m]->mf[-which_mf-1]->value_array[n];
		if (!fis->userDefinedImp)
			fis->rule_output[i] = (*fis->impFcn)(mf_value,
				fis->firing_strength[i]);
		else {
			double tmp[2];
			tmp[0] = mf_value;
			tmp[1] = fis->firing_strength[i];
			fis->rule_output[i] = fisCallMatlabFcn(tmp, 2, fis->impMethod);
		}
	}
	if (!fis->userDefinedAgg)
		out = fisArrayOperation(fis->rule_output, fis->rule_n, fis->aggFcn);
	else
		out = fisCallMatlabFcn(fis->rule_output, fis->rule_n, fis->aggMethod);
	return(out);
}
#endif

/* Returns the aggregated MF aggMF of the m-th output variable . */
/* (for Mamdani's model only */
static void
#ifdef __STDC__
fisFinalOutputMf2(FIS *fis, int m, double *aggMF, int numofpoints)
#else
fisFinalOutputMf2(fis, m, aggMF)
FIS *fis;
int m;
double *aggMF;
int numofpoints;
#endif
{
	int i, j, which_mf;

	/* fill in BigOutMfMatrix */
	/* The following should not be based on t-conorm */
	for (i = 0; i < fis->rule_n; i++) {
		which_mf = fis->rule_list[i][fis->in_n+m];
		if (which_mf > 0)
			for (j = 0; j < numofpoints; j++)
				/*
				fis->BigOutMfMatrix[i][j] = 
					fis->output[m]->mf[which_mf-1]->value_array[j];
				*/
				fis->BigOutMfMatrix[j*fis->rule_n+i] = 
					fis->output[m]->mf[which_mf-1]->value_array[j];
		else if (which_mf < 0)
			for (j = 0; j < numofpoints; j++)
				/*
				fis->BigOutMfMatrix[i][j] = 
					1-fis->output[m]->mf[-which_mf-1]->value_array[j];
				*/
				fis->BigOutMfMatrix[j*fis->rule_n+i] = 
					1 - fis->output[m]->mf[-which_mf-1]->value_array[j];
		else	/* which_mf == 0 */
			for (j = 0; j < numofpoints; j++)
				fis->BigOutMfMatrix[j*fis->rule_n+i] = 0; 
	}

	/* fill in BigWeightMatrix */
	for (i = 0; i < fis->rule_n; i++)
		for (j = 0; j < numofpoints; j++)
				fis->BigWeightMatrix[j*fis->rule_n+i] = 
					fis->firing_strength[i];

	/* apply implication operator */
	if (!fis->userDefinedImp)
		for (i = 0; i < (fis->rule_n)*numofpoints; i++)
			fis->BigOutMfMatrix[i] = (*fis->impFcn)(
				fis->BigWeightMatrix[i], fis->BigOutMfMatrix[i]);
	else {
#ifdef MATLAB_MEX_FILE
		fisCallMatlabFcn2(fis->BigWeightMatrix, fis->BigOutMfMatrix,
			fis->rule_n, numofpoints, fis->impMethod, fis->BigOutMfMatrix);
#else
#ifndef NO_PRINTF
				printf("Given IMP method %s is unknown.\n", fis->impMethod);
#endif
				fisError("Exiting ...");
#endif
	}
	
	/* apply MATLAB aggregate operator */
	if (!fis->userDefinedAgg)
		for (i = 0; i < numofpoints; i++)
			aggMF[i] = fisArrayOperation(
			fis->BigOutMfMatrix+i*fis->rule_n,
			fis->rule_n, fis->aggFcn);
	else {
#ifdef MATLAB_MEX_FILE
		fisCallMatlabFcn1(fis->BigOutMfMatrix, fis->rule_n,
			numofpoints, fis->aggMethod, aggMF);
#else
#ifndef NO_PRINTF
				printf("Given AGG method %s is unknown.\n", fis->aggMethod);
#endif
				fisError("Exiting ...");
#endif
	}
}

/***********************************************************************
 Evaluate the constructed FIS based on given input vector 
 **********************************************************************/

/* compute outputs and put them into output nodes */
void
#ifdef __STDC__
fisEvaluate(FIS *fis, int numofpoints)
#else
fisEvaluate(fis)
FIS *fis;
int numofpoints
#endif
{
	double out = 0;
	double total_w, total_wf;
	int i, j, k, which_mf;

	if (fis == NULL) {
#ifndef NO_PRINTF
		printf("FIS data structure has not been built yet.\n");
#endif
		fisError("Exiting ...");
	}
	
	fisComputeInputMfValue(fis);
	fisComputeFiringStrength(fis);
	total_w = fisArrayOperation(fis->firing_strength, fis->rule_n, fisSum);
	if (total_w == 0) {
#ifndef NO_PRINTF
		printf("Warning: no rule is fired for input [");
		for (i = 0; i < fis->in_n; i++)
			printf("%f ", fis->input[i]->value);
		
		printf("]!\n");
		printf("Average of the range of each output variable is used as default output.\n\n");
#endif
		for (i = 0; i < fis->out_n; i++)
			fis->output[i]->value = (fis->output[i]->bound[0] +
				fis->output[i]->bound[1])/2;
		return;
	}

	if (strcmp(fis->type, "sugeno") == 0) {
	fisComputeTskRuleOutput(fis);
	/* Find each rule's output */
	for (i = 0; i < fis->out_n; i++) {
		for (j = 0; j < fis->rule_n; j++) {
			which_mf = fis->rule_list[j][fis->in_n + i] - 1;
			if (which_mf == -1)	/* don't_care consequent */
				fis->rule_output[j] = 0;
			else
				fis->rule_output[j] = fis->output[i]->mf[which_mf]->value;
		}
		/* Weighted average to find the overall output*/
		total_wf = 0;
		for (k = 0; k < fis->rule_n; k++)
			total_wf += (fis->firing_strength[k]*
				fis->rule_output[k]);

		if (strcmp(fis->defuzzMethod, "wtaver") == 0)
			fis->output[i]->value = total_wf/total_w;
		else if (strcmp(fis->defuzzMethod, "wtsum") == 0)
			fis->output[i]->value = total_wf;
		else {
#ifndef NO_PRINTF
			printf("Unknown method (%s) for Sugeno model!", fis->defuzzMethod);
#endif
			fisError("Legal methods: wtaver, wtsum");
		}
	}
	}
	else if (strcmp(fis->type, "mamdani") == 0)
	for (i = 0; i < fis->out_n; i++) {
	/*	double aggMF[MF_POINT_N];
		double X[MF_POINT_N];*/
		double *aggMF;
		double *X;

		double min = fis->output[i]->bound[0];
		double max = fis->output[i]->bound[1];
		double step = (max - min)/(numofpoints - 1);

                X = (double *)calloc(numofpoints, sizeof(double));
                aggMF = (double *)calloc(numofpoints, sizeof(double));      
                
		for (j = 0; j < numofpoints; j++)
			X[j] = min + step*j;
		/* fill in aggMF */
		fisFinalOutputMf2(fis, i, aggMF, numofpoints);
		/* defuzzification */
		if (!fis->userDefinedDefuzz)
			out = (*fis->defuzzFcn)(fis, i, aggMF, numofpoints);
		else {	/* user defined defuzzification */
#ifdef MATLAB_MEX_FILE
			out = fisCallMatlabDefuzz(X, aggMF, 
				numofpoints, fis->defuzzMethod);
#else
#ifndef NO_PRINTF
			printf("Given defuzzification method %s is unknown.\n", fis->defuzzMethod);
#endif
			fisError("Exiting ...");
#endif
		}
		fis->output[i]->value = out;
                free(X);
                free(aggMF);
	}
	else {
#ifndef NO_PRINTF
	printf("Given FIS %s is unknown.\n", fis->name);
#endif
	fisError("Exiting ...");
	}
}

/* given input vector and FIS data structure, return output */
/* this is a wrap-up on fisEvaluate () */  
/* used in fismain() only */
static void
#ifdef __STDC__
getFisOutput(double *input, FIS *fis, double *output)
#else
getFisOutput(input, fis, output)
double *input;
FIS *fis;
double *output;
#endif
{
	int i;

	/* dispatch input */
	for (i = 0; i < fis->in_n; i++)
		fis->input[i]->value = input[i];

	/* evaluate FIS */
	fisEvaluate(fis, 101);

	/* dispatch output */
	for (i = 0; i < fis->out_n; i++)
		output[i] = fis->output[i]->value;
}
/* Copyright (c) 1994-98 by The MathWorks, Inc. */
/* $Revision: 1.7 $ */

#ifdef MATLAB_MEX_FILE
FIS *matlab2cStr(const mxArray *matlabmat, int numofpoints)
{
        mxArray *fispointer, *inputpointer, *mfpointer;
        char *buf;
	int i, j,k, param_size, data_n, in_n;
	FIS *fis;

        int status, buflen=100;	
        int io_vector_size;
        double *real_data_ptr;
	int *in_mf_n, *out_mf_n;
	IO *io_list;

	/*----------- Create FIS node -------------------*/
        buf=mxCalloc(buflen, sizeof(char));
        /* get fis name, type, ....*/
        fis = (FIS *)calloc(1, sizeof(FIS));
        fispointer=mxGetField(matlabmat, 0,"name");
        status=mxGetString(fispointer, fis->name, buflen);

        /* fis->type */
        fispointer=mxGetField(matlabmat, 0,"type");
        status=mxGetString(fispointer, fis->type, buflen);
        if (status!=0)
           fisError("Can not get fis type");
        /* fis->andMethod */
        fispointer=mxGetField(matlabmat, 0,"andMethod");
        status=mxGetString(fispointer, fis->andMethod, buflen);
        if (status!=0)
           fisError("Can not get fis andMethod");
        /* fis->orMethod */
        fispointer=mxGetField(matlabmat, 0,"orMethod");
        status=mxGetString(fispointer, fis->orMethod, buflen);
        if (status!=0)
           fisError("Can not get fis orMethod");
        /* fis->defuzzMethod */
        fispointer=mxGetField(matlabmat, 0,"defuzzMethod");
        status=mxGetString(fispointer, fis->defuzzMethod, buflen);
        if (status!=0)
           fisError("Can not get fis defuzzMethod");
        /* fis->impMethod */
        fispointer=mxGetField(matlabmat, 0,"impMethod");
        status=mxGetString(fispointer, fis->impMethod, buflen);
        if (status!=0)
           fisError("Can not get fis impMethod");
        /* fis->aggMethod */
        fispointer=mxGetField(matlabmat, 0,"aggMethod");
        status=mxGetString(fispointer, fis->aggMethod, buflen);
        if (status!=0)
           fisError("Can not get fis aggMethod");

        fispointer=mxGetField(matlabmat, 0,"input");
	io_vector_size = mxGetN(fispointer);
	fis->in_n=io_vector_size;
	fis->input = (IO **)calloc(io_vector_size, sizeof(IO *));
       
	/* create input node list, each in_mf_n's element containts the number of mf */
	in_mf_n = (int *)calloc(fis->in_n, sizeof(int));
	for (i = 0; i < fis->in_n; i++){
           inputpointer=mxGetField(fispointer, i, "mf"); 
           if (inputpointer!=NULL)
            in_mf_n[i]=mxGetN(inputpointer);
           else
            in_mf_n[i]=0;
        }
	io_list = fisBuildIoList(fis->in_n, in_mf_n);
       
	free(in_mf_n);
	fis->input = (IO **)calloc(fis->in_n, sizeof(IO *));
	for (i = 0; i < fis->in_n; i++)
		fis->input[i] = io_list+i;
        /*finished input memory allocation */

	for(i=0; i<fis->in_n; i++){
          inputpointer=mxGetField(fispointer, i, "name");
          status=mxGetString(inputpointer, fis->input[i]->name, buflen);

          inputpointer=mxGetField(fispointer, i, "range");
          real_data_ptr=(double *)mxGetPr(inputpointer);
          fis->input[i]->bound[0]=*real_data_ptr;
          fis->input[i]->bound[1]=*(real_data_ptr+1);

          inputpointer=mxGetField(fispointer, i, "mf");
          if (inputpointer!=NULL)
            fis->input[i]->mf_n=mxGetN(inputpointer);
          else
            fis->input[i]->mf_n=0;
          for(j=0; j<fis->input[i]->mf_n; j++){
             mfpointer=mxGetField(inputpointer, j, "name");
             status=mxGetString(mfpointer, fis->input[i]->mf[j]->label, buflen);
             mfpointer=mxGetField(inputpointer, j, "type");
             status=mxGetString(mfpointer, fis->input[i]->mf[j]->type, buflen);
             mfpointer=mxGetField(inputpointer, j, "params");
             param_size=mxGetN(mfpointer);
             real_data_ptr=(double *)mxGetPr(mfpointer);
             for(k=0; k<param_size; k++){
               fis->input[i]->mf[j]->para[k]=*real_data_ptr++;
	     }
          }      
        }
	/*output*/
        fispointer=mxGetField(matlabmat, 0,"output");
	io_vector_size = mxGetN(fispointer);
	fis->out_n=io_vector_size;

	/* create output node list, each in_mf_n's element containts the number of mf */
	out_mf_n = (int *)calloc(fis->out_n, sizeof(int));
	for (i = 0; i < fis->out_n; i++){
                inputpointer=mxGetField(fispointer, i, "mf"); 
		out_mf_n[i]=mxGetN(inputpointer);
        }
	io_list = fisBuildIoList(fis->out_n, out_mf_n);
	free(out_mf_n); 
	fis->output = (IO **)calloc(fis->out_n, sizeof(IO *));
	for (i = 0; i < fis->out_n; i++)
		fis->output[i] = io_list+i;
        /*finished output memory allocation */
	
	for(i=0; i<fis->out_n; i++){
          inputpointer=mxGetField(fispointer, i, "name");
          status=mxGetString(inputpointer, fis->output[i]->name, buflen);

          inputpointer=mxGetField(fispointer, i, "range");
          real_data_ptr=(double *)mxGetPr(inputpointer);
          fis->output[i]->bound[0]=*real_data_ptr;
          fis->output[i]->bound[1]=*(real_data_ptr+1);

          inputpointer=mxGetField(fispointer, i, "mf");
          if (inputpointer!=NULL)
           fis->output[i]->mf_n=mxGetN(inputpointer);
          else
           fis->output[i]->mf_n=0;
          for(j=0; j<fis->output[i]->mf_n; j++){
             mfpointer=mxGetField(inputpointer, j, "name");
             status=mxGetString(mfpointer, fis->output[i]->mf[j]->label, buflen);
             mfpointer=mxGetField(inputpointer, j, "type");
             status=mxGetString(mfpointer, fis->output[i]->mf[j]->type, buflen);
             mfpointer=mxGetField(inputpointer, j, "params");
             param_size=mxGetN(mfpointer);
             real_data_ptr=(double *)mxGetPr(mfpointer);

	     /* get Mamdani output MF parameters and compute MF value array */
	      if (strcmp(fis->type, "mamdani") == 0) {
		  fis->output[i]->mf[j]->value_array =(double *)calloc(numofpoints, sizeof(double)); 	
	          for(k=0; k<param_size; k++)
                   fis->output[i]->mf[j]->para[k]=*real_data_ptr++;
	     /* get Sugeno output equation parameters */
		  } else if (strcmp(fis->type, "sugeno") == 0) {
		      fis->output[i]->mf[j]->sugeno_coef =
					(double *)calloc(fis->in_n+1, sizeof(double));
                     if (strcmp(fis->output[i]->mf[j]->type, "linear") == 0) {
		      for (k = 0; k < fis->in_n+1; k++)
		        fis->output[i]->mf[j]->sugeno_coef[k] =*real_data_ptr++;
                    } else{
		      for (k = 0; k < fis->in_n; k++)
                        fis->output[i]->mf[j]->sugeno_coef[k]=0;
		      fis->output[i]->mf[j]->sugeno_coef[fis->in_n] =*real_data_ptr;
                  }   
                     
	        } else {
#ifndef NO_PRINTF
		printf("fis->type = %s\n", fis->type);
#endif
		fisError("Unknown fis type!");
	     }
          }      
        }

        fispointer=mxGetField(matlabmat, 0,"rule");
        if (fispointer==NULL)
         fis->rule_n=0;
        else
	 fis->rule_n = mxGetN(fispointer);
	fis->rule_list = (int **)fisCreateMatrix(fis->rule_n, fis->in_n + fis->out_n, sizeof(int));
	fis->rule_weight = (double *)calloc(fis->rule_n, sizeof(double));
	fis->and_or = (int *)calloc(fis->rule_n, sizeof(int));
	
	for (i = 0; i < fis->rule_n; i++) {
            inputpointer=mxGetField(fispointer, i, "antecedent");
            real_data_ptr=(double *)mxGetPr(inputpointer);
	    for (j = 0; j < fis->in_n ; j++)
		fis->rule_list[i][j] = *real_data_ptr++;
            inputpointer=mxGetField(fispointer, i, "consequent");
            real_data_ptr=(double *)mxGetPr(inputpointer);
	    for (j = 0; j < fis->out_n ; j++)
		fis->rule_list[i][j+fis->in_n] = *real_data_ptr++;
            inputpointer=mxGetField(fispointer, i, "weight");
            real_data_ptr=(double *)mxGetPr(inputpointer);
	    fis->rule_weight[i] = *real_data_ptr;
            inputpointer=mxGetField(fispointer, i, "connection");
            real_data_ptr=(double *)mxGetPr(inputpointer);
	    fis->and_or[i] =*real_data_ptr; 
	}
		fisAssignMfPointer(fis);
	fisAssignFunctionPointer(fis); 
	fis->firing_strength = (double *)calloc(fis->rule_n, sizeof(double));
	fis->rule_output = (double *)calloc(fis->rule_n, sizeof(double));

	if (strcmp(fis->type, "mamdani") == 0) {
		fis->BigOutMfMatrix = (double *)
			calloc(fis->rule_n*numofpoints, sizeof(double));
		fis->BigWeightMatrix = (double *)
			calloc(fis->rule_n*numofpoints, sizeof(double));
	}
	fis->mfs_of_rule = (double *)calloc(fis->in_n, sizeof(double));
        if (strcmp(fis->type, "mamdani") == 0) {
    	  for (i = 0; i < fis->out_n; i++)
         	fisComputeOutputMfValueArray(fis, numofpoints);
	} 
       	fisCheckDataStructure(fis);

	/*----------finished setting fis structure-------------------*/
	fis->next = NULL;
        return(fis);
}
#else
# define matlab2cStr(matlabmat, numofpoints)  NULL
#endif
/*
 * Defines for easy access to the FIS matrix that are passed in
 */
#define FISMATRIX	ssGetSFcnParam(S,0)

/*
 * mdlInitializeSizes - initialize the sizes array
 */

static void mdlInitializeSizes(SimStruct *S)
{
	double *tmp;
	int in_n, out_n;
        mxArray *fispointer;


	if (ssGetNumArgs(S) == 1) {
           fispointer=mxGetField(FISMATRIX, 0,"input");
	   in_n = mxGetN(fispointer);
	   fispointer=mxGetField(FISMATRIX, 0,"output");
           out_n = mxGetN(fispointer);

		ssSetNumContStates(S, 0);	/* no. of continuous states */
		ssSetNumDiscStates(S, 0);	/* no. of discrete states */
		ssSetNumInputs(S, in_n);	/* no. of inputs */
		ssSetNumOutputs(S, out_n);	/* no. of outputs */
		ssSetDirectFeedThrough(S, 1);	/* direct feedthrough flag */
		ssSetNumSampleTimes(S, 1);	/* no. of sample times */
		ssSetNumInputArgs(S, 1);	/* no. of input arguments */
		ssSetNumRWork(S, 0);	/* no. of real work vector elements */
		ssSetNumIWork(S, 0);	/* no. of int. work vector elements */
		ssSetNumPWork(S, 1);	/* no. of ptr. work vector elements */
                ssSetNumModes(S, 0);            /* number of mode work vector elements   */
                ssSetNumNonsampledZCs(S, 0);    /* number of nonsampled zero crossings   */
                ssSetOptions(S, 0);             /* general options (SS_OPTION_xx)        */
					/* This is the FIS pointer */
	} else {
#ifdef MATLAB_MEX_FILE
	    mexErrMsgTxt("Need FIS matrix as an additional input.");
#endif
	}
}

/*
 * mdlInitializeSampleTimes - initialize the sample times array
 *
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTimeEvent(S, 0, INHERITED_SAMPLE_TIME);
    ssSetOffsetTimeEvent(S, 0, 0.0);
}

/*
 * mdlInitializeConditions - initialize the states
 *
 * In this function, you should initialize the continuous and discrete
 * states for your S-function block.  The initial states are placed
 * in the x0 variable.  You can also perform any other initialization
 * activities that your S-function may require.
 */
static void mdlInitializeConditions(double *x0, SimStruct *S)
{
	int m, n, i, j;
	FIS *fis;


	/* Create FIS node */
	fis = (FIS *)calloc(1, sizeof(FIS));
	/*fisBuildFisNode(fis, FISMATRIX, n);*/
   /*======use Structure=======*/
   fis=matlab2cStr(FISMATRIX, 101);

	fis->next = NULL;

	
	/* Set fis as the Pwork for this S function */
	ssGetPWork(S)[0] = fis;
}

/*
 * mdlOutputs - compute the outputs (y)
 */
static void mdlOutputs(real_T *y, const real_T *x, const real_T *u, 
                       SimStruct *S, int_T tid)
{
	FIS *fis; /* obtained from Pwork */
	int_T j;

	fis = (FIS *)ssGetPWork(S)[0];

	/* Dispatch the inputs */
	for (j = 0; j < fis->in_n; j++)
		fis->input[j]->value = u[j];
	/* Compute the output */
	fisEvaluate(fis, 101);
	/* Collect the output */
	for (j = 0; j < fis->out_n; j++)
		y[j] = fis->output[j]->value;
}

/*
 * mdlUpdate - perform action at major integration time step
 *
 * This function is called once for every major integration time step.
 * Discrete states are typically updated here, but this function is useful
 * for performing any tasks that should only take place once per integration
 * step.
 */
static void mdlUpdate(real_T *x, const real_T *u, SimStruct *S, int_T tid)
{
}

/*
 * mdlDerivatives - compute the derivatives (dx)
 */
static void mdlDerivatives(real_T *dx, const real_T *x, const real_T *u, 
                           SimStruct *S, int_T tid)
{
}

/*
 * mdlTerminate - called when the simulation is terminated.
 */
static void mdlTerminate(SimStruct *S)
{
	FIS *fis; /* obtained from Pwork */

	fis = (FIS *)ssGetPWork(S)[0];
	fisFreeFisNode(fis);
}

#ifdef	MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif
