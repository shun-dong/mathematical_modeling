% Copyright (c) 1994-98 by The MathWorks, Inc.
% $Revision: 1.2 $
function out=mrdivide(mf1,mf2)
mf3.x=mf1.x;
mf3.y=fuzarith(mf1.x,mf1.y,mf2.y,'div');
plot(mf1.x,[mf1.y mf2.y mf3.y]);
out=mf(mf3.x,mf3.y);
