function y=custand(x)
%CUSTAND Customized AND function for CUSTTIP.FIS.
%
%   Copyright (c) 1994-98 by The MathWorks, Inc.
%       $Revision: 1.3 $

y=min(x).^0.5;
