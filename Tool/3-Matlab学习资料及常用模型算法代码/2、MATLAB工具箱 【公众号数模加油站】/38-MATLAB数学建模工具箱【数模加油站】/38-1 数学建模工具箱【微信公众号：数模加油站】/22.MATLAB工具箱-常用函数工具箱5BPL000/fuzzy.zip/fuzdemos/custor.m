function y=custor(x)
%CUSTOR Customized OR functions for CUSTTIP.FIS.
%   This function is really just PROBOR in disguise.
%   Copyright (c) 1994-98 by The MathWorks, Inc.
%       $Revision: 1.3 $

y=(probor(x)/2);
